
// Mock implementations for Capacitor plugins
// These are used when the native packages are not installed to prevent build errors.

export class FirebaseAnalytics {
  static async setEnabled(options: { enabled: boolean }) {
    console.log('[Mock Analytics] setEnabled:', options);
  }
  static async logEvent(options: { name: string; params: any }) {
    console.log('[Mock Analytics] logEvent:', options.name, options.params);
  }
  static async setUserId(options: { userId: string }) {
    console.log('[Mock Analytics] setUserId:', options);
  }
  static async setUserProperty(options: { name: string; value: string }) {
    console.log('[Mock Analytics] setUserProperty:', options);
  }
  static async setScreenName(options: { screenName: string; screenClassOverride?: string }) {
    console.log('[Mock Analytics] setScreenName:', options);
  }
}

export class FirebaseCrashlytics {
  static async setEnabled(options: { enabled: boolean }) {
    console.log('[Mock Crashlytics] setEnabled:', options);
  }
  static async recordException(options: { message: string }) {
    console.error('[Mock Crashlytics] recordException:', options.message);
  }
  static async log(options: { message: string }) {
    console.log('[Mock Crashlytics] log:', options.message);
  }
}

export class FirebaseRemoteConfig {
  static async fetchAndActivate() {
    console.log('[Mock RemoteConfig] fetchAndActivate');
  }
  static async getString(options: { key: string }) {
    console.log('[Mock RemoteConfig] getString:', options.key);
    return { value: '' };
  }
  static async getBoolean(options: { key: string }) {
    console.log('[Mock RemoteConfig] getBoolean:', options.key);
    return { value: false }; // Default to false for feature flags
  }
  static async getNumber(options: { key: string }) {
    console.log('[Mock RemoteConfig] getNumber:', options.key);
    return { value: 0 };
  }
}

export class LocalNotifications {
  static async requestPermissions() {
    console.log('[Mock LocalNotifications] requestPermissions');
    return { display: 'granted' };
  }

  static async createChannel(channel: any) {
    console.log('[Mock LocalNotifications] createChannel:', channel);
  }

  static async schedule(options: { notifications: any[] }) {
    console.log('[Mock LocalNotifications] schedule:', options.notifications);
    return { notifications: [] };
  }

  static async getPending() {
    console.log('[Mock LocalNotifications] getPending');
    return { notifications: [] };
  }

  static async cancel(pending: any) {
    console.log('[Mock LocalNotifications] cancel:', pending);
  }

  static async addListener(eventName: string, listenerFunc: (notification: any) => void) {
    console.log('[Mock LocalNotifications] addListener:', eventName);
    return { remove: () => {} };
  }
}

export class Geolocation {
  static async requestPermissions() {
    console.log('[Mock Geolocation] requestPermissions');
    return { location: 'granted' };
  }

  static async getCurrentPosition(options?: any) {
    console.log('[Mock Geolocation] getCurrentPosition', options);
    // Return a dummy position (Mecca coordinates)
    return {
      coords: {
        latitude: 21.4225,
        longitude: 39.8262,
        accuracy: 100,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        speed: 0
      },
      timestamp: Date.now()
    };
  }
}
