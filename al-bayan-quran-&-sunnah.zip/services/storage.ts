
import { AppNotification, AyahBookmark, Note, PageBookmark, Zekr, TasbihItem, PrayerData } from '../types';

// Keys
const KEY_FAV_ADHKAR = 'favorites_adhkar';
const KEY_CUSTOM_ADHKAR = 'custom_adhkar';
const KEY_CUSTOM_TASBIH = 'custom_tasbih_items'; 
const KEY_BOOKMARKS_AYAH = 'bookmarks_ayah';
const KEY_BOOKMARKS_PAGE = 'bookmarks_page';
const KEY_NOTES = 'user_notes';
const KEY_NOTIFICATIONS = 'notifications_table';
const KEY_SETTINGS_FONT = 'settings_font_size';
const KEY_SETTINGS_RECITER = 'settings_reciter';
const KEY_SETTINGS_AZHAN = 'settings_azhan_voice'; // New Key
const KEY_BENEFIT_HISTORY = 'daily_benefit_history_ids'; 
const KEY_CURRENT_BENEFIT = 'daily_benefit_current';
const KEY_LAST_USED_CATEGORY = 'smart_last_category';
const KEY_LAST_USED_ZEKR_ID = 'smart_last_zekr_id';
const KEY_LAST_TASBIH_TARGET = 'smart_tasbih_target';
const KEY_CACHED_PRAYERS = 'cached_prayer_times_today';

// --- Prayer Times Global Storage ---

export const saveDailyPrayers = (data: PrayerData): void => {
  const payload = {
    date: new Date().toDateString(),
    data: data
  };
  localStorage.setItem(KEY_CACHED_PRAYERS, JSON.stringify(payload));
};

export const getDailyPrayers = (): PrayerData | null => {
  try {
    const stored = localStorage.getItem(KEY_CACHED_PRAYERS);
    if (!stored) return null;
    
    const parsed = JSON.parse(stored);
    if (parsed.date === new Date().toDateString()) {
      return parsed.data;
    }
    return null;
  } catch { return null; }
};

// --- Smart Behavior Helpers ---

export const setLastUsedCategory = (category: string): void => {
  localStorage.setItem(KEY_LAST_USED_CATEGORY, category);
};

export const getLastUsedCategory = (): string | null => {
  return localStorage.getItem(KEY_LAST_USED_CATEGORY);
};

export const setLastUsedZekrId = (id: number): void => {
  localStorage.setItem(KEY_LAST_USED_ZEKR_ID, id.toString());
};

export const getLastUsedZekrId = (): number | null => {
  const val = localStorage.getItem(KEY_LAST_USED_ZEKR_ID);
  return val ? parseInt(val) : null;
};

export const setLastTasbihTarget = (target: number): void => {
  localStorage.setItem(KEY_LAST_TASBIH_TARGET, target.toString());
};

export const getLastTasbihTarget = (): number | null => {
  const val = localStorage.getItem(KEY_LAST_TASBIH_TARGET);
  return val ? parseInt(val) : null;
};

// --- Daily Benefit Logic ---

export interface StoredBenefit {
  date: string;
  data: any;
}

export const getBenefitHistory = (): string[] => {
  try {
    const stored = localStorage.getItem(KEY_BENEFIT_HISTORY);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const addToBenefitHistory = (id: string): void => {
  const history = getBenefitHistory();
  if (!history.includes(id)) {
    history.push(id);
    localStorage.setItem(KEY_BENEFIT_HISTORY, JSON.stringify(history));
  }
};

export const clearBenefitHistory = (): void => {
  localStorage.removeItem(KEY_BENEFIT_HISTORY);
};

export const getStoredBenefit = (): StoredBenefit | null => {
  try {
    const stored = localStorage.getItem(KEY_CURRENT_BENEFIT);
    return stored ? JSON.parse(stored) : null;
  } catch { return null; }
};

export const setStoredBenefit = (data: any): void => {
  const today = new Date().toISOString().split('T')[0];
  const obj: StoredBenefit = { date: today, data };
  localStorage.setItem(KEY_CURRENT_BENEFIT, JSON.stringify(obj));
};

// --- Adhkar Favorites Helper ---

export const getFavoriteAdhkarIds = (): number[] => {
  try {
    const stored = localStorage.getItem(KEY_FAV_ADHKAR);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const toggleFavoriteAdhkar = (id: number): boolean => {
  const ids = getFavoriteAdhkarIds();
  const exists = ids.includes(id);
  
  let newIds;
  if (exists) {
    newIds = ids.filter(i => i !== id);
  } else {
    newIds = [...ids, id];
  }
  
  localStorage.setItem(KEY_FAV_ADHKAR, JSON.stringify(newIds));
  return !exists; 
};

export const isAdhkarFavorite = (id: number): boolean => {
  return getFavoriteAdhkarIds().includes(id);
};

// --- Custom Adhkar Helper ---

export const getCustomAdhkar = (): Zekr[] => {
  try {
    const stored = localStorage.getItem(KEY_CUSTOM_ADHKAR);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const addCustomAdhkar = (zekr: Omit<Zekr, 'id'>): void => {
  const list = getCustomAdhkar();
  const newZekr: Zekr = {
    ...zekr,
    id: Date.now(),
  };
  const newList = [newZekr, ...list];
  localStorage.setItem(KEY_CUSTOM_ADHKAR, JSON.stringify(newList));
};

export const updateCustomAdhkar = (id: number, updatedZekr: Partial<Omit<Zekr, 'id'>>): void => {
  const list = getCustomAdhkar();
  const index = list.findIndex(z => z.id === id);
  if (index !== -1) {
    list[index] = { ...list[index], ...updatedZekr };
    localStorage.setItem(KEY_CUSTOM_ADHKAR, JSON.stringify(list));
  }
};

export const deleteCustomAdhkar = (id: number): void => {
  const list = getCustomAdhkar();
  const newList = list.filter(z => z.id !== id);
  localStorage.setItem(KEY_CUSTOM_ADHKAR, JSON.stringify(newList));
};

// --- Custom Tasbih Helper ---

export const getCustomTasbihs = (): TasbihItem[] => {
  try {
    const stored = localStorage.getItem(KEY_CUSTOM_TASBIH);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const addCustomTasbih = (item: Omit<TasbihItem, 'id'>): void => {
  const list = getCustomTasbihs();
  const newItem: TasbihItem = {
    ...item,
    id: Date.now().toString(), 
  };
  const newList = [newItem, ...list];
  localStorage.setItem(KEY_CUSTOM_TASBIH, JSON.stringify(newList));
};

export const deleteCustomTasbih = (id: string): void => {
  const list = getCustomTasbihs();
  const newList = list.filter(t => t.id !== id);
  localStorage.setItem(KEY_CUSTOM_TASBIH, JSON.stringify(newList));
};

// --- Ayah Bookmarks Helper ---

export const getAyahBookmarks = (): AyahBookmark[] => {
  try {
    const stored = localStorage.getItem(KEY_BOOKMARKS_AYAH);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const toggleAyahBookmark = (bookmark: Omit<AyahBookmark, 'id'>): boolean => {
  const list = getAyahBookmarks();
  const index = list.findIndex(b => b.surahNumber === bookmark.surahNumber && b.ayahNumber === bookmark.ayahNumber);
  
  let newList;
  const wasAdded = index === -1;

  if (wasAdded) {
    const newBookmark: AyahBookmark = { ...bookmark, id: Date.now().toString() };
    newList = [newBookmark, ...list];
  } else {
    newList = list.filter((_, i) => i !== index);
  }
  
  localStorage.setItem(KEY_BOOKMARKS_AYAH, JSON.stringify(newList));
  return wasAdded;
};

export const isAyahBookmarked = (surahNumber: number, ayahNumber: number): boolean => {
  const list = getAyahBookmarks();
  return list.some(b => b.surahNumber === surahNumber && b.ayahNumber === ayahNumber);
};

export const deleteAyahBookmark = (id: string) => {
  const list = getAyahBookmarks();
  const newList = list.filter(b => b.id !== id);
  localStorage.setItem(KEY_BOOKMARKS_AYAH, JSON.stringify(newList));
};

// --- Page Bookmarks Helper ---

export const getPageBookmarks = (): PageBookmark[] => {
  try {
    const stored = localStorage.getItem(KEY_BOOKMARKS_PAGE);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const addPageBookmark = (surahName: string, pageNumber: number): void => {
  const list = getPageBookmarks();
  const existingIndex = list.findIndex(b => b.pageNumber === pageNumber);
  
  let newList = [...list];
  if (existingIndex !== -1) {
    newList.splice(existingIndex, 1);
  }

  const newBookmark: PageBookmark = {
    id: Date.now().toString(),
    surahName,
    pageNumber,
    timestamp: Date.now()
  };

  newList = [newBookmark, ...newList];
  localStorage.setItem(KEY_BOOKMARKS_PAGE, JSON.stringify(newList));
};

export const removePageBookmark = (pageNumber: number): void => {
  const list = getPageBookmarks();
  const newList = list.filter(b => b.pageNumber !== pageNumber);
  localStorage.setItem(KEY_BOOKMARKS_PAGE, JSON.stringify(newList));
};

export const isPageBookmarked = (pageNumber: number): boolean => {
  const list = getPageBookmarks();
  return list.some(b => b.pageNumber === pageNumber);
};

// --- Notes Helper ---

export const getNotes = (): Note[] => {
  try {
    const stored = localStorage.getItem(KEY_NOTES);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const saveNote = (note: Omit<Note, 'id'>): void => {
  const list = getNotes();
  const existingIndex = list.findIndex(n => n.surahNumber === note.surahNumber && n.ayahNumber === note.ayahNumber);
  
  let newList = [...list];
  if (existingIndex !== -1) {
    newList[existingIndex] = { ...newList[existingIndex], text: note.text, timestamp: Date.now() };
  } else {
    const newNote: Note = { ...note, id: Date.now().toString(), timestamp: Date.now() };
    newList = [newNote, ...newList];
  }
  
  localStorage.setItem(KEY_NOTES, JSON.stringify(newList));
};

export const deleteNote = (id: string): void => {
  const list = getNotes();
  const newList = list.filter(n => n.id !== id);
  localStorage.setItem(KEY_NOTES, JSON.stringify(newList));
};

export const getNoteForAyah = (surahNumber: number, ayahNumber: number): string | null => {
  const list = getNotes();
  const note = list.find(n => n.surahNumber === surahNumber && n.ayahNumber === ayahNumber);
  return note ? note.text : null;
};

// --- Settings Helpers ---

export const getStoredFontSize = (): number => {
  const size = localStorage.getItem(KEY_SETTINGS_FONT);
  return size ? parseInt(size) : 28; 
};

export const setStoredFontSize = (size: number): void => {
  localStorage.setItem(KEY_SETTINGS_FONT, size.toString());
};

export const getStoredReciter = (): string => {
  return localStorage.getItem(KEY_SETTINGS_RECITER) || 'ar.minshawi_murattal';
};

export const setStoredReciter = (id: string): void => {
  localStorage.setItem(KEY_SETTINGS_RECITER, id);
};

export const getStoredAzhan = (): string => {
  return localStorage.getItem(KEY_SETTINGS_AZHAN) || 'egy_abdulbasit'; // Default to Abdul Basit
};

export const setStoredAzhan = (id: string): void => {
  localStorage.setItem(KEY_SETTINGS_AZHAN, id);
};

// --- Notifications Helper ---

export const getNotifications = (): AppNotification[] => {
  try {
    const stored = localStorage.getItem(KEY_NOTIFICATIONS);
    return stored ? JSON.parse(stored) : [];
  } catch { return []; }
};

export const addNotification = (title: string, content: string, type: AppNotification['type'] = 'system'): void => {
  const list = getNotifications();
  
  const today = new Date().toDateString();
  const isDuplicate = list.some(n => 
    n.title === title && 
    new Date(n.timestamp).toDateString() === today &&
    (type !== 'reminder' || n.content === content)
  );

  if (isDuplicate) return;

  const newNote: AppNotification = {
    id: Date.now().toString(),
    title,
    content,
    timestamp: Date.now(),
    isRead: false,
    type
  };

  const newList = [newNote, ...list].slice(0, 50); 
  localStorage.setItem(KEY_NOTIFICATIONS, JSON.stringify(newList));
};

export const markNotificationsRead = (): void => {
  const list = getNotifications();
  const newList = list.map(n => ({ ...n, isRead: true }));
  localStorage.setItem(KEY_NOTIFICATIONS, JSON.stringify(newList));
};

export const clearNotifications = (): void => {
  localStorage.setItem(KEY_NOTIFICATIONS, JSON.stringify([]));
};

export const getUnreadCount = (): number => {
  return getNotifications().filter(n => !n.isRead).length;
};
