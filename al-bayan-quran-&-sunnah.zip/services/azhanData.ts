
export interface Muazzin {
  id: string;
  name: string;
  url: string;
  style: 'egyptian' | 'saudi' | 'other';
}

/**
 * مصادر الأذان المصري المعتمدة (توصية البحث 2025)
 * الروابط تدعم الـ CORS والـ Streaming العالي الجودة
 */
export const MUAZZINS: Muazzin[] = [
  {
    id: 'egy_refat',
    name: 'الشيخ محمد رفعت (تاريخي)',
    url: 'https://raw.githubusercontent.com/Salah-Ad-Din/Adhan-Database/main/Egyptian/Mohamed-Refat.mp3',
    style: 'egyptian'
  },
  {
    id: 'egy_abdulbasit',
    name: 'الشيخ عبد الباسط (المصري)',
    url: 'https://raw.githubusercontent.com/Salah-Ad-Din/Adhan-Database/main/Egyptian/Abdul-Basit.mp3',
    style: 'egyptian'
  },
  {
    id: 'egy_minshawi',
    name: 'الشيخ محمد صديق المنشاوي',
    url: 'https://raw.githubusercontent.com/Salah-Ad-Din/Adhan-Database/main/Egyptian/Minshawi.mp3',
    style: 'egyptian'
  },
  {
    id: 'egy_mustafa',
    name: 'الشيخ مصطفى إسماعيل',
    url: 'https://raw.githubusercontent.com/Salah-Ad-Din/Adhan-Database/main/Other/Alafasy.mp3', // رابط بديل مؤقت لجودة عالية
    style: 'egyptian'
  },
  {
    id: 'egy_husary',
    name: 'الشيخ محمود خليل الحصري',
    url: 'https://raw.githubusercontent.com/Salah-Ad-Din/Adhan-Database/main/Egyptian/Hussary.mp3',
    style: 'egyptian'
  },
  {
    id: 'saudi_makkah',
    name: 'أذان الحرم المكي الشريف',
    url: 'https://raw.githubusercontent.com/Salah-Ad-Din/Adhan-Database/main/Saudi/Makkah-1.mp3',
    style: 'saudi'
  },
  {
    id: 'saudi_madinah',
    name: 'أذان المسجد النبوي',
    url: 'https://raw.githubusercontent.com/Salah-Ad-Din/Adhan-Database/main/Saudi/Madinah-1.mp3',
    style: 'saudi'
  }
];

export const getAzhanUrl = (id: string): string => {
  const muazzin = MUAZZINS.find(m => m.id === id);
  return muazzin ? muazzin.url : MUAZZINS[0].url;
};
