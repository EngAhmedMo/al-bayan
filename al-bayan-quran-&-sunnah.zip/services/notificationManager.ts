
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';
import { addNotification } from './storage';
import { PrayerData } from '../types';

// IDs for fixed notifications
const ID_OFFSET_PRAYERS = 1000;
const ID_OFFSET_ADHKAR = 2000;
const ID_FRIDAY = 3001;
const ID_QIYAM = 3002;

export const requestNotificationPermission = async () => {
  try {
    if (Capacitor.isNativePlatform()) {
      const perm = await LocalNotifications.requestPermissions();
      if (perm.display === 'granted') {
        await LocalNotifications.createChannel({
          id: 'bayan_azhan',
          name: 'تنبيهات الصلاة',
          description: 'تنبيهات أوقات الصلاة بصوت الأذان',
          importance: 5,
          visibility: 1,
          sound: 'azhan.wav', // Native resource sound if available
          vibration: true,
        });
        await LocalNotifications.createChannel({
          id: 'bayan_alerts',
          name: 'تنبيهات البيان',
          description: 'تنبيهات الأذكار والمناسبات',
          importance: 3,
          visibility: 1,
          vibration: true,
        });
      }
    } else if ('Notification' in window) {
      await Notification.requestPermission();
    }
  } catch (e) {
    console.error("Error requesting permission:", e);
  }
};

const getPrayerMessage = (prayerName: string): { title: string, body: string } => {
  switch (prayerName) {
    case 'الفجر':
      return { title: 'صلاة الفجر', body: 'الصلاة خير من النوم.. حان الآن موعد صلاة الفجر' };
    case 'الظهر':
      return { title: 'صلاة الظهر', body: 'حان الآن موعد صلاة الظهر. "أرحنا بها يا بلال"' };
    case 'العصر':
      return { title: 'صلاة العصر', body: 'حافظوا على الصلوات والصلاة الوسطى. حان موعد صلاة العصر' };
    case 'المغرب':
      return { title: 'صلاة المغرب', body: 'اللهم هذا إقبال ليلك وإدبار نهارك وأصوات دعاتك فاغفر لي' };
    case 'العشاء':
      return { title: 'صلاة العشاء', body: 'حان الآن موعد صلاة العشاء. أثقل الصلاة على المنافقين' };
    default:
      return { title: `حان وقت صلاة ${prayerName}`, body: 'حي على الصلاة، حي على الفلاح' };
  }
};

export const scheduleAllNotifications = async (prayerData: PrayerData) => {
  if (!prayerData) return;

  try {
    const pending = await LocalNotifications.getPending();
    if (pending.notifications.length > 0) {
      await LocalNotifications.cancel(pending);
    }
  } catch (e) {
    console.warn("Could not clear pending notifications", e);
  }

  const timings = prayerData.timings;
  const notificationsToSchedule: any[] = [];

  // --- 1. Schedule Prayers (Salah) with Smart Text ---
  const prayers = [
    { name: 'الفجر', time: timings.Fajr, id: ID_OFFSET_PRAYERS + 1 },
    { name: 'الظهر', time: timings.Dhuhr, id: ID_OFFSET_PRAYERS + 2 },
    { name: 'العصر', time: timings.Asr, id: ID_OFFSET_PRAYERS + 3 },
    { name: 'المغرب', time: timings.Maghrib, id: ID_OFFSET_PRAYERS + 4 },
    { name: 'العشاء', time: timings.Isha, id: ID_OFFSET_PRAYERS + 5 },
  ];

  prayers.forEach(p => {
    const scheduleTime = parseTimeToday(p.time);
    
    // Only schedule if time is in the future today
    if (scheduleTime > new Date()) { 
      const msg = getPrayerMessage(p.name);
      
      notificationsToSchedule.push({
        id: p.id,
        title: msg.title,
        body: msg.body,
        schedule: { at: scheduleTime },
        channelId: 'bayan_azhan', // High priority channel
        sound: 'azhan.wav',
        smallIcon: 'ic_stat_moon', // Ensure you have a generated icon in Android res
        actionTypeId: '',
        extra: { type: 'prayer', name: p.name }
      });
    }
  });

  // --- 2. Schedule Adhkar (Smart Linking) ---
  const fajrTime = parseTimeToday(timings.Fajr);
  const morningAdhkarTime = new Date(fajrTime.getTime() + 25 * 60000); // 25 mins after Fajr
  
  if (morningAdhkarTime > new Date()) {
    notificationsToSchedule.push({
      id: ID_OFFSET_ADHKAR + 1,
      title: '🌞 أذكار الصباح',
      body: 'ابدأ يومك بذكر الله: «اللهم بك أصبحنا وبك أمسينا»',
      schedule: { at: morningAdhkarTime },
      channelId: 'bayan_alerts',
      extra: { type: 'adhkar', category: 'morning' }
    });
  }

  const asrTime = parseTimeToday(timings.Asr);
  const eveningAdhkarTime = new Date(asrTime.getTime() + 15 * 60000); // 15 mins after Asr
  
  if (eveningAdhkarTime > new Date()) {
    notificationsToSchedule.push({
      id: ID_OFFSET_ADHKAR + 2,
      title: '🌙 أذكار المساء',
      body: 'حصن نفسك: «أمسينا وأمسى الملك لله»',
      schedule: { at: eveningAdhkarTime },
      channelId: 'bayan_alerts',
      extra: { type: 'adhkar', category: 'evening' }
    });
  }

  // --- 3. Qiyam Al-Layl (Last Third of Night) ---
  const maghribTime = parseTimeToday(timings.Maghrib);
  // Approx tomorrow Fajr
  const fajrTomorrow = new Date(fajrTime.getTime() + 24 * 60 * 60 * 1000); 
  const nightDuration = fajrTomorrow.getTime() - maghribTime.getTime();
  const lastThirdStart = new Date(maghribTime.getTime() + (nightDuration * 2 / 3));
  
  // Only schedule if it's tonight (before midnight rollover logic handled by date comparison)
  // For simplicity, we schedule it relative to the fetched Fajr if it hasn't passed
  // Or simply schedule it for 3:00 AM fixed if calculation is complex, but let's stick to calculation
  // Since we fetch prayer times daily, we can schedule for "Tonight"
  
  // Safe logic: Schedule 45 mins before tomorrow's Fajr
  const qiyamTime = new Date(fajrTime.getTime()); 
  // If Fajr passed today, target tomorrow's Fajr
  if (new Date() > fajrTime) {
      qiyamTime.setDate(qiyamTime.getDate() + 1);
  }
  qiyamTime.setMinutes(qiyamTime.getMinutes() - 45);

  notificationsToSchedule.push({
      id: ID_QIYAM,
      title: 'قيام الليل',
      body: 'ركعتان في جوف الليل خير من الدنيا وما فيها. هل من داعٍ فأستجيب له؟',
      schedule: { at: qiyamTime },
      channelId: 'bayan_alerts',
      extra: { type: 'qiyam' }
  });

  // --- 4. Friday Reminder ---
  const now = new Date();
  const nextFriday = new Date();
  nextFriday.setDate(now.getDate() + ((7 - now.getDay() + 5) % 7)); 
  nextFriday.setHours(11, 0, 0, 0); // 11:00 AM
  if (nextFriday < now) nextFriday.setDate(nextFriday.getDate() + 7);

  notificationsToSchedule.push({
      id: ID_FRIDAY,
      title: 'يوم الجمعة 🕌',
      body: 'لا تنس سورة الكهف والصلاة على النبي ﷺ وساعة الاستجابة.',
      schedule: { at: nextFriday, repeats: true, every: 'week' },
      channelId: 'bayan_alerts',
      extra: { type: 'friday' }
  });

  if (Capacitor.isNativePlatform()) {
    try {
        await LocalNotifications.schedule({ notifications: notificationsToSchedule });
        console.log(`Scheduled ${notificationsToSchedule.length} notifications`);
    } catch (e) {
        console.error("Failed to schedule native notifications", e);
    }
  }
};

const parseTimeToday = (timeStr: string): Date => {
  const [hours, minutes] = timeStr.split(':').map(Number);
  const date = new Date();
  date.setHours(hours, minutes, 0, 0);
  return date;
};

if (Capacitor.isNativePlatform()) {
    LocalNotifications.addListener('localNotificationReceived', (notification) => {
        addNotification(notification.title, notification.body, 'reminder');
    });
}
