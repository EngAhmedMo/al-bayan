
import { SURAH_AYAH_COUNTS } from './quranStaticData';
import { getAudioUrl } from './api';
import { getAzhanUrl } from './azhanData';

const CACHE_NAME = 'quran-audio-v1';
const AZHAN_CACHE_NAME = 'azhan-audio-v1';

// --- QURAN AUDIO FUNCTIONS ---

export const getSurahAyahRange = (surahNumber: number): { start: number; end: number } => {
  let start = 1;
  for (let i = 1; i < surahNumber; i++) {
    start += SURAH_AYAH_COUNTS[i];
  }
  const end = start + SURAH_AYAH_COUNTS[surahNumber] - 1;
  return { start, end };
};

export const isSurahDownloaded = async (reciterId: string, surahNumber: number): Promise<boolean> => {
  if (!('caches' in window)) return false;
  const cache = await caches.open(CACHE_NAME);
  const { start, end } = getSurahAyahRange(surahNumber);
  const checkAyahs = [start, Math.floor((start + end) / 2), end];
  try {
    const results = await Promise.all(
      checkAyahs.map(id => cache.match(getAudioUrl(reciterId, id)))
    );
    return results.every(res => res !== undefined);
  } catch (e) { return false; }
};

export const downloadSurah = async (
  reciterId: string, 
  surahNumber: number, 
  onProgress: (percent: number) => void,
  signal?: AbortSignal 
): Promise<void> => {
  if (!('caches' in window)) throw new Error("التخزين غير مدعوم");
  const cache = await caches.open(CACHE_NAME);
  const { start, end } = getSurahAyahRange(surahNumber);
  const total = end - start + 1;
  let completed = 0;
  const urls: string[] = [];
  for (let i = start; i <= end; i++) urls.push(getAudioUrl(reciterId, i));

  const BATCH_SIZE = 5;
  for (let i = 0; i < urls.length; i += BATCH_SIZE) {
    if (signal?.aborted) throw new Error("ABORTED");
    const batch = urls.slice(i, i + BATCH_SIZE);
    await Promise.all(batch.map(async (url) => {
      try {
        const match = await cache.match(url);
        if (match) { completed++; return; }
        const response = await fetch(url, { mode: 'cors', signal });
        if (response.ok) {
          const blob = await response.blob();
          const headers = new Headers(response.headers);
          headers.set('Content-Type', 'audio/mpeg');
          await cache.put(url, new Response(blob, { status: 200, headers }));
        }
      } catch (e) {} finally { completed++; onProgress(Math.round((completed / total) * 100)); }
    }));
  }
};

export const deleteSurahFromCache = async (reciterId: string, surahNumber: number): Promise<void> => {
  if (!('caches' in window)) return;
  const cache = await caches.open(CACHE_NAME);
  const { start, end } = getSurahAyahRange(surahNumber);
  for (let i = start; i <= end; i++) await cache.delete(getAudioUrl(reciterId, i));
};

export const getPlayableUrl = async (reciterId: string, globalAyahId: number): Promise<string> => {
  const networkUrl = getAudioUrl(reciterId, globalAyahId);
  if (!('caches' in window)) return networkUrl;
  try {
    const cache = await caches.open(CACHE_NAME);
    const cachedResponse = await cache.match(networkUrl);
    if (cachedResponse) {
      const blob = await cachedResponse.blob();
      return URL.createObjectURL(blob);
    }
  } catch (e) {}
  return networkUrl;
};

// --- AZHAN AUDIO FUNCTIONS (PRO GRADE) ---

export const isAzhanDownloaded = async (azhanId: string): Promise<boolean> => {
  if (!('caches' in window)) return false;
  try {
    const cache = await caches.open(AZHAN_CACHE_NAME);
    const url = getAzhanUrl(azhanId);
    const response = await cache.match(url);
    return response !== undefined;
  } catch { return false; }
};

/**
 * محرك تحميل احترافي يستخدم الـ Streams لضمان عدم تلف الملفات
 */
export const downloadAzhan = async (
  azhanId: string, 
  onProgress?: (percent: number) => void,
  signal?: AbortSignal
): Promise<void> => {
  if (!('caches' in window)) throw new Error("التخزين غير مدعوم");
  
  const cache = await caches.open(AZHAN_CACHE_NAME);
  const url = getAzhanUrl(azhanId);
  
  const response = await fetch(url, { mode: 'cors', signal });
  if (!response.ok) throw new Error('فشل الوصول للملف');
  if (!response.body) throw new Error('ReadableStream not supported');

  const contentLength = response.headers.get('Content-Length');
  const total = contentLength ? parseInt(contentLength, 10) : 0;
  
  let loaded = 0;
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      loaded += value.length;
      if (total > 0 && onProgress) {
          onProgress(Math.round((loaded / total) * 100));
      }
    }
  }

  const blob = new Blob(chunks, { type: 'audio/mpeg' });
  
  // بناء استجابة محكمة يدوياً لضمان الاستقرار في وضع الأوفلاين
  const manualResponse = new Response(blob, {
      status: 200,
      statusText: 'OK',
      headers: {
        'Content-Type': 'audio/mpeg',
        'Content-Length': blob.size.toString(),
        'Cache-Control': 'public, max-age=31536000'
      }
  });

  await cache.put(url, manualResponse);
};

export const deleteAzhanFromCache = async (azhanId: string): Promise<void> => {
  if (!('caches' in window)) return;
  const cache = await caches.open(AZHAN_CACHE_NAME);
  await cache.delete(getAzhanUrl(azhanId));
};

export const getPlayableAzhanUrl = async (azhanId: string): Promise<string> => {
  const networkUrl = getAzhanUrl(azhanId);
  if (!('caches' in window)) return networkUrl;

  try {
    const cache = await caches.open(AZHAN_CACHE_NAME);
    const cachedResponse = await cache.match(networkUrl);
    if (cachedResponse) {
      const blob = await cachedResponse.blob();
      // استخدام Blob URL يحل مشاكل الـ CORS أثناء التشغيل
      return URL.createObjectURL(blob);
    }
  } catch (e) {
      console.error("Cache retrieval error", e);
  }
  return networkUrl;
};

export const downloadQueueProcessor = async (reciterId: string, queue: number[], onSurahComplete: (n: number) => void, onTotalProgress: (c: number) => void, initialCompletedCount: number, signal: AbortSignal): Promise<void> => {
  let completedSoFar = initialCompletedCount;
  for (const surahNum of queue) {
    if (signal.aborted) throw new Error("PAUSED");
    try {
      await downloadSurah(reciterId, surahNum, () => {}, signal);
      completedSoFar++;
      onSurahComplete(surahNum);
      onTotalProgress(completedSoFar);
    } catch (e: any) { if (e.name === 'AbortError') throw new Error("PAUSED"); }
  }
};

export const deleteAllSurahs = async (reciterId: string): Promise<void> => {
  if (!('caches' in window)) return;
  const totalSurahs = 114;
  for (let i = 1; i <= totalSurahs; i++) await deleteSurahFromCache(reciterId, i);
};
