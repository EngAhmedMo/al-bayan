
import { Hadith, HadithBook, Surah, Ayah, TafsirResponse, QuranSearchResult, Reciter, PrayerData } from '../types';
import { normalizeArabic, stripDiacriticsAndPrefixes, toArabicDigits } from './normalization';
import { getBenefitHistory, addToBenefitHistory, clearBenefitHistory } from './storage';
import { SURAH_AYAH_COUNTS, TOTAL_QURAN_AYAHS, getMetadataFromGlobalAyah } from './quranStaticData';
import { HADITH_DB } from './hadithData'; // Import the local DB

// --- Quran Service ---

const API_BASE = 'https://api.alquran.cloud/v1';
const surahCache: Surah[] = [];
// Updated page cache to include reciter ID in key to avoid stale audio
const pageCache: Record<string, Ayah[]> = {}; 

// Cache for full Quran text to enable fuzzy search client-side
let fullQuranCache: { surah: Surah; ayah: Ayah }[] | null = null;

// Extended Reciter Interface
export interface ReciterWithImage extends Reciter {
  image?: string;
  source: 'islamic-network' | 'everyayah'; // Support multiple backends
  folder?: string; // For EveryAyah backend
  bitrate?: number; // For Islamic Network backend
}

// FIXED: Replaced broken Khalid Al-Jaleel with Mishary Alafasy (Stable Source)
export const RECITERS: ReciterWithImage[] = [
  { 
    id: 'ar.minshawi_murattal', 
    name: 'المنشاوي (مرتل)', 
    image: 'https://static.qurancentral.com/authors/muhammad-siddiq-al-minshawi.jpg', 
    source: 'everyayah', 
    folder: 'Minshawy_Murattal_128kbps'
  },
  { 
    id: 'ar.minshawi', 
    name: 'المنشاوي (مجود)', 
    image: 'https://static.qurancentral.com/authors/muhammad-siddiq-al-minshawi.jpg', 
    source: 'everyayah', 
    folder: 'Minshawy_Mujawwad_192kbps'
  },
  { 
    id: 'ar.alafasy', 
    name: 'مشاري العفاسي', 
    image: 'https://static.qurancentral.com/authors/mishary-rashid-alafasy.jpg', 
    source: 'everyayah', 
    folder: 'Alafasy_128kbps' 
  },
  { 
    id: 'ar.yasseraddosari', 
    name: 'ياسر الدوسري', 
    image: 'https://static.qurancentral.com/authors/yasser-al-dosari.jpg', 
    source: 'everyayah', 
    folder: 'Yasser_Ad-Dussary_128kbps' 
  },
  { 
    id: 'ar.saudshuraim', 
    name: 'سعود الشريم', 
    image: 'https://static.qurancentral.com/authors/saud-al-shuraim.jpg', 
    source: 'everyayah', 
    folder: 'Saood_ash-Shuraym_128kbps' 
  },
  { 
    id: 'ar.mahermuaiqly', 
    name: 'ماهر المعيقلي', 
    image: 'https://static.qurancentral.com/authors/maher-al-mueaqly.jpg', 
    source: 'everyayah', 
    folder: 'MaherAlMuaiqly128kbps' 
  },
  { 
    id: 'ar.hudhaify', 
    name: 'علي الحذيفي', 
    image: 'https://static.qurancentral.com/authors/ali-al-huthaify.jpg', 
    source: 'everyayah', 
    folder: 'Hudhaify_128kbps' 
  },
  { 
    id: 'ar.faresabbad', 
    name: 'فارس عباد', 
    image: 'https://static.qurancentral.com/authors/fares-abbad.jpg', 
    source: 'everyayah', 
    folder: 'Fares_Abbad_64kbps' 
  },
  { 
    id: 'ar.abdulbasitmurattal', 
    name: 'عبد الباسط (مرتل)', 
    image: 'https://static.qurancentral.com/authors/abdul-basit-abdus-samad.jpg', 
    source: 'everyayah', 
    folder: 'Abdul_Basit_Murattal_192kbps' 
  },
  { 
    id: 'ar.husary', 
    name: 'محمود خليل الحصري', 
    image: 'https://static.qurancentral.com/authors/mahmoud-khalil-al-hussary.jpg', 
    source: 'everyayah', 
    folder: 'Husary_128kbps' 
  },
  { 
    id: 'ar.husary_mujawwad', 
    name: 'الحصري (مجود)', 
    image: 'https://static.qurancentral.com/authors/mahmoud-khalil-al-hussary.jpg', 
    source: 'everyayah', 
    folder: 'Husary_Mujawwad_128kbps' 
  },
  { 
    id: 'ar.ahmedajamy', 
    name: 'أحمد العجمي', 
    image: 'https://static.qurancentral.com/authors/ahmed-al-ajmi.jpg', 
    source: 'everyayah', 
    folder: 'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net' 
  },
  { 
    id: 'ar.shaatree', 
    name: 'أبو بكر الشاطري', 
    image: 'https://static.qurancentral.com/authors/abu-bakr-al-shatri.jpg', 
    source: 'everyayah', 
    folder: 'Abu_Bakr_Ash-Shaatree_128kbps' 
  },
  { 
    id: 'ar.mustafaismail', 
    name: 'مصطفى إسماعيل', 
    image: 'https://static.qurancentral.com/authors/mustafa-ismail.jpg', 
    source: 'everyayah', 
    folder: 'Mustafa_Ismail_48kbps' 
  }
];

// Helper to construct Audio URL based on reciter config
export const getAudioUrl = (reciterId: string, globalAyahNumber: number): string => {
  // Ensure we have a valid ID, default to Minshawi Murattal
  const targetId = reciterId || 'ar.minshawi_murattal';
  
  const reciter = RECITERS.find(r => r.id === targetId);
  const activeReciter = reciter || RECITERS[0]; 

  if (activeReciter.source === 'everyayah' && activeReciter.folder) {
    // EveryAyah logic: requires padded Surah (001) and Ayah (001) numbers
    const { surahNumber, ayahInSurah } = getMetadataFromGlobalAyah(globalAyahNumber);
    const s = surahNumber.toString().padStart(3, '0');
    const a = ayahInSurah.toString().padStart(3, '0');
    return `https://everyayah.com/data/${activeReciter.folder}/${s}${a}.mp3`;
  } else {
    // Islamic Network logic fallback (if any reciter uses it)
    const bitrate = activeReciter.bitrate || 64;
    return `https://cdn.islamic.network/quran/audio/${bitrate}/${activeReciter.id}/${globalAyahNumber}.mp3`;
  }
};

export const fetchSurahs = async (): Promise<Surah[]> => {
  if (surahCache.length > 0) return surahCache;
  try {
    const res = await fetch(`${API_BASE}/surah`);
    const data = await res.json();
    if (data.code === 200) {
      surahCache.push(...data.data);
      return data.data;
    }
  } catch (e) { console.error("Failed to fetch Surahs", e); }
  return [];
};

export const fetchPage = async (pageNumber: number, reciterId: string = 'ar.minshawi_murattal'): Promise<Ayah[]> => {
  // Logic Fix: Pages are text content, they don't depend on Reciter ID.
  // However, we construct the 'audio' property on the fly.
  // To avoid caching issues where page X is cached with Reciter A, and then requested for Reciter B,
  // we include reciterId in the cache key.
  const cacheKey = `${pageNumber}-${reciterId}`;
  if (pageCache[cacheKey]) return pageCache[cacheKey];
  
  try {
    const res = await fetch(`${API_BASE}/page/${pageNumber}/quran-uthmani`); 
    const data = await res.json();
    if (data.code === 200) {
      const ayahs: Ayah[] = data.data.ayahs.map((a: any) => ({
        ...a,
        audio: getAudioUrl(reciterId, a.number)
      }));
      pageCache[cacheKey] = ayahs;
      return ayahs;
    }
  } catch (e) { console.error(`Failed to fetch page ${pageNumber}`, e); }
  return [];
};

export const fetchTafsir = async (surahNumber: number, ayahNumberInSurah: number): Promise<TafsirResponse | null> => {
  try {
    const res = await fetch(`${API_BASE}/ayah/${surahNumber}:${ayahNumberInSurah}/ar.muyassar`);
    const data = await res.json();
    if (data.code === 200 && data.data) return data.data[0] || data.data; 
  } catch (e) { console.error("Failed to fetch Tafsir", e); }
  return null;
};

export const fetchPrayerTimes = async (lat: number, lng: number): Promise<PrayerData | null> => {
  try {
    const date = Math.floor(Date.now() / 1000);
    const res = await fetch(`https://api.aladhan.com/v1/timings/${date}?latitude=${lat}&longitude=${lng}&method=4`);
    const json = await res.json();
    
    if (json.code === 200 && json.data) {
      return json.data;
    }
  } catch (e) {
    console.error("Failed to fetch prayer times", e);
  }
  return null;
};

// --- Daily Benefit Logic ---
export interface DailyBenefit {
  ayah: Ayah;
  tafsir: string;
  surahName: string;
  id: string; // Unique ID (surah:ayah)
}

const FALLBACK_BENEFITS: DailyBenefit[] = [
  {
    id: "39:53",
    ayah: { number: 1, text: "قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَى أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ ۚ إِنَّ اللَّهَ يَغْفِرُ الذُّنُوبَ جَمِيعًا ۚ إِنَّهُ هُوَ الْغَفُورُ الرَّحِيمُ", numberInSurah: 53, juz: 24, manzil: 6, page: 464, ruku: 4, hizbQuarter: 3, sajda: false },
    surahName: "سورة الزمر",
    tafsir: "قل -أيها الرسول- لعبادي الذين تمادَوا في المعاصي، وأسرفوا على أنفسهم بإتيان ما يوبقها: لا تيأسوا من رحمة الله؛ لكثرة ذنوبكم، إن الله يغفر الذنوب جميعًا لمن تاب منها ورجع عنها مهما كانت، إنه هو الغفور لذنوب التائبين من عباده، الرحيم بهم."
  },
];

const getUniqueRandomCoordinate = (): { surah: number, ayah: number } | null => {
  const history = getBenefitHistory();
  if (history.length >= TOTAL_QURAN_AYAHS) {
    clearBenefitHistory();
  }
  for (let i = 0; i < 50; i++) {
    const surah = Math.floor(Math.random() * 114) + 1;
    const maxAyah = SURAH_AYAH_COUNTS[surah] || 1;
    const ayah = Math.floor(Math.random() * maxAyah) + 1;
    const id = `${surah}:${ayah}`;
    if (!history.includes(id)) return { surah, ayah };
  }
  return { surah: 1, ayah: 1 };
};

export const fetchRandomBenefit = async (): Promise<DailyBenefit> => {
  try {
    const coords = getUniqueRandomCoordinate();
    if (!coords) throw new Error("No unique verses available");

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000); 

    const ayahRes = await fetch(`${API_BASE}/ayah/${coords.surah}:${coords.ayah}/quran-uthmani`, { signal: controller.signal });
    const ayahJson = await ayahRes.json();

    if (ayahJson.code !== 200 || !ayahJson.data) throw new Error('API Error fetching Ayah');
    const ayahData = ayahJson.data;

    const tafsirRes = await fetch(`${API_BASE}/ayah/${coords.surah}:${coords.ayah}/ar.muyassar`, { signal: controller.signal });
    const tafsirJson = await tafsirRes.json();
    
    clearTimeout(timeoutId);

    const tafsirText = (tafsirJson.code === 200 && tafsirJson.data) 
      ? (tafsirJson.data.text || tafsirJson.data[0]?.text || 'التفسير غير متاح حالياً') 
      : 'التفسير غير متاح حالياً';

    const benefit: DailyBenefit = {
      id: `${coords.surah}:${coords.ayah}`,
      ayah: ayahData,
      surahName: ayahData.surah.name,
      tafsir: tafsirText
    };

    addToBenefitHistory(benefit.id);
    return benefit;

  } catch (e) {
    const randomIndex = Math.floor(Math.random() * FALLBACK_BENEFITS.length);
    return FALLBACK_BENEFITS[randomIndex];
  }
};

/**
 * STRICT SEARCH ALGORITHM
 * 
 * Rules:
 * 1. Match Exact Word.
 * 2. Match Word with standard Prefix (Wa, Fa, Al...).
 * 3. Match Word with standard Suffix (Plural markers, pronouns).
 * 4. REJECT substring matches in the middle of words (e.g. "amn" in "qawwamuna").
 */

// Common Arabic Prefixes that attach to words
const ARABIC_PREFIXES = [
  'ال', 'و', 'ف', 'ب', 'ك', 'ل', 'لل', 
  'وال', 'فال', 'كال', 'بال', 'ول', 'فل', 'وب', 'وك', 'فس', 'وس', 'أف', 'أو'
];

// Common Arabic Suffixes (Pronouns, Plurals, Taa Marbuta)
const ARABIC_SUFFIXES = [
  'ة', 'ه', 'ها', 'هم', 'هما', 'هن', // Pronouns / Taa Marbuta
  'ك', 'كم', 'كما', 'كن', // Pronouns (Ka)
  'نا', 'ي', 'ني', // Pronouns (We, Me)
  'ون', 'ين', 'ان', 'ات', // Plurals / Duals
  'وا', 'تم', 'تما', 'تن', // Verbs
  'ت'
];

/**
 * Checks if a word from the Ayah matches the Query Term using strict morphological rules.
 */
export const isStrictMatch = (ayahWord: string, queryTerm: string): boolean => {
  const normAyah = normalizeArabic(ayahWord);
  const normQuery = normalizeArabic(queryTerm);

  // 1. Exact Match
  if (normAyah === normQuery) return true;

  // 2. Remove Prefixes from Ayah Word and check if it STARTS with query
  // This prevents "Amn" matching inside "Qawwamuna" (middle match)
  let strippedAyah = normAyah;
  
  // Try to strip one valid prefix (longest match first)
  // We iterate prefixes sorted by length desc to catch "wal" before "w"
  const sortedPrefixes = [...ARABIC_PREFIXES].sort((a, b) => b.length - a.length);
  
  for (const prefix of sortedPrefixes) {
    if (strippedAyah.startsWith(prefix)) {
      strippedAyah = strippedAyah.slice(prefix.length);
      break; // Only strip the first valid prefix group found
    }
  }

  // After stripping prefix, does it match exactly?
  if (strippedAyah === normQuery) return true;

  // Does it START with the query? (e.g. Ayah: "Amanu", Query: "Amn")
  if (strippedAyah.startsWith(normQuery)) {
    // If it starts with the query, the REMAINDER must be a valid suffix.
    // This prevents "Jinn" matching "Jannah" (unless Taa Marbuta is considered a suffix, which is acceptable).
    const remainder = strippedAyah.slice(normQuery.length);
    
    // If remainder is empty, it's a match (already covered above).
    if (remainder.length === 0) return true;

    // Check if remainder is a valid suffix
    // We sort suffixes by length desc to match complex suffixes first if needed
    const sortedSuffixes = [...ARABIC_SUFFIXES].sort((a, b) => b.length - a.length);
    const isValidSuffix = sortedSuffixes.some(s => s === remainder);

    return isValidSuffix;
  }

  return false;
};

export const searchQuranText = async (query: string): Promise<QuranSearchResult[]> => {
  const normalizedQuery = normalizeArabic(query);
  if (!normalizedQuery) return [];

  // Split query into distinct terms
  const queryTerms = normalizedQuery.split(/\s+/).filter(t => t.length > 0);

  if (!fullQuranCache) {
    try {
      const res = await fetch(`${API_BASE}/quran/quran-simple-clean`);
      const data = await res.json();
      if (data.code === 200 && data.data && data.data.surahs) {
        fullQuranCache = [];
        data.data.surahs.forEach((surah: any) => {
          const surahMeta = { ...surah, ayahs: undefined };
          surah.ayahs.forEach((ayah: any) => {
            fullQuranCache!.push({
              surah: surahMeta,
              ayah: { ...ayah, page: ayah.page || -1 }
            });
          });
        });
      }
    } catch (e) { console.error("Failed to load full quran for search", e); }
  }

  if (fullQuranCache) {
    const results: QuranSearchResult[] = [];
    
    for (const item of fullQuranCache) {
      const ayahWords = item.ayah.text.split(/\s+/);

      // Check: Are ALL query terms present in this Ayah using STRICT matching?
      const isMatch = queryTerms.every(qTerm => {
        return ayahWords.some(ayahWord => isStrictMatch(ayahWord, qTerm));
      });

      if (isMatch) {
        // Determine Match Type
        const normalizedAyah = normalizeArabic(item.ayah.text);
        const isExactPhrase = normalizedAyah.includes(normalizedQuery);
        
        results.push({ 
          surah: item.surah, 
          ayah: item.ayah, 
          matchType: isExactPhrase ? 'exact' : 'partial' 
        });
      }
    }
    return results;
  }
  return [];
};

// --- Hadith Service --- (Existing code remains)
const searchDorarDirect = async (query: string): Promise<Hadith[]> => {
  try {
    const targetUrl = `https://dorar.net/dorar_api.json?skey=${encodeURIComponent(query)}`;
    const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(targetUrl)}`;
    
    const response = await fetch(proxyUrl);
    if (!response.ok) throw new Error("Proxy connection failed");
    
    const data = await response.json();
    if (!data.ahadith) return [];

    const parser = new DOMParser();
    // const doc = parser.parseFromString(data.ahadith, 'text/html'); // Unused
    const results: Hadith[] = [];

    const entries = data.ahadith.split(/--------------/g);

    entries.forEach((entryHtml: string, idx: number) => {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = entryHtml;
        const entryText = tempDiv.innerText.trim();
        
        if (entryText.length < 20) return;

        const rawiMatch = entryText.match(/الراوي:\s*([^\n\r]+)/);
        const mohdithMatch = entryText.match(/المحدث:\s*([^\n\r]+)/);
        const sourceMatch = entryText.match(/المصدر:\s*([^\n\r]+)/);
        const gradeMatch = entryText.match(/خلاصة حكم المحدث:\s*([^\n\r]+)/);
        
        let body = entryText.split(/الراوي:/)[0].trim();
        body = body.replace(/^\d+\s*-\s*/, '').replace(/^"/, '').replace(/"$/, '').trim();

        if (body && rawiMatch) {
            results.push({
                id: `dorar_${Date.now()}_${idx}`,
                book: HadithBook.ALL,
                text: body,
                sourceName: sourceMatch ? sourceMatch[1].trim() : 'الموسوعة الحديثية',
                chapter: `الراوي: ${rawiMatch[1].trim()}`,
                explanation: gradeMatch ? `حكم المحدث: ${gradeMatch[1].trim()} | المحدث: ${mohdithMatch ? mohdithMatch[1].trim() : ''}` : undefined,
                number: 0
            });
        }
    });

    return results;

  } catch (e) {
    console.warn("Dorar Search Failed:", e);
    return [];
  }
};

const fetchBooksFromGading = async (bookId: string, limit: number = 20): Promise<Hadith[]> => {
  try {
    const bookMap: Record<string, string> = {
      [HadithBook.BUKHARI]: 'bukhari',
      [HadithBook.MUSLIM]: 'muslim',
      [HadithBook.NAWAWI]: 'nawawi',
      [HadithBook.RIYAD]: 'riyad',
    };

    const apiBookId = bookMap[bookId];
    if (!apiBookId) return []; 

    const url = `https://api.hadith.gading.dev/books/${apiBookId}?range=1-${limit}`;
    const res = await fetch(url);
    const json = await res.json();

    if (json.code === 200 && json.data && json.data.hadiths) {
      return json.data.hadiths.map((h: any) => ({
        id: `${apiBookId}_${h.number}`,
        book: bookId as HadithBook,
        text: h.arab,
        sourceName: json.data.name || 'كتاب الحديث',
        number: h.number,
        chapter: `حديث رقم ${h.number}`,
        explanation: '' 
      }));
    }
  } catch (e) {
    console.warn("Gading API Failed", e);
  }
  return [];
};

export const searchHadith = async (query: string, book: HadithBook): Promise<Hadith[]> => {
  if (query.trim().length > 1) {
     const results = await searchDorarDirect(query);
     if (results.length === 0) {
        const normalizedQuery = normalizeArabic(query);
        return HADITH_DB.filter(h => normalizeArabic(h.text).includes(normalizedQuery));
     }
     return results;
  }

  if (book !== HadithBook.ALL) {
     if (book === HadithBook.BUKHARI || book === HadithBook.MUSLIM) {
        const onlineResults = await fetchBooksFromGading(book);
        if (onlineResults.length > 0) return onlineResults;
     }
     return HADITH_DB.filter(h => h.book === book);
  }

  return [];
};
