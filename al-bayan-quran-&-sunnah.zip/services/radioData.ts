
import { RadioStation } from '../types';

export const RADIO_STATIONS: RadioStation[] = [
  // --- إذاعات الحرمين والقاهرة ---
  {
    id: 'cairo_quran',
    name: 'إذاعة القرآن الكريم - القاهرة',
    url: [
      'https://stream.radiojar.com/8s5u5tpdtwzuv',
      'https://icecast.omnea.com.sa:8000/qurancairo',
      'https://n02.radiojar.com/8s5u5tpdtwzuv'
    ],
    category: 'cairo'
  },
  {
    id: 'makkah_live',
    name: 'إذاعة القرآن الكريم - مكة المكرمة',
    url: [
        'https://stream.radiojar.com/0tpy1h0kxtzuv',
        'https://backup.qurango.net/radio/makkah',
        'https://qurango.net/radio/makkah'
    ],
    category: 'quran'
  },
  
  // --- إذاعات القراء المشاهير (تم إضافة روابط احتياطية لكل قارئ) ---
  {
    id: 'minshawi_radio',
    name: 'المنشاوي (المصحف المرتل)',
    url: [
        'https://qurango.net/radio/mohammed_siddiq_alminshawi',
        'https://backup.qurango.net/radio/mohammed_siddiq_alminshawi',
        'https://server11.mp3quran.net/radios/mohammed_siddiq_alminshawi'
    ],
    category: 'reciters'
  },
  {
    id: 'minshawi_mujawwad_radio',
    name: 'المنشاوي (المصحف المجود)',
    url: [
        'https://qurango.net/radio/mohammed_siddiq_alminshawi_mojawwad',
        'https://backup.qurango.net/radio/mohammed_siddiq_alminshawi_mojawwad',
        'https://server11.mp3quran.net/radios/mohammed_siddiq_alminshawi_mojawwad'
    ],
    category: 'reciters'
  },
  {
    id: 'abdulbasit_warsh',
    name: 'عبدالباسط (ورش عن نافع)',
    url: [
        'https://qurango.net/radio/abdulbasit_abdulsamad_warsh',
        'https://backup.qurango.net/radio/abdulbasit_abdulsamad_warsh',
        'https://server12.mp3quran.net/radios/abdulbasit_abdulsamad_warsh'
    ],
    category: 'reciters'
  },
  {
    id: 'abdulbasit_mujawwad',
    name: 'عبدالباسط (المصحف المجود)',
    url: [
        'https://qurango.net/radio/abdulbasit_abdulsamad_mojawwad',
        'https://backup.qurango.net/radio/abdulbasit_abdulsamad_mojawwad',
        'https://server10.mp3quran.net/radios/abdulbasit_abdulsamad_mojawwad'
    ],
    category: 'reciters'
  },
  {
    id: 'mustafa_ismail',
    name: 'مصطفى إسماعيل (تلاوات نادرة ومجودة)',
    url: [
        'https://qurango.net/radio/mustafa_ismail',
        'https://backup.qurango.net/radio/mustafa_ismail',
        'https://server12.mp3quran.net/radios/mustafa_ismail'
    ],
    category: 'reciters'
  },
  {
    id: 'husary_radio',
    name: 'محمود خليل الحصري',
    url: [
        'https://qurango.net/radio/mahmoud_khalil_alhussary',
        'https://backup.qurango.net/radio/mahmoud_khalil_alhussary',
        'https://server13.mp3quran.net/radios/mahmoud_khalil_alhussary'
    ],
    category: 'reciters'
  },
  {
    id: 'alafasy_radio',
    name: 'مشاري العفاسي',
    url: [
        'https://qurango.net/radio/mishary_alafasi',
        'https://backup.qurango.net/radio/mishary_alafasi',
        'https://server10.mp3quran.net/radios/mishary_alafasi'
    ],
    category: 'reciters'
  },
  {
    id: 'shuraim_radio',
    name: 'سعود الشريم',
    url: [
        'https://qurango.net/radio/saud_alshuraim',
        'https://backup.qurango.net/radio/saud_alshuraim',
        'https://server11.mp3quran.net/radios/saud_alshuraim'
    ],
    category: 'reciters'
  },
  {
    id: 'sudais_radio',
    name: 'عبدالرحمن السديس',
    url: [
        'https://qurango.net/radio/abdulrahman_alsudaes',
        'https://backup.qurango.net/radio/abdulrahman_alsudaes',
        'https://server11.mp3quran.net/radios/abdulrahman_alsudaes'
    ],
    category: 'reciters'
  },
  {
    id: 'maher_radio',
    name: 'ماهر المعيقلي',
    url: [
        'https://qurango.net/radio/maher_almaikulai',
        'https://backup.qurango.net/radio/maher_almaikulai',
        'https://server12.mp3quran.net/radios/maher_almaikulai'
    ],
    category: 'reciters'
  },
  {
    id: 'ajamy_radio',
    name: 'أحمد العجمي',
    url: [
        'https://qurango.net/radio/ahmad_alajmy',
        'https://backup.qurango.net/radio/ahmad_alajmy',
        'https://server10.mp3quran.net/radios/ahmad_alajmy'
    ],
    category: 'reciters'
  },
  
  // --- إذاعات متنوعة ---
  {
    id: 'roqya_radio',
    name: 'الرقية الشرعية',
    url: [
        'https://qurango.net/radio/roqiah',
        'https://backup.qurango.net/radio/roqiah'
    ],
    category: 'other'
  },
  {
    id: 'fatwa_radio',
    name: 'فتاوى العلماء',
    url: [
        'https://qurango.net/radio/fatwa',
        'https://backup.qurango.net/radio/fatwa'
    ],
    category: 'other'
  }
];
