
import React, { Suspense, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home'; // Home is loaded instantly
import { FirebaseService } from './services/firebase'; // Updated Service

// Lazy Load other pages to reduce bundle size
const QuranReader = React.lazy(() => import('./pages/QuranReader').then(m => ({ default: m.QuranReader })));
const Search = React.lazy(() => import('./pages/Search').then(m => ({ default: m.Search })));
const Hifz = React.lazy(() => import('./pages/Hifz').then(m => ({ default: m.Hifz })));
const Tasbih = React.lazy(() => import('./pages/Tasbih').then(m => ({ default: m.Tasbih })));
const HadithPage = React.lazy(() => import('./pages/Hadith').then(m => ({ default: m.HadithPage })));
const Adhkar = React.lazy(() => import('./pages/Adhkar').then(m => ({ default: m.Adhkar })));
const Events = React.lazy(() => import('./pages/Events').then(m => ({ default: m.Events })));
const Bookmarks = React.lazy(() => import('./pages/Bookmarks').then(m => ({ default: m.Bookmarks })));
const Notifications = React.lazy(() => import('./pages/Notifications').then(m => ({ default: m.Notifications })));
const WaqfGuide = React.lazy(() => import('./pages/WaqfGuide').then(m => ({ default: m.WaqfGuide })));
const Downloads = React.lazy(() => import('./pages/Downloads').then(m => ({ default: m.Downloads })));
const About = React.lazy(() => import('./pages/About').then(m => ({ default: m.About })));
const Radio = React.lazy(() => import('./pages/Radio').then(m => ({ default: m.Radio })));

// Loading Component
const LoadingSpinner = () => (
  <div className="flex flex-col items-center justify-center h-full w-full bg-gold-50 dark:bg-navy-950">
    <div className="w-12 h-12 border-4 border-gold-200 border-t-gold-500 rounded-full animate-spin"></div>
    <p className="mt-4 text-sm font-bold text-navy-500 dark:text-navy-300">جاري التحميل...</p>
  </div>
);

// Component to track route changes
const RouteTracker = () => {
  const location = useLocation();

  useEffect(() => {
    const pageName = location.pathname === '/' ? 'Home' : location.pathname.substring(1);
    FirebaseService.logScreen(pageName);
  }, [location]);

  return null;
};

const App: React.FC = () => {
  
  useEffect(() => {
    // Initialize Firebase (Analytics, Crashlytics, Remote Config)
    FirebaseService.init();
  }, []);

  return (
    <HashRouter>
      <RouteTracker />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="reader" element={
            <Suspense fallback={<LoadingSpinner />}>
              <QuranReader />
            </Suspense>
          } />
          <Route path="search" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Search />
            </Suspense>
          } />
          <Route path="downloads" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Downloads />
            </Suspense>
          } />
          <Route path="hifz" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Hifz />
            </Suspense>
          } />
          <Route path="tasbih" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Tasbih />
            </Suspense>
          } />
          <Route path="hadith" element={
            <Suspense fallback={<LoadingSpinner />}>
              <HadithPage />
            </Suspense>
          } />
          <Route path="radio" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Radio />
            </Suspense>
          } />
          <Route path="adhkar" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Adhkar />
            </Suspense>
          } />
          <Route path="events" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Events />
            </Suspense>
          } />
          <Route path="bookmarks" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Bookmarks />
            </Suspense>
          } />
          <Route path="notifications" element={
            <Suspense fallback={<LoadingSpinner />}>
              <Notifications />
            </Suspense>
          } />
          <Route path="waqf" element={
            <Suspense fallback={<LoadingSpinner />}>
              <WaqfGuide />
            </Suspense>
          } />
          <Route path="about" element={
            <Suspense fallback={<LoadingSpinner />}>
              <About />
            </Suspense>
          } />
          {/* Ensure any unknown path redirects to Home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </HashRouter>
  );
};

export default App;
