
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { X, Volume2, VolumeX, Pause, Play, Moon, Settings, Check, Loader2, AlertCircle, RefreshCcw, BellRing } from 'lucide-react';
import { MUAZZINS } from '../services/azhanData';
import { getStoredAzhan, setStoredAzhan } from '../services/storage';
import { getPlayableAzhanUrl } from '../services/offlineAudio';

interface AzhanModalProps {
  prayerName: string;
  prayerTime: string;
  onClose: () => void;
}

export const AzhanModal: React.FC<AzhanModalProps> = ({ prayerName, prayerTime, onClose }) => {
  const [currentAzhanId, setCurrentAzhanId] = useState(getStoredAzhan());
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playPromiseRef = useRef<Promise<void> | null>(null);
  const fadeIntervalRef = useRef<number | null>(null);
  const wakeLockRef = useRef<any>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const isMounted = useRef(true);

  // 1. ميزة التدرج الصوتي (Audio Fade-in) - توصية احترافية
  const fadeIn = useCallback(() => {
    if (!audioRef.current) return;
    audioRef.current.volume = 0;
    let vol = 0;
    fadeIntervalRef.current = window.setInterval(() => {
      if (audioRef.current && vol < 1) {
        vol = Math.min(vol + 0.05, 1);
        audioRef.current.volume = vol;
      } else {
        if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);
      }
    }, 200); // يصل لـ 100% خلال 4 ثوانٍ تقريباً
  }, []);

  // 2. طلب Wake Lock لإبقاء الشاشة مفعلة أثناء الأذان (توصية البحث)
  const requestWakeLock = async () => {
    if ('wakeLock' in navigator) {
      try {
        wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
      } catch (err) { console.warn("WakeLock failed"); }
    }
  };

  const releaseWakeLock = () => {
    if (wakeLockRef.current) {
      wakeLockRef.current.release().then(() => { wakeLockRef.current = null; });
    }
  };

  useEffect(() => {
    isMounted.current = true;
    const audio = new Audio();
    audio.crossOrigin = "anonymous";
    audio.preload = "auto";
    audioRef.current = audio;

    const onTimeUpdate = () => {
      if (audio.duration && isMounted.current) {
        setProgress((audio.currentTime / audio.duration) * 100);
      }
    };

    const onEnded = () => {
      if (isMounted.current) { setIsPlaying(false); setProgress(100); releaseWakeLock(); }
    };

    const onError = (e: any) => {
      console.error("Audio Error Event:", e);
      if (isMounted.current) {
        setError("فشل تشغيل الأذان. تحقق من اتصال الشبكة.");
        setIsLoading(false);
        setIsPlaying(false);
      }
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onError);

    return () => {
      isMounted.current = false;
      if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
      }
      releaseWakeLock();
    };
  }, []);

  const loadAndPlay = useCallback(async (id: string) => {
    if (!audioRef.current) return;
    
    setIsLoading(true);
    setError(null);
    setProgress(0);

    try {
      // استخدام Playable URL يضمن استقرار المسار وتجاوز مشاكل CORS
      const url = await getPlayableAzhanUrl(id);
      
      // حل مشكلة Interruption: انتظر اكتمال أي عملية تشغيل سابقة
      if (playPromiseRef.current) {
          try { await playPromiseRef.current; } catch (e) {}
      }

      audioRef.current.src = url;
      audioRef.current.load();
      
      // بدء التدرج الصوتي
      fadeIn();
      requestWakeLock();

      const playPromise = audioRef.current.play();
      playPromiseRef.current = playPromise;

      await playPromise;
      if (isMounted.current) {
          setIsPlaying(true);
          setIsLoading(false);
      }
    } catch (err: any) {
      if (err.name !== 'AbortError' && isMounted.current) {
        setError("تعذر الوصول لصوت المؤذن حالياً.");
        setIsLoading(false);
      }
    }
  }, [fadeIn]);

  useEffect(() => {
    loadAndPlay(currentAzhanId);
  }, [currentAzhanId, loadAndPlay]);

  const togglePlay = async () => {
    if (!audioRef.current || isLoading) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
      releaseWakeLock();
    } else {
      try {
        fadeIn();
        requestWakeLock();
        await audioRef.current.play();
        setIsPlaying(true);
      } catch (e) { setError("فشل استئناف الأذان."); }
    }
  };

  const changeMuazzin = (id: string) => {
    setStoredAzhan(id);
    setCurrentAzhanId(id);
    setShowSettings(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-navy-950/98 backdrop-blur-2xl animate-in fade-in duration-500 font-sans">
      <div className="relative w-full max-w-md bg-navy-900 border border-gold-500/20 rounded-[3rem] shadow-2xl overflow-hidden flex flex-col items-center text-center p-8 space-y-6">
        
        {/* Top Controls */}
        <div className="w-full flex justify-between items-center absolute top-6 px-8 z-20">
          <button onClick={() => setShowSettings(!showSettings)} className="p-2.5 rounded-full bg-white/5 hover:bg-gold-500/20 text-white/60 hover:text-gold-400 transition-all"><Settings size={22} /></button>
          <button onClick={onClose} className="p-2.5 rounded-full bg-white/5 hover:bg-red-500/20 text-white/60 hover:text-red-400 transition-all"><X size={22} /></button>
        </div>

        {/* Visualizer / Icon */}
        <div className="relative mt-10">
          <div className={`w-36 h-36 rounded-full border-4 border-gold-500/20 flex items-center justify-center bg-navy-800 shadow-[0_0_60px_rgba(176,141,85,0.1)] relative`}>
            {isLoading ? (
              <Loader2 size={45} className="text-gold-500 animate-spin" />
            ) : error ? (
              <AlertCircle size={45} className="text-red-400" />
            ) : (
              <>
                <div className={`absolute inset-0 border-4 border-t-gold-500 border-r-transparent border-b-transparent border-l-gold-500 rounded-full ${isPlaying ? 'animate-spin-slow' : 'opacity-20'}`}></div>
                <BellRing size={50} className={`text-gold-400 ${isPlaying ? 'animate-bounce' : 'opacity-40'}`} />
              </>
            )}
          </div>
        </div>

        {/* Info */}
        <div className="space-y-2">
          <h2 className="text-4xl font-bold font-quran text-white">{prayerName}</h2>
          <p className="text-gold-400 text-xl font-sans font-bold opacity-80">{prayerTime}</p>
          <div className="pt-2">
            <span className="bg-navy-800 px-4 py-1.5 rounded-xl text-[11px] font-bold text-navy-300 border border-white/5">
               بصوت: {MUAZZINS.find(m => m.id === currentAzhanId)?.name}
            </span>
          </div>
        </div>

        {error && (
          <div className="bg-red-900/20 border border-red-500/30 p-4 rounded-2xl flex flex-col items-center gap-2 animate-in shake">
            <p className="text-xs text-red-200 font-bold">{error}</p>
            <button onClick={() => loadAndPlay(currentAzhanId)} className="flex items-center gap-2 text-[10px] font-bold text-white bg-red-500/40 px-3 py-1.5 rounded-lg hover:bg-red-500 transition-colors">
              <RefreshCcw size={12} /> إعادة المحاولة
            </button>
          </div>
        )}

        {/* Progress & Player Controls */}
        <div className="w-full space-y-6 pt-4">
          <div className="w-full h-1.5 bg-navy-950 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-gold-600 to-gold-400 transition-all duration-300 ease-linear" style={{ width: `${progress}%` }}></div>
          </div>

          <div className="flex items-center justify-center gap-8">
            <button onClick={() => { if(audioRef.current) { audioRef.current.muted = !isMuted; setIsMuted(!isMuted); }}} className="p-4 rounded-full bg-navy-800 text-gold-400 hover:bg-navy-700 transition-all">
              {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
            </button>

            <button onClick={togglePlay} disabled={isLoading} className={`w-20 h-20 rounded-full bg-gold-500 text-navy-900 flex items-center justify-center hover:bg-gold-400 hover:scale-105 transition-all shadow-xl shadow-gold-500/20 active:scale-95 ${isLoading ? 'opacity-50' : ''}`}>
              {isPlaying ? <Pause size={36} fill="currentColor" /> : <Play size={36} fill="currentColor" className="ml-1.5" />}
            </button>

            <button onClick={onClose} className="px-8 py-4 rounded-2xl bg-navy-800 text-white font-bold text-sm hover:bg-navy-700 transition-all border border-white/5">تخطي</button>
          </div>
        </div>

        {/* Muazzin Selection Overlay */}
        {showSettings && (
          <div className="absolute inset-x-6 top-24 bottom-6 bg-navy-800/98 backdrop-blur-xl rounded-[2.5rem] z-30 shadow-2xl border border-white/10 flex flex-col overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-5 border-b border-white/5 flex justify-between items-center bg-black/20">
              <span className="text-sm font-bold text-white">اختر المؤذن المفضل</span>
              <button onClick={() => setShowSettings(false)} className="p-1 rounded-full hover:bg-white/10 text-white/50"><X size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-2">
              <p className="text-[10px] text-gold-500 font-bold mb-2 text-right pr-2">أصوات المدرسة المصرية</p>
              {MUAZZINS.map(m => (
                <button 
                  key={m.id} 
                  onClick={() => changeMuazzin(m.id)} 
                  className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all border ${currentAzhanId === m.id ? 'bg-gold-500 text-navy-900 border-gold-400' : 'text-white/80 hover:bg-white/5 border-transparent'} ${m.style === 'egyptian' ? 'border-r-4 border-r-gold-500' : ''}`}
                >
                  <div className="text-right">
                    <span className="text-sm font-bold block">{m.name}</span>
                    <span className="text-[9px] opacity-60">{m.style === 'egyptian' ? 'المدرسة المصرية' : 'الخليج والشام'}</span>
                  </div>
                  {currentAzhanId === m.id && <Check size={18} strokeWidth={3} />}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
