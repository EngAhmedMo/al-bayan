import React, { useState, useEffect, createContext, useContext, useRef, useMemo, useLayoutEffect } from 'react';
import { flushSync } from 'react-dom';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { BookOpen, Search, Grid, Moon, Sun, Activity, BookHeart, Menu, X, Play, Pause, SkipForward, SkipBack, Home, Shield, Calendar, Bookmark, Bell, Info, Headphones, Mic, Repeat, Download, WifiOff, Settings, Radio, Signal, Volume2, Check, Trash2, Type, Square, Heart } from 'lucide-react';
import { fetchSurahs, RECITERS, getAudioUrl } from '../services/api';
import { Surah, RadioStation } from '../types';
import { RADIO_STATIONS } from '../services/radioData';
import { requestNotificationPermission } from '../services/notificationManager';
import { getUnreadCount, getStoredFontSize, setStoredFontSize as saveFontSize, getStoredReciter, setStoredReciter as saveReciter, getDailyPrayers, getStoredAzhan, setStoredAzhan } from '../services/storage';
import { getMetadataFromGlobalAyah } from '../services/quranStaticData';
import { toArabicDigits } from '../services/normalization';
import { getPlayableUrl, downloadAzhan, isAzhanDownloaded, deleteAzhanFromCache, getPlayableAzhanUrl } from '../services/offlineAudio';
import { AzhanModal } from './AzhanModal';
import { MUAZZINS } from '../services/azhanData';

// --- Contexts ---
interface ThemeContextType {
  isDark: boolean;
  toggleTheme: () => void;
}
const ThemeContext = createContext<ThemeContextType>({ isDark: false, toggleTheme: () => {} });
export const useTheme = () => useContext(ThemeContext);

interface AudioContextType {
  currentTrack: { url: string; title: string; subtitle: string; globalAyahNumber?: number } | null;
  isPlaying: boolean;
  autoAdvance: boolean;
  repeatCount: number;
  playTrack: (url: string, title: string, subtitle: string, globalAyahNumber?: number, shouldAutoAdvance?: boolean, repeatCount?: number, forceReciterId?: string) => void;
  playNext: () => void;
  playPrev: () => void;
  pauseTrack: () => void;
  closePlayer: () => void;
  togglePlay: () => void;
}
export const AudioContext = createContext<AudioContextType>({
  currentTrack: null,
  isPlaying: false,
  autoAdvance: false,
  repeatCount: 0,
  playTrack: () => {},
  playNext: () => {},
  playPrev: () => {},
  pauseTrack: () => {},
  closePlayer: () => {},
  togglePlay: () => {},
});
export const useAudio = () => useContext(AudioContext);

interface RadioContextType {
  activeStation: RadioStation | null;
  isPlaying: boolean;
  isLoading: boolean;
  error: string | null;
  playStation: (station: RadioStation) => void;
  stopRadio: () => void;
  toggleRadio: () => void;
  playNextStation: () => void;
  playPrevStation: () => void;
}
export const RadioContext = createContext<RadioContextType>({
  activeStation: null,
  isPlaying: false,
  isLoading: false,
  error: null,
  playStation: () => {},
  stopRadio: () => {},
  toggleRadio: () => {},
  playNextStation: () => {},
  playPrevStation: () => {},
});
export const useRadio = () => useContext(RadioContext);

// --- NAVIGATION CONTEXT ---
interface NavigationContextType {
  navigateToAyah: (surahId: number, ayahNumber: number, page?: number) => void;
  openSidebar: () => void;
  setIsFullscreen: (v: boolean) => void;
}

// Strictly initialized to match interface
export const NavigationContext = createContext<NavigationContextType>({ 
  navigateToAyah: () => {}, 
  openSidebar: () => {}, 
  setIsFullscreen: () => {} 
});

interface SettingsContextType {
  fontSize: number;
  setFontSize: (size: number) => void;
  reciterId: string;
  setReciterId: (id: string) => void;
  azhanId: string;
  setAzhanId: (id: string) => void;
  openSettings: () => void;
}
export const SettingsContext = createContext<SettingsContextType>({ 
  fontSize: 28, 
  setFontSize: () => {}, 
  reciterId: 'ar.minshawi_murattal', 
  setReciterId: () => {},
  azhanId: 'egy_abdulbasit',
  setAzhanId: () => {},
  openSettings: () => {}
});
export const useSettings = () => useContext(SettingsContext);

// Sidebar
const Sidebar = React.memo(({ isOpen, close, navigateToSurah, openSettings }: { isOpen: boolean; close: () => void; navigateToSurah: (num: number) => void, openSettings: () => void }) => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const unreadCount = getUnreadCount();

  useEffect(() => {
    if (surahs.length === 0) {
      fetchSurahs().then(setSurahs);
    }
  }, [surahs.length]);

  const filteredSurahs = useMemo(() => {
    return surahs.filter(s => s.name.includes(searchTerm) || s.englishName.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [surahs, searchTerm]);

  const navItems = useMemo(() => [
    { label: "الرئيسية", path: "/", icon: <Home size={18} /> },
    { label: "بحث", path: "/search", icon: <Search size={18} /> },
    { label: "الإذاعة", path: "/radio", icon: <Radio size={18} /> },
    { label: "الحفظ", path: "/hifz", icon: <Activity size={18} /> },
    { label: "أوفلاين", path: "/downloads", icon: <WifiOff size={18} /> },
    { label: "المناسبات", path: "/events", icon: <Calendar size={18} /> },
    { label: "الحديث", path: "/hadith", icon: <BookHeart size={18} /> },
    { label: "المحفوظات", path: "/bookmarks", icon: <Bookmark size={18} /> },
    { label: "عن التطبيق", path: "/about", icon: <Info size={18} /> },
  ], []);

  return (
    <>
      {isOpen && <div className="fixed inset-0 bg-navy-950/70 z-50 transition-opacity backdrop-blur-sm md:hidden" onClick={close} />}
      <div className={`fixed inset-y-0 right-0 w-[85%] max-w-sm bg-white dark:bg-navy-950 shadow-2xl z-50 transform transition-transform duration-300 ease-out md:hidden ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        
        <div className="h-full overflow-y-auto custom-scrollbar overscroll-contain">
          <div className="flex flex-col min-h-full">
            
            <div className="relative h-32 bg-gradient-to-br from-navy-900 to-navy-800 shrink-0 overflow-hidden flex items-center px-6">
               <div className="absolute inset-0 opacity-10" style={{backgroundImage: "url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMiIgZmlsbD0ibm9uZSIgb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMjAgMEwyMCA0ME0wIDIwTDQwIDIwIiAvPjwvc3ZnPg==')"}}></div>
               <button onClick={close} className="absolute top-4 left-4 p-2 bg-white/10 text-white rounded-full hover:bg-white/20 transition-colors z-20">
                 <X size={20} />
               </button>
               <div className="relative z-10 flex items-center gap-4 cursor-pointer" onClick={() => { navigate('/'); close(); }}>
                 <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-navy-900 shadow-xl transform rotate-3">
                    <span className="font-quran text-3xl font-bold mt-2">ب</span>
                 </div>
                 <div>
                    <h2 className="font-bold text-2xl text-white font-quran">البيان</h2>
                    <p className="text-[10px] text-gold-400 font-bold tracking-wider mt-0.5 opacity-90">القرآن والسنة</p>
                 </div>
               </div>
            </div>
            
            <div className="p-3 grid grid-cols-4 gap-2 shrink-0 bg-gold-50/50 dark:bg-navy-900/50 border-b border-navy-100 dark:border-navy-800">
               {navItems.map((item) => (
                  <button 
                    key={item.path}
                    onClick={() => { navigate(item.path); close(); }} 
                    className="flex flex-col items-center justify-center gap-1 p-2 rounded-xl bg-white dark:bg-navy-800 border border-navy-100 dark:border-navy-700 shadow-sm hover:border-gold-500 dark:hover:border-gold-500 hover:shadow-md transition-all group"
                  >
                    <div className="text-navy-500 dark:text-navy-400 group-hover:text-gold-500 transition-colors">
                      {item.icon}
                    </div>
                    <span className="text-[9px] font-bold text-navy-800 dark:text-white truncate w-full text-center">{item.label}</span>
                  </button>
               ))}
               
               <button 
                 onClick={() => { openSettings(); close(); }} 
                 className="flex flex-col items-center justify-center gap-1 p-2 rounded-xl bg-white dark:bg-navy-800 border border-navy-100 dark:border-navy-700 shadow-sm hover:border-gold-500 dark:hover:border-gold-500 hover:shadow-md transition-all group"
               >
                 <div className="text-navy-500 dark:text-navy-400 group-hover:text-gold-500 transition-colors">
                   <Settings size={18} />
                 </div>
                 <span className="text-[9px] font-bold text-navy-800 dark:text-white truncate w-full text-center">الإعدادات</span>
               </button>

               <button onClick={() => { navigate('/notifications'); close(); }} className="col-span-4 flex items-center justify-between px-3 py-2 rounded-xl bg-gradient-to-r from-navy-800 to-navy-700 text-white shadow-sm relative overflow-hidden group">
                  <div className="flex items-center gap-2 relative z-10">
                     <Bell size={16} className="text-gold-400" />
                     <span className="text-xs font-bold">التنبيهات</span>
                  </div>
                  {unreadCount > 0 && (
                    <span className="bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full relative z-10">
                      {unreadCount}
                    </span>
                  )}
               </button>
            </div>

            <div className="flex-1 flex flex-col bg-white dark:bg-navy-950">
              <div className="p-3 bg-white dark:bg-navy-950 z-20 sticky top-0 border-b border-navy-50 dark:border-navy-800 shadow-sm">
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="ابحث عن سورة..." 
                    className="w-full h-10 px-4 pl-10 rounded-xl border border-navy-200 dark:border-navy-700 bg-white dark:bg-navy-900 text-navy-900 dark:text-white focus:ring-2 focus:ring-gold-500 outline-none transition-all text-sm"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                  />
                  <Search size={16} className="absolute left-3 top-3 text-navy-400" />
                </div>
              </div>

              <div className="px-2 pb-6 pt-2">
                <div className="grid grid-cols-1 gap-1">
                  {filteredSurahs.map(surah => (
                    <button
                      key={surah.number}
                      onClick={() => { navigateToSurah(surah.number); close(); }}
                      className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gold-50 dark:hover:bg-navy-800 transition-colors group border-b border-navy-50 dark:border-navy-800/50 last:border-0"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 flex shrink-0 items-center justify-center bg-navy-100 dark:bg-navy-800 rounded-lg text-xs font-bold text-navy-600 dark:text-navy-400 group-hover:bg-gold-500 group-hover:text-white transition-colors font-sans">
                          {surah.number}
                        </span>
                        <div className="text-right">
                          <div className="font-quran text-base font-bold text-navy-800 dark:text-white group-hover:text-gold-700 dark:group-hover:text-gold-400">{surah.name}</div>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-0.5">
                         <span className="text-[10px] text-navy-400 group-hover:text-navy-600 dark:group-hover:text-navy-300 font-bold">
                           {surah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}
                         </span>
                         <span className="text-[9px] text-navy-300 dark:text-navy-600">
                           {surah.numberOfAyahs} آية
                         </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="p-4 text-center border-t border-navy-100 dark:border-navy-800 bg-navy-50 dark:bg-navy-900 text-[10px] text-navy-400 mt-auto">
               © {new Date().getFullYear()} البيان - القرآن والسنة
            </div>
          </div>
        </div>
      </div>
    </>
  );
});

// Audio Player Bar
const AudioPlayerBar = () => {
  const { currentTrack, isPlaying, autoAdvance, repeatCount, togglePlay, playNext, playPrev, playTrack, closePlayer } = useAudio();
  const { reciterId, setReciterId } = useSettings();
  const [showReciterMenu, setShowReciterMenu] = useState(false);

  if (!currentTrack) return null;

  const handleReciterChange = (newReciterId: string) => {
    setReciterId(newReciterId);
    setShowReciterMenu(false);
    if (currentTrack && currentTrack.globalAyahNumber) {
        const newUrl = getAudioUrl(newReciterId, currentTrack.globalAyahNumber);
        playTrack(
          newUrl, 
          currentTrack.title, 
          currentTrack.subtitle, 
          currentTrack.globalAyahNumber, 
          autoAdvance, 
          repeatCount, 
          newReciterId 
        );
    }
  };

  return (
    <div className="fixed bottom-[70px] md:bottom-0 left-0 right-0 md:left-0 z-50 animate-in slide-in-from-bottom-10 pointer-events-auto">
      {showReciterMenu && (
        <div className="absolute bottom-full left-0 right-0 md:left-6 md:right-auto md:w-80 mx-3 mb-2 bg-white dark:bg-navy-950 rounded-2xl shadow-2xl border border-navy-100 dark:border-navy-700 overflow-hidden animate-in zoom-in-95 origin-bottom">
           <div className="p-3 border-b border-navy-100 dark:border-navy-800 flex justify-between items-center bg-navy-50 dark:bg-navy-900/50">
              <h4 className="text-xs font-bold text-navy-600 dark:text-white">اختر القارئ</h4>
              <button onClick={() => setShowReciterMenu(false)}><X size={16} className="text-navy-400" /></button>
           </div>
           <div className="grid grid-cols-3 gap-2 p-3 max-h-64 overflow-y-auto custom-scrollbar">
              {RECITERS.map(r => (
                <button 
                  key={r.id} 
                  onClick={() => handleReciterChange(r.id)}
                  className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all border min-h-[70px] justify-center ${
                    reciterId === r.id 
                      ? 'bg-gold-50 border-gold-500 dark:bg-gold-900/20' 
                      : 'bg-white dark:bg-navy-900 border-transparent hover:bg-navy-50 dark:hover:bg-navy-800'
                  }`}
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden border border-navy-100 dark:border-navy-700 shadow-sm relative shrink-0">
                     <div className="absolute inset-0 flex items-center justify-center bg-navy-100 dark:bg-navy-800 text-navy-400">
                        <Mic size={14} />
                     </div>
                     {r.image && (
                       <img 
                         src={r.image} 
                         alt={r.name} 
                         className="relative z-10 w-full h-full object-cover transition-opacity duration-300"
                         onError={(e) => { e.currentTarget.style.opacity = '0'; }}
                       />
                     )}
                  </div>
                  <span className="text-[10px] font-bold text-center text-navy-800 dark:text-navy-200 w-full leading-tight line-clamp-2">{r.name}</span>
                </button>
              ))}
           </div>
        </div>
      )}

      <div className="mx-3 md:mx-0 mb-3 md:mb-0">
        <div className="bg-white/95 dark:bg-navy-900/95 backdrop-blur-xl border border-gold-500/20 dark:border-navy-700 rounded-2xl md:rounded-none md:border-x-0 md:border-b-0 p-3 md:px-6 shadow-[0_8px_30px_rgba(0,0,0,0.12)] flex items-center justify-between gap-3 relative">
          
          <div className="flex items-center gap-3 overflow-hidden flex-1 group cursor-pointer select-none" onClick={() => setShowReciterMenu(!showReciterMenu)}>
            <button 
              className="relative w-10 h-10 md:w-12 md:h-12 flex-shrink-0 bg-gold-500 rounded-full flex items-center justify-center text-white shadow-lg shadow-gold-500/30 transition-transform group-hover:scale-105"
            >
               {isPlaying ? (
                 <div className="flex gap-0.5 items-end h-4">
                   <span className="w-1 bg-white animate-[music-bar_1s_ease-in-out_infinite] h-2"></span>
                   <span className="w-1 bg-white animate-[music-bar_1.2s_ease-in-out_infinite] h-4"></span>
                   <span className="w-1 bg-white animate-[music-bar_0.8s_ease-in-out_infinite] h-3"></span>
                 </div>
               ) : (
                 <Headphones size={20} />
               )}
               <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-navy-800 rounded-full flex items-center justify-center border border-white dark:border-navy-900">
                 <Grid size={8} />
               </div>
            </button>
            <div className="flex flex-col min-w-0">
               <span className="text-sm md:text-base font-bold text-navy-900 dark:text-white truncate group-hover:text-gold-600 dark:group-hover:text-gold-400 transition-colors">
                 {currentTrack.title}
               </span>
               <div className="flex items-center gap-2 text-[10px] md:text-xs text-navy-500 dark:text-navy-300 truncate">
                 <span>{currentTrack.subtitle}</span>
                 {repeatCount > 0 ? (
                   <span className="flex items-center gap-0.5 text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-900/20 px-1.5 py-0.5 rounded-full">
                     <Repeat size={10} /> {repeatCount >= 100 ? '∞' : repeatCount}
                   </span>
                 ) : autoAdvance ? (
                   <span className="flex items-center gap-0.5 text-gold-600 dark:text-gold-500 font-bold bg-gold-50 dark:bg-gold-900/20 px-1.5 py-0.5 rounded-full">
                     <Repeat size={10} /> متابعة
                   </span>
                 ) : null}
                 <span className="font-bold text-navy-400 group-hover:text-gold-500 transition-colors">• تغيير القارئ</span>
               </div>
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-4 flex-shrink-0">
            <button 
              onClick={playNext}
              className="p-2 text-navy-400 hover:text-gold-600 dark:text-navy-400 dark:hover:text-gold-400 transition-colors rounded-full hover:bg-navy-50 dark:hover:bg-navy-800"
              title="الآية التالية"
            >
              <SkipBack size={20} className="fill-current" />
            </button>
            
            <button 
              onClick={togglePlay}
              className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center rounded-full bg-navy-900 dark:bg-white text-white dark:text-navy-900 hover:bg-gold-600 dark:hover:bg-gold-400 transition-all shadow-md active:scale-95"
            >
              {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
            </button>
            
            <button 
              onClick={playPrev}
              className="p-2 text-navy-400 hover:text-gold-600 dark:text-navy-400 dark:hover:text-gold-400 transition-colors rounded-full hover:bg-navy-50 dark:hover:bg-navy-800"
              title="الآية السابقة"
            >
              <SkipForward size={20} className="fill-current" />
            </button>

            <div className="w-px h-6 bg-navy-100 dark:bg-navy-700 mx-1"></div>

            <button
              onClick={closePlayer}
              className="p-2 text-red-400 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 transition-colors rounded-full hover:bg-red-50 dark:hover:bg-red-900/20"
              title="إغلاق المشغل"
            >
              <X size={20} />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

const RadioPlayerBar = () => {
  const { activeStation, isPlaying, isLoading, toggleRadio, stopRadio, playNextStation, playPrevStation, error } = useRadio();

  if (!activeStation) return null;

  return (
    <div className="fixed bottom-[80px] md:absolute md:bottom-6 left-2 right-2 md:left-6 md:right-6 z-50 pointer-events-none flex justify-center">
      <div className="w-full max-w-3xl pointer-events-auto animate-in slide-in-from-bottom-10 fade-in duration-500">
        <div className={`relative overflow-hidden rounded-2xl md:rounded-3xl p-3 md:p-4 flex items-center justify-between gap-3 md:gap-6 shadow-xl shadow-black/10 hover:shadow-2xl transition-all duration-500 bg-white/95 border border-gold-200/60 backdrop-blur-xl text-navy-900 dark:bg-[#0f172a]/95 dark:border-emerald-500/20 dark:text-white dark:shadow-black/40`}>
            {/* ... Radio content ... */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-gold-50/40 to-transparent dark:via-emerald-500/5 opacity-60 animate-pulse pointer-events-none"></div>
            <div className="flex items-center gap-2 md:gap-5 flex-1 min-w-0">
                <div className={`relative w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl shrink-0 flex items-center justify-center transition-colors duration-500 shadow-inner ${isPlaying ? 'bg-gold-500 text-white dark:bg-emerald-600 dark:shadow-emerald-900/30' : 'bg-navy-100 text-navy-400 dark:bg-navy-800 dark:text-navy-500'}`}>
                    {isLoading ? (
                        <div className="w-5 h-5 border-2 border-white/80 border-t-transparent rounded-full animate-spin"></div>
                    ) : isPlaying ? (
                         <div className="flex gap-1 items-end h-5 pb-1">
                           <span className="w-1 bg-white animate-[music-bar_0.6s_ease-in-out_infinite] h-2 rounded-full"></span>
                           <span className="w-1 bg-white animate-[music-bar_0.8s_ease-in-out_infinite] h-4 rounded-full"></span>
                           <span className="w-1 bg-white animate-[music-bar_1.0s_ease-in-out_infinite] h-3 rounded-full"></span>
                         </div>
                    ) : (
                        <Radio size={24} />
                    )}
                </div>
                <div className="flex flex-col min-w-0 relative z-10">
                    <h3 className="font-bold text-sm md:text-lg truncate leading-tight tracking-tight">{activeStation.name}</h3>
                    <div className="flex items-center gap-2 text-xs md:text-sm font-medium mt-0.5">
                        <span className={`flex items-center gap-1 ${isPlaying ? "text-emerald-600 dark:text-emerald-400" : error ? "text-amber-500" : "text-navy-400 dark:text-navy-500"}`}>
                           <Signal size={12} className={isPlaying ? "animate-pulse" : ""} />
                           <span className="truncate">{isLoading ? 'جاري الاتصال...' : error ? error : (isPlaying ? 'بث مباشر' : 'متوقف')}</span>
                        </span>
                    </div>
                </div>
            </div>
            <div className="flex items-center gap-2 md:gap-3 shrink-0 relative z-10 pl-1">
                <button onClick={playPrevStation} className="p-2 rounded-full text-navy-500 hover:bg-navy-100/80 dark:text-slate-400 dark:hover:bg-white/10"><SkipForward size={20} className="fill-current md:w-6 md:h-6" /></button>
                <button onClick={toggleRadio} className={`w-10 h-10 md:w-14 md:h-14 rounded-full flex items-center justify-center shadow-lg transition-all active:scale-95 ${isPlaying ? 'bg-navy-900 text-white dark:bg-white dark:text-navy-900' : 'bg-gold-500 text-white dark:bg-emerald-600'}`}>{isPlaying ? <Pause size={18} fill="currentColor" className="md:w-5 md:h-5" /> : <Play size={18} fill="currentColor" className="ml-0.5 md:w-5 md:h-5" />}</button>
                <button onClick={playNextStation} className="p-2 rounded-full text-navy-500 hover:bg-navy-100/80 dark:text-slate-400 dark:hover:bg-white/10"><SkipBack size={20} className="fill-current md:w-6 md:h-6" /></button>
                <div className="w-px h-6 md:h-8 bg-navy-100 dark:bg-white/10 mx-1 md:mx-1.5"></div>
                <button onClick={stopRadio} className="p-2 rounded-full bg-red-50 text-red-500 hover:bg-red-100 dark:bg-red-500/10 dark:hover:bg-red-500/20"><X size={18} className="md:w-5 md:h-5" /></button>
            </div>
        </div>
      </div>
    </div>
  );
};

const DesktopNavItem = ({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) => (
  <NavLink 
    to={to} 
    className={({ isActive }) => 
      `flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all duration-200 group relative overflow-hidden ${
        isActive 
          ? 'bg-gold-50 dark:bg-navy-800 text-gold-700 dark:text-gold-400' 
          : 'text-navy-500 dark:text-navy-400 hover:bg-gold-50/50 dark:hover:bg-navy-800/50 hover:text-navy-700 dark:hover:text-white'
      }`
    }
  >
    {({ isActive }) => (
      <>
        {isActive && <div className="absolute right-0 top-0 bottom-0 w-1 bg-gold-500 rounded-l-full"></div>}
        <div className={`transition-transform ${isActive ? 'scale-110' : 'group-hover:scale-110'}`}>{icon}</div>
        <span>{label}</span>
      </>
    )}
  </NavLink>
);

const NavItem = ({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) => (
  <NavLink 
    to={to} 
    className={({ isActive }) => 
      `flex flex-col items-center justify-center w-full h-full space-y-1.5 transition-all duration-300 relative ${
        isActive 
          ? 'text-gold-600 dark:text-gold-400' 
          : 'text-navy-400 dark:text-navy-500 hover:text-navy-600 dark:hover:text-navy-300'
      }`
    }
  >
    {({ isActive }) => (
      <>
        <div className={`p-1.5 rounded-xl transition-all duration-300 ${isActive ? 'bg-gold-50 dark:bg-gold-900/20 -translate-y-1' : ''}`}>
           {icon}
        </div>
        <span className={`text-[9px] font-bold ${isActive ? '-translate-y-1' : ''}`}>{label}</span>
      </>
    )}
  </NavLink>
);

export const Layout: React.FC = () => {
  const [isDark, setIsDark] = useState(() => localStorage.getItem('theme') === 'dark');
  const navigate = useNavigate();
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const unreadCount = getUnreadCount();

  // Audio State
  const [currentTrack, setCurrentTrack] = useState<{ url: string; title: string; subtitle: string; globalAyahNumber?: number } | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [autoAdvance, setAutoAdvance] = useState(false);
  const [repeatCount, setRepeatCount] = useState(0); 
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const preloadAudioRef = useRef<HTMLAudioElement | null>(null); 
  const playTrackId = useRef<number>(0);
  const consecutiveErrors = useRef(0);
  
  // Radio State
  const [radioStation, setRadioStation] = useState<RadioStation | null>(null);
  const [isRadioPlaying, setIsRadioPlaying] = useState(false);
  const [radioLoading, setRadioLoading] = useState(false);
  const [radioError, setRadioError] = useState<string | null>(null);
  const [currentUrlIndex, setCurrentUrlIndex] = useState(0);
  const radioAudioRef = useRef<HTMLAudioElement | null>(null);
  
  const activeStationRef = useRef<RadioStation | null>(null);
  const urlIndexRef = useRef<number>(0);

  // Settings State
  const [fontSize, setFontSizeState] = useState(getStoredFontSize());
  const [reciterId, setReciterIdState] = useState(getStoredReciter());
  const [azhanId, setAzhanIdState] = useState(getStoredAzhan());
  const [isSettingsOpen, setIsSettingsOpen] = useState(false); 

  // --- AZHAN STATE ---
  const [azhanModalData, setAzhanModalData] = useState<{ name: string; time: string } | null>(null);
  const lastAzhanTriggered = useRef<string | null>(null);
  
  const azhanPreviewRef = useRef<HTMLAudioElement | null>(null);
  const [previewPlayingId, setPreviewPlayingId] = useState<string | null>(null);
  
  const [azhanDownloads, setAzhanDownloads] = useState<Record<string, boolean>>({});
  const [downloadProgress, setDownloadProgress] = useState<Record<string, number>>({});
  const [activeDownloads, setActiveDownloads] = useState<Record<string, AbortController>>({});

  const setFontSize = (size: number) => { setFontSizeState(size); saveFontSize(size); };
  const setReciterId = (id: string) => { setReciterIdState(id); saveReciter(id); };
  const setAzhanId = (id: string) => { setAzhanIdState(id); setStoredAzhan(id); };

  useEffect(() => { activeStationRef.current = radioStation; }, [radioStation]);
  useEffect(() => { urlIndexRef.current = currentUrlIndex; }, [currentUrlIndex]);

  useEffect(() => {
    if (isSettingsOpen) {
        const checkDownloads = async () => {
            const statuses: Record<string, boolean> = {};
            for (const m of MUAZZINS) {
                statuses[m.id] = await isAzhanDownloaded(m.id);
            }
            setAzhanDownloads(statuses);
        };
        checkDownloads();
    } else {
        if (azhanPreviewRef.current) {
            azhanPreviewRef.current.pause();
            azhanPreviewRef.current.src = ""; // Clear src
            setPreviewPlayingId(null);
        }
    }
  }, [isSettingsOpen]);

  // --- Initial System Checks & Prayer Watcher ---
  useEffect(() => {
    requestNotificationPermission();
    
    const checkPrayers = () => {
      const todayPrayers = getDailyPrayers();
      if (!todayPrayers) return;

      const now = new Date();
      const currentHm = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      
      if (lastAzhanTriggered.current === currentHm) return;

      const timings = todayPrayers.timings;
      const prayersToCheck = [
        { name: 'الفجر', time: timings.Fajr },
        { name: 'الظهر', time: timings.Dhuhr },
        { name: 'العصر', time: timings.Asr },
        { name: 'المغرب', time: timings.Maghrib },
        { name: 'العشاء', time: timings.Isha }
      ];

      const match = prayersToCheck.find(p => p.time.startsWith(currentHm));
      
      if (match) {
        setAzhanModalData({ name: `صلاة ${match.name}`, time: match.time });
        lastAzhanTriggered.current = currentHm;
        
        if (isPlaying) pauseTrack();
        if (isRadioPlaying) stopRadio();
        if (previewPlayingId && azhanPreviewRef.current) { 
            azhanPreviewRef.current.pause(); 
            setPreviewPlayingId(null); 
        }
      }
    };

    const timer = setInterval(checkPrayers, 30000);
    checkPrayers(); 

    return () => clearInterval(timer);
  }, [isPlaying, isRadioPlaying, previewPlayingId]);

  const toggleTheme = () => {
    if (!(document as any).startViewTransition) {
      setIsDark((prev) => !prev);
      return;
    }
    (document as any).startViewTransition(() => {
      flushSync(() => {
        setIsDark((prev) => !prev);
      });
    });
  };

  useLayoutEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      root.style.colorScheme = 'dark';
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      root.style.colorScheme = 'light';
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  const trackRef = useRef(currentTrack);
  const autoAdvanceRef = useRef(autoAdvance);
  const repeatCountRef = useRef(repeatCount);
  const reciterRef = useRef(reciterId);

  useEffect(() => { trackRef.current = currentTrack; }, [currentTrack]);
  useEffect(() => { autoAdvanceRef.current = autoAdvance; }, [autoAdvance]);
  useEffect(() => { repeatCountRef.current = repeatCount; }, [repeatCount]);
  useEffect(() => { reciterRef.current = reciterId; }, [reciterId]);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.playbackRate = 1.0; 
      audioRef.current.addEventListener('ended', handleTrackEnded);
      audioRef.current.addEventListener('error', handleAudioError);
    }
    if (!radioAudioRef.current) {
      radioAudioRef.current = new Audio();
      radioAudioRef.current.removeAttribute('crossorigin');
      
      radioAudioRef.current.onerror = () => {
         const station = activeStationRef.current;
         const idx = urlIndexRef.current;
         if (station && idx < station.url.length - 1) {
             const nextIdx = idx + 1;
             setCurrentUrlIndex(nextIdx);
             if (radioAudioRef.current) {
                 const url = station.url[nextIdx];
                 radioAudioRef.current.src = `${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`;
                 radioAudioRef.current.load();
                 radioAudioRef.current.play().catch(console.error);
             }
         } else {
             setRadioError("تعذر الاتصال بالبث");
             setRadioLoading(false);
             setIsRadioPlaying(false);
         }
      };

      radioAudioRef.current.onplaying = () => {
         setRadioLoading(false);
         setIsRadioPlaying(true);
         setRadioError(null);
      };
    }
  }, []);

  const handleTrackEnded = () => {
    if (repeatCountRef.current > 0) {
       const nextRepeat = repeatCountRef.current >= 100 ? repeatCountRef.current : repeatCountRef.current - 1;
       setRepeatCount(nextRepeat);
       if (audioRef.current) { audioRef.current.currentTime = 0; audioRef.current.play().catch(console.error); }
       return; 
    }
    consecutiveErrors.current = 0; 
    if (autoAdvanceRef.current && trackRef.current && trackRef.current.globalAyahNumber) {
       playNextVerse(); 
    } else {
       setIsPlaying(false);
    }
  };

  const handleAudioError = (e: Event) => {
     if (autoAdvanceRef.current && trackRef.current && trackRef.current.globalAyahNumber) {
         if (consecutiveErrors.current > 5) { setIsPlaying(false); consecutiveErrors.current = 0; return; }
         consecutiveErrors.current += 1;
         setTimeout(() => { playNextVerse(); }, 200); 
     } else {
         setIsPlaying(false);
     }
  };

  const playNextVerse = () => {
      const currentGlobal = trackRef.current?.globalAyahNumber;
      if (!currentGlobal) return;
      const nextGlobal = currentGlobal + 1;
      if (nextGlobal <= 6236) {
        const nextMeta = getMetadataFromGlobalAyah(nextGlobal);
        const currentReciterId = reciterRef.current;
        const nextUrl = getAudioUrl(currentReciterId, nextGlobal);
        playTrack(nextUrl, `سورة ${nextMeta.surahName}`, `الآية ${toArabicDigits(nextMeta.ayahInSurah)}`, nextGlobal, true, 0, currentReciterId);
      } else {
        setIsPlaying(false);
      }
  };

  const playTrack = async (url: string, title: string, subtitle: string, globalAyahNumber?: number, shouldAutoAdvance = false, repeat = 0, forceReciterId?: string) => {
    if (radioStation) stopRadio();
    if (previewPlayingId && azhanPreviewRef.current) { azhanPreviewRef.current.pause(); setPreviewPlayingId(null); }
    const requestId = ++playTrackId.current;
    const targetReciterId = forceReciterId || reciterId;
    let finalUrl = url;
    if (globalAyahNumber && targetReciterId) {
       try { finalUrl = await getPlayableUrl(targetReciterId, globalAyahNumber); } catch (e) {}
    }
    if (requestId !== playTrackId.current) return;
    if (!audioRef.current) return;

    try {
      if (audioRef.current.src !== finalUrl) {
          audioRef.current.src = finalUrl;
          audioRef.current.load();
      }
      const playPromise = audioRef.current.play();
      if (playPromise !== undefined) {
        playPromise.then(() => {
            consecutiveErrors.current = 0;
            if (globalAyahNumber) {
                const nextGlobal = globalAyahNumber + 1;
                if (nextGlobal <= 6236) {
                    const nextUrl = getAudioUrl(targetReciterId, nextGlobal);
                    const preloader = new Audio(nextUrl);
                    preloader.preload = 'auto';
                    preloader.load();
                    preloadAudioRef.current = preloader;
                }
            }
        }).catch(error => {
          if (error.name !== 'AbortError') {
             if (shouldAutoAdvance && globalAyahNumber && consecutiveErrors.current <= 5) {
                 consecutiveErrors.current += 1;
                 setTimeout(() => playNextVerse(), 200);
             } else {
                 setIsPlaying(false);
             }
          }
        });
      }
    } catch (e) { setIsPlaying(false); }
    
    setCurrentTrack({ url, title, subtitle, globalAyahNumber });
    setIsPlaying(true);
    setAutoAdvance(shouldAutoAdvance);
    setRepeatCount(repeat);
  };

  const pauseTrack = () => { audioRef.current?.pause(); setIsPlaying(false); };
  
  const closePlayer = () => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.currentTime = 0; }
    if ('mediaSession' in navigator) { navigator.mediaSession.playbackState = 'none'; navigator.mediaSession.metadata = null; }
    setIsPlaying(false);
    setCurrentTrack(null);
    setAutoAdvance(false);
    setRepeatCount(0);
    consecutiveErrors.current = 0;
  };

  const togglePlay = () => {
    if (isPlaying) { pauseTrack(); } 
    else if (currentTrack && audioRef.current) { audioRef.current.play().catch(console.error); setIsPlaying(true); }
  };

  const manualChangeTrack = (offset: number) => {
    if (!currentTrack || !currentTrack.globalAyahNumber) return;
    const nextAyahNum = currentTrack.globalAyahNumber + offset;
    if (nextAyahNum < 1 || nextAyahNum > 6236) return;
    consecutiveErrors.current = 0;
    const nextMeta = getMetadataFromGlobalAyah(nextAyahNum);
    const currentReciterId = reciterRef.current;
    const nextUrl = getAudioUrl(currentReciterId, nextAyahNum);
    playTrack(nextUrl, `سورة ${nextMeta.surahName}`, `الآية ${toArabicDigits(nextMeta.ayahInSurah)}`, nextAyahNum, autoAdvance, 0, currentReciterId);
  };

  const playStation = (station: RadioStation) => {
      if (currentTrack) closePlayer();
      if (previewPlayingId && azhanPreviewRef.current) { azhanPreviewRef.current.pause(); setPreviewPlayingId(null); }
      setRadioStation(station);
      setRadioLoading(true);
      setRadioError(null);
      setCurrentUrlIndex(0); 
      if (radioAudioRef.current) {
          const url = station.url[0];
          const finalUrl = `${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`;
          radioAudioRef.current.src = finalUrl;
          radioAudioRef.current.load();
          radioAudioRef.current.play().catch(e => {
              if (e.name !== 'AbortError') radioAudioRef.current?.dispatchEvent(new Event('error'));
          });
      }
  };

  const stopRadio = () => {
      if (radioAudioRef.current) {
          radioAudioRef.current.pause();
          radioAudioRef.current.src = "";
      }
      setRadioStation(null);
      setIsRadioPlaying(false);
      setRadioLoading(false);
      setRadioError(null);
  };

  const toggleRadio = () => {
      if (isRadioPlaying) {
          radioAudioRef.current?.pause();
          setIsRadioPlaying(false);
      } else {
          if (radioAudioRef.current && radioAudioRef.current.src) {
              setRadioLoading(true);
              radioAudioRef.current.play().catch(() => {});
          } else if (radioStation) {
              playStation(radioStation);
          }
      }
  };

  const changeStation = (direction: 'next' | 'prev') => {
      if (!radioStation) return;
      const currentIndex = RADIO_STATIONS.findIndex(s => s.id === radioStation.id);
      if (currentIndex === -1) return;
      let nextIndex;
      if (direction === 'next') {
          nextIndex = (currentIndex + 1) % RADIO_STATIONS.length;
      } else {
          nextIndex = (currentIndex - 1 + RADIO_STATIONS.length) % RADIO_STATIONS.length;
      }
      playStation(RADIO_STATIONS[nextIndex]);
  };

  const handlePreviewAzhan = async (id: string) => {
    if (currentTrack) pauseTrack();
    if (isRadioPlaying) stopRadio();

    if (!azhanPreviewRef.current) {
        azhanPreviewRef.current = new Audio();
        azhanPreviewRef.current.onended = () => setPreviewPlayingId(null);
    }

    if (previewPlayingId === id) {
        azhanPreviewRef.current.pause();
        setPreviewPlayingId(null);
    } else {
        const url = await getPlayableAzhanUrl(id);
        azhanPreviewRef.current.src = url;
        
        try {
            await azhanPreviewRef.current.play();
            setPreviewPlayingId(id);
        } catch (e) {
            console.error("Preview failed", e);
            setPreviewPlayingId(null);
        }
    }
  };

  const handleDownloadAzhan = async (id: string) => {
    if (activeDownloads[id]) {
        activeDownloads[id].abort();
        const newActive = { ...activeDownloads };
        delete newActive[id];
        setActiveDownloads(newActive);
        setDownloadProgress(prev => ({ ...prev, [id]: 0 }));
        return;
    }

    if (azhanDownloads[id]) {
        if(confirm("هل تريد حذف هذا الملف من التخزين؟")) {
            await deleteAzhanFromCache(id);
            setAzhanDownloads(prev => ({...prev, [id]: false}));
        }
        return;
    }

    const controller = new AbortController();
    setActiveDownloads(prev => ({ ...prev, [id]: controller }));
    setDownloadProgress(prev => ({ ...prev, [id]: 1 })); 

    try {
        await downloadAzhan(id, (pct) => {
            setDownloadProgress(prev => ({ ...prev, [id]: pct }));
        }, controller.signal);
        
        setAzhanDownloads(prev => ({...prev, [id]: true}));
    } catch (e: any) {
        if (e.name !== 'AbortError') {
            alert("فشل التحميل، تأكد من الاتصال بالإنترنت");
        }
    } finally {
        const newActive = { ...activeDownloads };
        delete newActive[id];
        setActiveDownloads(newActive);
        setDownloadProgress(prev => ({ ...prev, [id]: 0 }));
    }
  };

  useEffect(() => {
    if ('mediaSession' in navigator) {
        if (currentTrack) {
            navigator.mediaSession.metadata = new MediaMetadata({
                title: currentTrack.title,
                artist: currentTrack.subtitle,
                album: 'البيان - القرآن الكريم',
                artwork: [{ src: '/icon-512.png', sizes: '512x512', type: 'image/png' }]
            });
            navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
            navigator.mediaSession.setActionHandler('play', togglePlay);
            navigator.mediaSession.setActionHandler('pause', togglePlay);
            navigator.mediaSession.setActionHandler('previoustrack', () => manualChangeTrack(-1));
            navigator.mediaSession.setActionHandler('nexttrack', () => manualChangeTrack(1));
            navigator.mediaSession.setActionHandler('stop', closePlayer);
        } else if (radioStation) {
            navigator.mediaSession.metadata = new MediaMetadata({
                title: radioStation.name,
                artist: 'الإذاعة المباشرة',
                album: 'البيان',
                artwork: [{ src: radioStation.img || '/icon-512.png', sizes: '512x512', type: 'image/png' }]
            });
            navigator.mediaSession.playbackState = isRadioPlaying ? 'playing' : 'paused';
            navigator.mediaSession.setActionHandler('play', toggleRadio);
            navigator.mediaSession.setActionHandler('pause', toggleRadio);
            navigator.mediaSession.setActionHandler('previoustrack', () => changeStation('prev'));
            navigator.mediaSession.setActionHandler('nexttrack', () => changeStation('next'));
            navigator.mediaSession.setActionHandler('stop', stopRadio);
        } else {
            navigator.mediaSession.playbackState = 'none';
        }
    }
  }, [currentTrack, isPlaying, radioStation, isRadioPlaying]);

  const themeContextValue = useMemo(() => ({ isDark, toggleTheme }), [isDark]);
  const settingsContextValue = useMemo(() => ({ fontSize, setFontSize, reciterId, setReciterId, azhanId, setAzhanId, openSettings: () => setIsSettingsOpen(true) }), [fontSize, reciterId, azhanId]);

  return (
    <ThemeContext.Provider value={themeContextValue}>
      <SettingsContext.Provider value={settingsContextValue}>
        <AudioContext.Provider value={{ currentTrack, isPlaying, autoAdvance, repeatCount, playTrack, playNext: () => manualChangeTrack(1), playPrev: () => manualChangeTrack(-1), pauseTrack, closePlayer, togglePlay }}>
          <RadioContext.Provider value={{ activeStation: radioStation, isPlaying: isRadioPlaying, isLoading: radioLoading, error: radioError, playStation, stopRadio, toggleRadio, playNextStation: () => changeStation('next'), playPrevStation: () => changeStation('prev') }}>
            <NavigationContext.Provider value={{ navigateToAyah: (s, a, p) => { navigate(`/reader?page=${p}&highlight=${s}:${a}`); setSidebarOpen(false); }, openSidebar: () => setSidebarOpen(true), setIsFullscreen }}>
              
              <div className="flex h-screen overflow-hidden bg-gold-50 dark:bg-navy-950 transition-colors duration-500 ease-in-out">
                
                {azhanModalData && (
                  <AzhanModal 
                    prayerName={azhanModalData.name} 
                    prayerTime={azhanModalData.time} 
                    onClose={() => setAzhanModalData(null)} 
                  />
                )}

                {/* Settings Modal (Global) */}
                {isSettingsOpen && (
                  <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-navy-900/80 backdrop-blur-sm" onClick={() => setIsSettingsOpen(false)}></div>
                    <div className="relative w-full max-w-sm bg-white dark:bg-navy-900 rounded-3xl shadow-2xl overflow-hidden border border-navy-100 dark:border-navy-800 animate-in zoom-in-95">
                      <div className="p-5 border-b border-navy-100 dark:border-navy-800 flex justify-between items-center bg-navy-50 dark:bg-navy-950">
                        <h3 className="font-bold text-lg text-navy-900 dark:text-white flex items-center gap-2">
                          <Settings size={20} className="text-gold-500" /> إعدادات التطبيق
                        </h3>
                        <button onClick={() => setIsSettingsOpen(false)} className="p-1.5 rounded-full hover:bg-navy-200 dark:hover:bg-navy-800 text-navy-500"><X size={20} /></button>
                      </div>
                      <div className="p-5 overflow-y-auto max-h-[70vh] custom-scrollbar space-y-6">
                         {/* Azhan Settings */}
                         <div>
                            <label className="flex items-center gap-2 text-sm font-bold text-navy-700 dark:text-navy-300 mb-3">
                               <Volume2 size={18} className="text-gold-500" /> صوت الأذان الافتراضي
                            </label>
                            <div className="bg-navy-50 dark:bg-navy-950 rounded-2xl p-2 space-y-2">
                               {MUAZZINS.map(m => {
                                 const isDownloading = !!activeDownloads[m.id];
                                 const progress = downloadProgress[m.id] || 0;
                                 
                                 return (
                                   <div
                                     key={m.id}
                                     className={`w-full flex items-center gap-2 p-2 rounded-xl transition-all ${azhanId === m.id ? 'bg-white dark:bg-navy-800 shadow-sm border border-gold-200 dark:border-gold-800' : 'hover:bg-white/50 dark:hover:bg-navy-900'}`}
                                   >
                                     <button 
                                       onClick={() => handlePreviewAzhan(m.id)}
                                       className="p-2 rounded-full bg-navy-100 dark:bg-navy-700 text-navy-600 dark:text-white hover:bg-gold-500 hover:text-white transition-colors"
                                     >
                                        {previewPlayingId === m.id ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" />}
                                     </button>

                                     <div onClick={() => setAzhanId(m.id)} className="flex-1 cursor-pointer">
                                        <span className={`text-sm font-bold ${azhanId === m.id ? 'text-gold-600 dark:text-gold-500' : 'text-navy-600 dark:text-navy-300'}`}>{m.name}</span>
                                        {isDownloading && (
                                            <div className="w-full h-1 bg-navy-200 mt-1 rounded-full overflow-hidden">
                                                <div className="h-full bg-gold-500 transition-all duration-300" style={{ width: `${progress}%` }}></div>
                                            </div>
                                        )}
                                     </div>

                                     <button 
                                       onClick={() => handleDownloadAzhan(m.id)}
                                       className={`p-2 rounded-full transition-colors relative group ${
                                           isDownloading 
                                            ? 'text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20' 
                                            : azhanDownloads[m.id] 
                                                ? 'text-emerald-500 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20' 
                                                : 'text-navy-400 hover:text-gold-500 hover:bg-gold-50 dark:hover:bg-navy-800'
                                       }`}
                                       title={isDownloading ? "إلغاء التحميل" : azhanDownloads[m.id] ? "محمل (اضغط للحذف)" : "تحميل"}
                                     >
                                        {isDownloading ? (
                                            <div className="relative">
                                                <Square size={12} fill="currentColor" />
                                                <span className="absolute -top-1 -right-1 flex h-2 w-2">
                                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                                </span>
                                            </div>
                                        ) : azhanDownloads[m.id] ? (
                                            <div className="relative">
                                                <Check size={16} className="group-hover:hidden" />
                                                <Trash2 size={16} className="hidden group-hover:block" />
                                            </div>
                                        ) : (
                                            <Download size={16} />
                                        )}
                                     </button>
                                     
                                     {azhanId === m.id && <div className="w-1.5 h-1.5 rounded-full bg-gold-500 shrink-0"></div>}
                                   </div>
                                 );
                               })}
                            </div>
                         </div>
                         
                         {/* Font Size */}
                         <div>
                            <label className="flex items-center gap-2 text-sm font-bold text-navy-700 dark:text-navy-300 mb-3">
                              <Type size={18} className="text-gold-500" /> حجم الخط
                            </label>
                            <div className="flex items-center gap-3 bg-navy-50 dark:bg-navy-950 p-3 rounded-xl border border-navy-100 dark:border-navy-800">
                              <span className="text-xs font-bold text-navy-400">A</span>
                              <input type="range" min="18" max="50" value={fontSize} onChange={(e) => setFontSize(parseInt(e.target.value))} className="flex-1 accent-gold-600 h-2 bg-navy-200 dark:bg-navy-700 rounded-lg cursor-pointer" />
                              <span className="text-xl font-bold text-navy-900 dark:text-white">A</span>
                            </div>
                         </div>
                      </div>
                    </div>
                  </div>
                )}

                <Sidebar isOpen={isSidebarOpen} close={() => setSidebarOpen(false)} navigateToSurah={(n) => navigate(`/reader?surah=${n}`)} openSettings={() => setIsSettingsOpen(true)} />
                
                <aside className={`hidden md:flex flex-col border-l border-navy-100 dark:border-navy-800 bg-white dark:bg-navy-900 z-30 shadow-sm transition-all duration-500 ease-in-out overflow-hidden ${isFullscreen ? 'w-0 opacity-0 pointer-events-none border-none' : 'w-72 opacity-100'}`}>
                  <div className="p-8 flex items-center gap-3 cursor-pointer hover:opacity-90 min-w-[280px]" onClick={() => navigate('/')}>
                    <div className="w-12 h-12 bg-navy-900 dark:bg-white rounded-2xl flex items-center justify-center text-white dark:text-navy-900 shadow-xl shadow-navy-900/10">
                      <span className="font-quran text-3xl font-bold mt-1">ب</span>
                    </div>
                    <div>
                      <h1 className="text-2xl font-bold font-quran tracking-tight text-navy-900 dark:text-white">البيان</h1>
                      <span className="text-[10px] text-gold-600 dark:text-gold-400 font-bold tracking-wider uppercase block">Quran & Sunnah</span>
                    </div>
                  </div>
                  
                  <nav className="flex-1 px-4 space-y-1 overflow-y-auto py-4 custom-scrollbar min-w-[280px]">
                    <div className="text-xs font-bold text-navy-400 px-4 mb-2 mt-2 uppercase tracking-wider">القائمة الرئيسية</div>
                    <DesktopNavItem to="/" icon={<Home size={20} />} label="الرئيسية" />
                    <DesktopNavItem to="/reader" icon={<BookOpen size={20} />} label="المصحف الكريم" />
                    <DesktopNavItem to="/search" icon={<Search size={20} />} label="بحث" />
                    <DesktopNavItem to="/radio" icon={<Radio size={20} />} label="الإذاعة المباشرة" />
                    <DesktopNavItem to="/downloads" icon={<WifiOff size={20} />} label="التحميلات (أوفلاين)" />
                    
                    <div className="text-xs font-bold text-navy-400 px-4 mb-2 mt-6 uppercase tracking-wider">أدوات المسلم</div>
                    <DesktopNavItem to="/hifz" icon={<Activity size={20} />} label="خطة الحفظ" />
                    <DesktopNavItem to="/adhkar" icon={<Shield size={20} />} label="حصن المسلم" />
                    <DesktopNavItem to="/events" icon={<Calendar size={20} />} label="المناسبات" />
                    <DesktopNavItem to="/hadith" icon={<BookHeart size={20} />} label="الحديث الشريف" />
                    <DesktopNavItem to="/tasbih" icon={<Grid size={20} />} label="السبحة" />
                    <DesktopNavItem to="/bookmarks" icon={<Bookmark size={20} />} label="المحفوظات" />
                    <DesktopNavItem to="/waqf" icon={<Info size={20} />} label="علامات الوقف" />
                    <DesktopNavItem to="/notifications" icon={
                      <div className="relative">
                        <Bell size={20} />
                        {unreadCount > 0 && <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full animate-pulse ring-2 ring-white dark:ring-navy-900"></span>}
                      </div>
                    } label="التنبيهات" />
                    <DesktopNavItem to="/about" icon={<Heart size={20} />} label="عن التطبيق" />
                  </nav>
                </aside>

                <div className="flex-1 flex flex-col h-full relative overflow-hidden">
                  <main className="flex-1 overflow-y-auto overflow-x-hidden relative pb-24 md:pb-24 scroll-smooth">
                    <Outlet />
                  </main>

                  {/* Render Players: Exclusive Logic */}
                  {currentTrack ? <AudioPlayerBar /> : radioStation ? <RadioPlayerBar /> : null}

                  <nav className={`h-[70px] bg-white dark:bg-navy-900 border-t border-navy-100 dark:border-navy-800 grid grid-cols-6 gap-0 items-center px-2 z-40 fixed bottom-0 w-full md:hidden shadow-[0_-5px_20px_rgba(0,0,0,0.03)] pb-2 pt-1 transition-all duration-500 ease-in-out ${isFullscreen ? 'translate-y-full opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'}`}>
                    <NavItem to="/" icon={<Home size={22} />} label="الرئيسية" />
                    <NavItem to="/reader" icon={<BookOpen size={22} />} label="المصحف" />
                    <NavItem to="/hifz" icon={<Activity size={22} />} label="الحفظ" />
                    <NavItem to="/radio" icon={<Radio size={22} />} label="الإذاعة" />
                    <NavItem to="/adhkar" icon={<Shield size={22} />} label="الأذكار" />
                    <NavItem to="/tasbih" icon={<Grid size={22} />} label="السبحة" />
                  </nav>
                </div>
                
              </div>
            </NavigationContext.Provider>
          </RadioContext.Provider>
        </AudioContext.Provider>
      </SettingsContext.Provider>
    </ThemeContext.Provider>
  );
};