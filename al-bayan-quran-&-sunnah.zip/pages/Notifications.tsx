
import React, { useEffect, useState } from 'react';
import { TopBar } from '../components/TopBar';
import { getNotifications, markNotificationsRead, clearNotifications } from '../services/storage';
import { AppNotification } from '../types';
import { Bell, Calendar, Info, Trash2, CheckCircle2, Clock } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';

export const Notifications: React.FC = () => {
  const [list, setList] = useState<AppNotification[]>([]);

  useEffect(() => {
    setList(getNotifications());
    // Mark as read after a short delay so user sees "new" status briefly
    const timer = setTimeout(() => {
        markNotificationsRead();
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleClear = () => {
    if (window.confirm('هل تريد مسح جميع الإشعارات؟')) {
      clearNotifications();
      setList([]);
    }
  };

  const getIconData = (type: AppNotification['type']) => {
    switch (type) {
      case 'event': return { icon: <Calendar size={20} />, bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-600 dark:text-amber-400' };
      case 'reminder': return { icon: <CheckCircle2 size={20} />, bg: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-600 dark:text-emerald-400' };
      default: return { icon: <Info size={20} />, bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400' };
    }
  };

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar 
        title="التنبيهات والإشعارات" 
        extra={
          list.length > 0 && (
            <button 
              onClick={handleClear} 
              className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-full hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors text-xs font-bold"
            >
              <Trash2 size={14} />
              <span>مسح الكل</span>
            </button>
          )
        }
      />
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 custom-scrollbar">
        <div className="max-w-3xl mx-auto space-y-4">
          
          {list.length > 0 ? (
            list.map(item => {
              const { icon, bg, text } = getIconData(item.type);
              
              return (
                <div 
                  key={item.id} 
                  className={`relative p-5 rounded-2xl border transition-all duration-300 group ${
                    !item.isRead 
                      ? 'bg-white dark:bg-navy-900 border-gold-300 dark:border-gold-700 shadow-md shadow-gold-500/5' 
                      : 'bg-white dark:bg-navy-900 border-navy-100 dark:border-navy-800 opacity-90 hover:opacity-100 hover:shadow-sm'
                  }`}
                >
                  <div className="flex gap-4">
                    <div className={`mt-1 w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${bg} ${text}`}>
                      {icon}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1.5">
                        <h3 className={`font-bold text-base md:text-lg ${!item.isRead ? 'text-navy-900 dark:text-white' : 'text-navy-700 dark:text-navy-200'}`}>
                          {item.title}
                        </h3>
                        {!item.isRead && (
                          <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse shadow-sm"></span>
                        )}
                      </div>
                      
                      <p className="text-sm text-navy-600 dark:text-navy-300 leading-relaxed">
                        {item.content}
                      </p>
                      
                      <div className="flex items-center gap-1.5 mt-3 text-[10px] font-bold text-navy-400">
                        <Clock size={12} />
                        <span>
                          {new Date(item.timestamp).toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' })}
                          {' • '}
                          {new Date(item.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center animate-in fade-in slide-in-from-bottom-4">
              <div className="w-24 h-24 bg-navy-100 dark:bg-navy-800 rounded-full flex items-center justify-center mb-6 shadow-inner">
                <Bell size={40} className="text-navy-300 dark:text-navy-500" />
              </div>
              <h3 className="text-xl font-bold text-navy-800 dark:text-white mb-2">لا توجد تنبيهات جديدة</h3>
              <p className="text-navy-500 dark:text-navy-400 max-w-xs mx-auto">
                ستظهر هنا الإشعارات الخاصة بالأذكار، المناسبات الإسلامية، وتحديثات التطبيق.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
