
import React, { useState, useEffect, useRef } from 'react';
import { TopBar } from '../components/TopBar';
import { HadithBook, Hadith as HadithType } from '../types';
import { searchHadith } from '../services/api';
import { Search, Book, Info, Copy, Share2, Check, ChevronDown, ChevronUp, Globe, BookOpen, Library, X, Filter } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';

export const HadithPage: React.FC = () => {
  const [activeBook, setActiveBook] = useState<HadithBook>(HadithBook.ALL);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<HadithType[]>([]);
  const [loading, setLoading] = useState(false);
  const searchTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Tabs Configuration
  const TABS = [
    { id: HadithBook.ALL, label: 'بحث الدرر', icon: <Search size={16} /> },
    { id: HadithBook.BUKHARI, label: 'البخاري', icon: <BookOpen size={16} /> },
    { id: HadithBook.MUSLIM, label: 'مسلم', icon: <BookOpen size={16} /> },
    { id: HadithBook.NAWAWI, label: 'الأربعين', icon: <Book size={16} /> },
    { id: HadithBook.RIYAD, label: 'رياض الصالحين', icon: <Library size={16} /> },
  ];

  // Logic: Load data when Book changes
  useEffect(() => {
    setResults([]);
    setQuery('');
    
    // If browsing a specific book, load initial data automatically
    if (activeBook !== HadithBook.ALL) {
        performSearch('', activeBook);
    }
  }, [activeBook]);

  const performSearch = async (searchText: string, book: HadithBook) => {
    setLoading(true);
    try {
        const data = await searchHadith(searchText, book);
        setResults(data);
    } catch (e) {
        console.error(e);
    } finally {
        setLoading(false);
    }
  };

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);

    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);

    // If searching in "ALL" (Dorar), debounce heavily (proxy/api call)
    // If searching inside a specific book, we could filter locally or fetch, but stick to generic search for consistency
    
    if (val.trim().length === 0) {
        if (activeBook === HadithBook.ALL) {
            setResults([]); 
            setLoading(false);
        } else {
            // Reload default book content
            performSearch('', activeBook);
        }
        return;
    }

    setLoading(true);
    searchTimeoutRef.current = setTimeout(() => {
        performSearch(val, activeBook);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="الموسوعة الحديثية" />
      
      {/* 1. Tabs Segmented Control (Style from Adhkar.tsx) */}
      <div className="px-4 pt-4 sticky top-0 z-20 bg-gold-50/95 dark:bg-navy-950/95 backdrop-blur-sm">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveBook(tab.id)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all border ${
                activeBook === tab.id 
                  ? 'bg-navy-800 text-white border-navy-800 shadow-md scale-105' 
                  : 'bg-white dark:bg-navy-900 text-navy-600 dark:text-navy-300 border-navy-100 dark:border-navy-700 hover:bg-navy-50'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Search Bar (Style from Search.tsx) */}
      <div className="px-4 pt-2 pb-2 z-10">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={handleSearchInput}
            placeholder={activeBook === HadithBook.ALL ? "ابحث عن أي حديث في الدرر السنية..." : "بحث أو تصفية..."}
            className="w-full h-12 pl-12 pr-12 rounded-2xl border border-navy-200 dark:border-navy-700 bg-white dark:bg-navy-900 text-navy-900 dark:text-white shadow-sm focus:ring-2 focus:ring-gold-500 outline-none transition-all placeholder:text-navy-400 font-bold text-sm"
          />
          <div className="absolute right-4 top-3.5 text-navy-400">
             {activeBook === HadithBook.ALL ? <Globe size={20} /> : <Filter size={20} />}
          </div>
          {query && (
            <button 
                onClick={() => { setQuery(''); if(activeBook !== HadithBook.ALL) performSearch('', activeBook); else setResults([]); }}
                className="absolute left-3 top-3 p-1.5 bg-navy-100 dark:bg-navy-800 text-navy-500 rounded-full hover:bg-red-100 hover:text-red-500 transition-colors"
            >
                <X size={14} />
            </button>
          )}
        </div>
        
        {/* Helper Text for Dorar */}
        {activeBook === HadithBook.ALL && !query && results.length === 0 && (
            <div className="text-center mt-8 opacity-60 animate-in fade-in">
                <div className="w-20 h-20 bg-navy-100 dark:bg-navy-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search size={40} className="text-navy-300 dark:text-navy-500" />
                </div>
                <p className="text-sm font-bold text-navy-600 dark:text-navy-400">ابحث عن صحة الأحاديث</p>
                <p className="text-xs text-navy-400 mt-1">يعتمد البحث على محرك الدرر السنية</p>
            </div>
        )}
      </div>

      {/* 3. Content Area */}
      <div className="flex-1 overflow-y-auto px-4 pb-24 custom-scrollbar">
        <div className="max-w-4xl mx-auto space-y-4">
            
            {/* Loading */}
            {loading && (
                <div className="flex flex-col items-center justify-center py-10 gap-3 opacity-70">
                    <div className="w-8 h-8 border-4 border-gold-500 border-t-transparent rounded-full animate-spin"></div>
                    <p className="text-xs font-bold text-navy-500 dark:text-navy-300">جاري الاتصال...</p>
                </div>
            )}

            {/* Results */}
            {!loading && results.length > 0 && (
                results.map((hadith) => (
                    <HadithCard key={hadith.id} hadith={hadith} />
                ))
            )}

            {/* No Results */}
            {!loading && query && results.length === 0 && (
                <div className="text-center py-10 opacity-60">
                    <p className="text-sm font-bold text-navy-500">لا توجد نتائج مطابقة</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

// --- Standardized Card Component ---
const HadithCard: React.FC<{ hadith: HadithType }> = ({ hadith }) => {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);

  // Analyze Grade to color-code it
  const getGradeStyle = (text: string) => {
      if (!text) return 'bg-navy-50 text-navy-500 border-navy-100';
      if (text.includes('صحيح') || text.includes('جيد') || text.includes('ثابت')) 
          return 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800';
      if (text.includes('حسن')) 
          return 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-800';
      if (text.includes('ضعيف') || text.includes('موضوع') || text.includes('منكر')) 
          return 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800';
      return 'bg-navy-50 dark:bg-navy-800 text-navy-500 dark:text-navy-400 border-navy-100 dark:border-navy-700';
  };

  const gradeInfo = hadith.explanation && hadith.explanation.includes('حكم') 
    ? hadith.explanation.split('|')[0].replace('حكم المحدث:', '').trim()
    : null;

  const handleCopy = () => {
    navigator.clipboard.writeText(`${hadith.text}\n\n[${hadith.sourceName}]\n${hadith.explanation || ''}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ title: 'حديث شريف', text: `${hadith.text}\n\n[${hadith.sourceName}]` }).catch(console.error);
    } else {
      handleCopy();
    }
  };

  return (
    <div className="bg-white dark:bg-navy-900 rounded-2xl p-5 shadow-sm border border-navy-100 dark:border-navy-800 hover:shadow-md transition-all group overflow-hidden animate-in slide-in-from-bottom-2 duration-500 relative">
      
      {/* Header Meta */}
      <div className="flex flex-wrap justify-between items-start gap-3 mb-4 pb-3 border-b border-navy-50 dark:border-navy-800">
        <div className="flex items-center gap-3">
           <div className="p-2 bg-navy-50 dark:bg-navy-800 rounded-lg text-navy-600 dark:text-gold-500">
             <Book size={18} />
           </div>
           <div>
             <h3 className="font-bold text-navy-900 dark:text-white text-sm">
                {hadith.sourceName}
             </h3>
             {hadith.chapter && (
               <span className="text-[10px] text-navy-500 dark:text-navy-400 block mt-0.5 max-w-[200px] truncate">
                 {hadith.chapter}
               </span>
             )}
           </div>
        </div>
        
        {gradeInfo && (
            <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border ${getGradeStyle(gradeInfo)}`}>
               {gradeInfo}
            </span>
        )}
      </div>

      {/* Body Text */}
      <div className="mb-4">
         <p className="font-quran text-lg sm:text-xl leading-[2.4] text-navy-800 dark:text-gray-100 text-justify">
           {hadith.text}
         </p>
      </div>

      {/* Footer Actions */}
      <div className="flex items-center justify-between mt-2 pt-2">
         <div className="flex gap-2">
            <button onClick={handleCopy} className="p-2 text-navy-400 hover:text-gold-500 hover:bg-gold-50 dark:hover:bg-navy-800 rounded-lg transition-all" title="نسخ">
              {copied ? <Check size={16} className="text-emerald-500" /> : <Copy size={16} />}
            </button>
            <button onClick={handleShare} className="p-2 text-navy-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-navy-800 rounded-lg transition-all" title="مشاركة">
              <Share2 size={16} />
            </button>
         </div>

         {hadith.explanation && hadith.explanation.length > 5 && (
           <button 
             onClick={() => setExpanded(!expanded)}
             className="flex items-center gap-1 text-[10px] font-bold text-navy-500 hover:text-navy-800 dark:text-navy-400 dark:hover:text-white transition-colors bg-navy-50 dark:bg-navy-800 px-3 py-1.5 rounded-lg"
           >
             {expanded ? 'إخفاء التفاصيل' : 'التخريج والحكم'}
             {expanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
           </button>
         )}
      </div>

      {/* Expanded Info */}
      {expanded && (
        <div className="mt-4 pt-3 border-t border-navy-50 dark:border-navy-800 animate-in fade-in">
          <div className="flex gap-2 items-start text-xs text-navy-600 dark:text-navy-300 bg-gold-50/50 dark:bg-navy-950/50 p-3 rounded-xl">
            <Info size={14} className="text-gold-500 mt-0.5 shrink-0" />
            <p className="leading-relaxed">{hadith.explanation}</p>
          </div>
        </div>
      )}
    </div>
  );
};
