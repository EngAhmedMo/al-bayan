
import React, { useState, useEffect, useRef } from 'react';
import { TopBar } from '../components/TopBar';
import { RECITERS, fetchSurahs } from '../services/api';
import { Surah } from '../types';
import { downloadSurah, isSurahDownloaded, deleteSurahFromCache, downloadQueueProcessor, deleteAllSurahs, isAzhanDownloaded, deleteAzhanFromCache, downloadAzhan } from '../services/offlineAudio';
import { MUAZZINS } from '../services/azhanData';
import { useSettings } from '../components/Layout';
import { Download, CheckCircle, Trash2, WifiOff, Loader2, Mic, AlertCircle, XCircle, HardDriveDownload, Pause, Play, Volume2, Music, Square, MapPin } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';

const AZHAN_TAB_ID = 'TAB_AZHAN';

export const Downloads: React.FC = () => {
  const { reciterId, setReciterId } = useSettings();
  const [surahs, setSurahs] = useState<Surah[]>([]);
  
  // Status Tracking
  const [downloadStatus, setDownloadStatus] = useState<Record<number, 'downloaded' | 'none'>>({});
  const [azhanStatus, setAzhanStatus] = useState<Record<string, boolean>>({});
  
  // Surah Progress & Abort Control
  const [activeSurahDownloads, setActiveSurahDownloads] = useState<Record<number, AbortController>>({});
  const [surahProgress, setSurahProgress] = useState<Record<number, number>>({});

  // Azhan Progress & Abort Control
  const [activeAzhanDownloads, setActiveAzhanDownloads] = useState<Record<string, AbortController>>({});
  const [azhanProgress, setAzhanProgress] = useState<Record<string, number>>({});

  const [activeTab, setActiveTab] = useState(reciterId);

  // Bulk State
  const [isBulkActive, setIsBulkActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);
  const [bulkProgress, setBulkProgress] = useState<{ completed: number, total: number } | null>(null);
  const [downloadQueue, setDownloadQueue] = useState<number[]>([]);
  const bulkAbortControllerRef = useRef<AbortController | null>(null);

  const isAzhanMode = activeTab === AZHAN_TAB_ID;

  useEffect(() => {
    fetchSurahs().then(setSurahs);
  }, []);

  const checkDownloads = async () => {
    if (isAzhanMode) {
        const statuses: Record<string, boolean> = {};
        for (const m of MUAZZINS) {
            statuses[m.id] = await isAzhanDownloaded(m.id);
        }
        setAzhanStatus(statuses);
    } else {
        if (surahs.length === 0) return;
        const statusMap: Record<number, 'downloaded' | 'none'> = {};
        await Promise.all(surahs.map(async (s) => {
          const isDown = await isSurahDownloaded(activeTab, s.number);
          statusMap[s.number] = isDown ? 'downloaded' : 'none';
        }));
        setDownloadStatus(prev => ({ ...prev, ...statusMap }));
    }
  };

  useEffect(() => {
    checkDownloads();
  }, [surahs, activeTab]);

  // --- Single Surah Operations ---

  const handleDownloadSurah = async (surah: Surah) => {
    const controller = new AbortController();
    setActiveSurahDownloads(prev => ({ ...prev, [surah.number]: controller }));
    setSurahProgress(prev => ({ ...prev, [surah.number]: 1 }));

    try {
      await downloadSurah(
          activeTab, 
          surah.number, 
          (pct) => {
             setSurahProgress(prev => ({ ...prev, [surah.number]: pct }));
          },
          controller.signal
      );
      setDownloadStatus(prev => ({ ...prev, [surah.number]: 'downloaded' }));
    } catch (e: any) {
      if (e.name !== 'AbortError' && e.message !== 'ABORTED') {
          console.error(e);
          alert('فشل التحميل، يرجى التحقق من الإنترنت');
      }
    } finally {
      setActiveSurahDownloads(prev => {
          const newState = { ...prev };
          delete newState[surah.number];
          return newState;
      });
      setSurahProgress(prev => ({ ...prev, [surah.number]: 0 }));
    }
  };

  const handleCancelSurah = (surahNum: number) => {
      const controller = activeSurahDownloads[surahNum];
      if (controller) controller.abort();
  };

  const handleDeleteSurah = async (surah: Surah) => {
    if (!window.confirm(`هل تريد حذف سورة ${surah.name} من التخزين؟`)) return;
    await deleteSurahFromCache(activeTab, surah.number);
    setDownloadStatus(prev => ({ ...prev, [surah.number]: 'none' }));
  };

  // --- Azhan Operations (Updated) ---

  const handleDownloadAzhan = async (id: string) => {
    const controller = new AbortController();
    setActiveAzhanDownloads(prev => ({ ...prev, [id]: controller }));
    setAzhanProgress(prev => ({ ...prev, [id]: 1 }));

    try {
        await downloadAzhan(id, (pct) => {
            setAzhanProgress(prev => ({ ...prev, [id]: pct }));
        }, controller.signal);
        
        setAzhanStatus(prev => ({...prev, [id]: true}));
    } catch (e: any) {
        if (e.name !== 'AbortError') alert("فشل التحميل، تأكد من الاتصال");
    } finally {
        setActiveAzhanDownloads(prev => {
            const newState = { ...prev };
            delete newState[id];
            return newState;
        });
        setAzhanProgress(prev => ({ ...prev, [id]: 0 }));
    }
  };

  const handleCancelAzhan = (id: string) => {
      const controller = activeAzhanDownloads[id];
      if (controller) controller.abort();
  };

  const handleDeleteAzhan = async (id: string) => {
      if(!window.confirm("هل تريد حذف هذا الأذان؟")) return;
      await deleteAzhanFromCache(id);
      setAzhanStatus(prev => ({...prev, [id]: false}));
  };

  const handleDownloadAllAzhans = async () => {
      const toDownload = MUAZZINS.filter(m => !azhanStatus[m.id]);
      if (toDownload.length === 0) {
          alert("جميع الأذانات محملة بالفعل");
          return;
      }
      toDownload.forEach(m => handleDownloadAzhan(m.id));
  };

  const handleDeleteAllAzhans = async () => {
      if(!window.confirm("هل تريد حذف جميع الأذانات؟")) return;
      for(const m of MUAZZINS) {
          if(azhanStatus[m.id]) await deleteAzhanFromCache(m.id);
      }
      checkDownloads();
  };

  // --- Bulk Operations (Surahs) ---

  const startQueueProcessing = async (queue: number[], initialCompleted: number, total: number) => {
      setIsBulkActive(true);
      setIsPaused(false);
      bulkAbortControllerRef.current = new AbortController();

      try {
          await downloadQueueProcessor(
              activeTab,
              queue,
              (completedSurahNum) => {
                  setDownloadStatus(prev => ({ ...prev, [completedSurahNum]: 'downloaded' }));
                  setDownloadQueue(prev => prev.filter(id => id !== completedSurahNum));
              },
              (completedCount) => {
                  setBulkProgress({ completed: completedCount, total });
              },
              initialCompleted,
              bulkAbortControllerRef.current.signal
          );
          setIsBulkActive(false);
          setBulkProgress(null);
          setDownloadQueue([]);
          await checkDownloads();
      } catch (e: any) {
          if (e.message === "PAUSED") {
              setIsPaused(true);
          } else {
              console.error(e);
              alert("حدث خطأ أثناء التحميل. تم الإيقاف.");
              setIsBulkActive(false);
              setBulkProgress(null);
          }
      }
  };

  const handleStartBulk = () => {
    const toDownload = surahs.filter(s => downloadStatus[s.number] !== 'downloaded').map(s => s.number);
    if (toDownload.length === 0) {
        alert("جميع السور محملة بالفعل!");
        return;
    }
    setDownloadQueue(toDownload);
    setBulkProgress({ completed: 0, total: toDownload.length });
    startQueueProcessing(toDownload, 0, toDownload.length);
  };

  const handlePauseBulk = () => bulkAbortControllerRef.current?.abort();
  const handleResumeBulk = () => bulkProgress && startQueueProcessing(downloadQueue, bulkProgress.completed, bulkProgress.total);
  const handleCancelBulk = () => {
      bulkAbortControllerRef.current?.abort();
      setIsBulkActive(false);
      setIsPaused(false);
      setBulkProgress(null);
      setDownloadQueue([]);
  };

  const handleDeleteAllSurahs = async () => {
    const count = Object.values(downloadStatus).filter(s => s === 'downloaded').length;
    if (count === 0) return;
    if (!window.confirm(`هل أنت متأكد من حذف ${toArabicDigits(count)} سورة للقارئ الحالي؟`)) return;
    setIsBulkDeleting(true);
    try {
        await deleteAllSurahs(activeTab);
        await checkDownloads();
    } finally {
        setIsBulkDeleting(false);
    }
  };

  const currentReciterName = RECITERS.find(r => r.id === activeTab)?.name;
  const surahsDownloadedCount = Object.values(downloadStatus).filter(s => s === 'downloaded').length;
  const azhansDownloadedCount = Object.values(azhanStatus).filter(s => s).length;
  const totalCount = isAzhanMode ? MUAZZINS.length : surahs.length;
  const currentCount = isAzhanMode ? azhansDownloadedCount : surahsDownloadedCount;

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="إدارة التحميلات" />
      
      <div className="flex-1 overflow-y-auto pb-24">
        
        {/* Header / Tabs */}
        <div className="p-4 bg-white dark:bg-navy-900 border-b border-navy-100 dark:border-navy-800 shadow-sm sticky top-0 z-20">
           <div className="mb-4">
             <h2 className="text-lg font-bold text-navy-900 dark:text-white flex items-center gap-2">
               <WifiOff className="text-gold-500" /> الاستماع دون إنترنت
             </h2>
             <p className="text-xs text-navy-500 dark:text-navy-400 mt-1">
               {isAzhanMode 
                 ? "تحميل ملفات الأذان عالية الجودة للتنبيهات."
                 : "تحميل المصحف للاستماع دون اتصال بالإنترنت."
               }
             </p>
           </div>

           {/* Horizontal Tabs */}
           <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar mb-2">
             {RECITERS.map(r => (
               <button
                 key={r.id}
                 onClick={() => !isBulkActive && setActiveTab(r.id)}
                 disabled={isBulkActive}
                 className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${
                   activeTab === r.id
                     ? 'bg-navy-800 text-white border-navy-800 shadow-md'
                     : 'bg-navy-50 dark:bg-navy-800 text-navy-600 dark:text-navy-300 border-navy-100 dark:border-navy-700 hover:bg-navy-100'
                 } ${isBulkActive ? 'opacity-50 cursor-not-allowed' : ''}`}
               >
                 {activeTab === r.id && <Mic size={12} />}
                 {r.name}
               </button>
             ))}
             
             {/* Special Azhan Tab */}
             <button
                 onClick={() => !isBulkActive && setActiveTab(AZHAN_TAB_ID)}
                 disabled={isBulkActive}
                 className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all border ${
                   activeTab === AZHAN_TAB_ID
                     ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                     : 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-800 hover:bg-emerald-100'
                 }`}
               >
                 {activeTab === AZHAN_TAB_ID ? <Volume2 size={12} className="animate-pulse" /> : <Music size={12} />}
                 أصوات الأذان
             </button>
           </div>

           {/* --- BULK ACTION DASHBOARD --- */}
           <div className="bg-navy-50 dark:bg-navy-950 rounded-xl p-4 border border-navy-100 dark:border-navy-800 transition-all">
              <div className="flex justify-between items-center mb-3">
                 <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-navy-600 dark:text-navy-300">حالة التخزين:</span>
                    <span className="bg-white dark:bg-navy-800 px-2 py-0.5 rounded-lg text-xs font-bold text-gold-600 dark:text-gold-500 border border-navy-100 dark:border-navy-700 shadow-sm">
                        {toArabicDigits(currentCount)} / {toArabicDigits(totalCount)} {isAzhanMode ? 'أذان' : 'سورة'}
                    </span>
                 </div>
                 
                 {currentCount > 0 && !isBulkActive && (
                     <button 
                       onClick={isAzhanMode ? handleDeleteAllAzhans : handleDeleteAllSurahs}
                       disabled={isBulkDeleting}
                       className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
                     >
                       {isBulkDeleting ? <Loader2 size={12} className="animate-spin" /> : <Trash2 size={12} />}
                       حذف الكل
                     </button>
                 )}
              </div>

              {/* Progress UI */}
              {bulkProgress && (isBulkActive || isPaused) ? (
                  <div className="space-y-3">
                      <div className="flex justify-between text-xs font-bold text-navy-600 dark:text-navy-300">
                          <span>{isPaused ? 'التحميل متوقف مؤقتاً' : 'جاري تحميل الباقة...'}</span>
                          <span>{toArabicDigits(bulkProgress.completed)} من {toArabicDigits(bulkProgress.total)}</span>
                      </div>
                      
                      <div className="w-full h-3 bg-navy-200 dark:bg-navy-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-300 ${isPaused ? 'bg-amber-500' : 'bg-gold-500 striped-bar'}`}
                            style={{ width: `${(bulkProgress.completed / bulkProgress.total) * 100}%` }}
                          ></div>
                      </div>
                      
                      <div className="flex gap-2">
                          {!isPaused ? (
                              <button onClick={handlePauseBulk} className="flex-1 py-2 bg-amber-50 text-amber-600 rounded-lg text-xs font-bold flex justify-center items-center gap-2 hover:bg-amber-100"><Pause size={14} /> إيقاف مؤقت</button>
                          ) : (
                              <button onClick={handleResumeBulk} className="flex-1 py-2 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-bold flex justify-center items-center gap-2 hover:bg-emerald-100"><Play size={14} /> استكمال</button>
                          )}
                          <button onClick={handleCancelBulk} className="flex-1 py-2 bg-red-50 text-red-500 rounded-lg text-xs font-bold flex justify-center items-center gap-2 hover:bg-red-100"><XCircle size={14} /> إلغاء</button>
                      </div>
                  </div>
              ) : (
                  <button 
                    onClick={isAzhanMode ? handleDownloadAllAzhans : handleStartBulk}
                    disabled={currentCount === totalCount || isBulkDeleting}
                    className={`w-full py-3 rounded-xl flex items-center justify-center gap-2 font-bold text-sm shadow-sm transition-all ${
                        currentCount === totalCount 
                        ? 'bg-emerald-100 text-emerald-700 cursor-default'
                        : 'bg-gold-500 hover:bg-gold-600 text-navy-900'
                    }`}
                  >
                    {currentCount === totalCount ? (
                        <>
                          <CheckCircle size={18} /> {isAzhanMode ? 'كل الأذانات محملة' : 'المصحف محمل بالكامل'}
                        </>
                    ) : (
                        <>
                          <HardDriveDownload size={18} /> {isAzhanMode ? 'تحميل كل الأذانات' : `تحميل المصحف كاملاً (${currentReciterName})`}
                        </>
                    )}
                  </button>
              )}
           </div>
        </div>

        {/* --- MAIN CONTENT LIST --- */}
        <div className="p-4 space-y-3">
           {isAzhanMode ? (
               // --- AZHAN LIST (Grouped for better UX) ---
               MUAZZINS.map(m => {
                    const isDownloading = !!activeAzhanDownloads[m.id];
                    const pct = azhanProgress[m.id] || 0;
                    const isDownloaded = azhanStatus[m.id];
                    const isEgyptian = m.style === 'egyptian';

                    return (
                        <div key={m.id} className={`flex items-center justify-between p-4 rounded-xl border shadow-sm animate-in slide-in-from-bottom-2 ${isEgyptian ? 'bg-white dark:bg-navy-900 border-gold-200 dark:border-gold-900/50' : 'bg-slate-50 dark:bg-navy-950 border-navy-100 dark:border-navy-800'}`}>
                            <div className="flex items-center gap-3 flex-1">
                                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${isEgyptian ? 'bg-gold-50 dark:bg-gold-900/20 text-gold-600' : 'bg-navy-100 dark:bg-navy-800 text-navy-500'}`}>
                                    {isEgyptian ? <MapPin size={20} /> : <Volume2 size={20} />}
                                </div>
                                <div className="flex-1">
                                    <span className="font-bold text-sm text-navy-900 dark:text-white block">{m.name}</span>
                                    {m.style === 'egyptian' && <span className="text-[9px] text-gold-600 dark:text-gold-500 font-bold bg-gold-50 dark:bg-navy-800 px-1.5 py-0.5 rounded ml-1">المدرسة المصرية</span>}
                                    {isDownloading && (
                                        <div className="w-full max-w-[120px] h-1 bg-navy-200 mt-1.5 rounded-full overflow-hidden">
                                            <div className="h-full bg-gold-500 transition-all duration-300" style={{ width: `${pct}%` }}></div>
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            {isDownloaded ? (
                                <div className="flex items-center gap-2">
                                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">محمل</span>
                                    <button onClick={() => handleDeleteAzhan(m.id)} className="p-2 text-red-400 bg-red-50 dark:bg-red-900/10 rounded-full hover:bg-red-100 transition-colors">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ) : isDownloading ? (
                                <div className="flex items-center gap-2">
                                    <span className="text-[10px] font-bold text-gold-600">{toArabicDigits(pct)}%</span>
                                    <button onClick={() => handleCancelAzhan(m.id)} className="p-2 text-red-500 bg-red-50 dark:bg-red-900/20 rounded-full hover:bg-red-100 transition-colors">
                                        <Square size={12} fill="currentColor" />
                                    </button>
                                </div>
                            ) : (
                                <button onClick={() => handleDownloadAzhan(m.id)} className="flex items-center gap-2 px-3 py-2 bg-navy-50 dark:bg-navy-800 hover:bg-emerald-600 hover:text-white text-navy-600 dark:text-navy-300 rounded-lg text-xs font-bold transition-all">
                                    <Download size={16} />
                                    <span>تحميل</span>
                                </button>
                            )}
                        </div>
                    );
               })
           ) : (
               // --- SURAH LIST ---
               surahs.map(surah => {
                 const status = downloadStatus[surah.number] || 'none';
                 const isDownloading = !!activeSurahDownloads[surah.number];
                 const pct = surahProgress[surah.number] || 0;
                 const isQueued = isBulkActive && downloadQueue.includes(surah.number);

                 return (
                   <div key={surah.number} className="flex items-center justify-between p-4 bg-white dark:bg-navy-900 rounded-xl border border-navy-100 dark:border-navy-800 shadow-sm">
                      <div className="flex items-center gap-3 flex-1">
                         <div className="w-10 h-10 rounded-lg bg-navy-50 dark:bg-navy-800 flex items-center justify-center text-sm font-bold text-navy-600 dark:text-navy-300 font-sans">
                            {toArabicDigits(surah.number)}
                         </div>
                         <div className="flex-1">
                            <h3 className="font-bold text-navy-900 dark:text-white">{surah.name}</h3>
                            <p className="text-[10px] text-navy-400">{toArabicDigits(surah.numberOfAyahs)} آية</p>
                            
                            {isDownloading && (
                                <div className="w-full max-w-[120px] h-1 bg-navy-200 mt-2 rounded-full overflow-hidden">
                                    <div className="h-full bg-gold-500 transition-all duration-300" style={{ width: `${pct}%` }}></div>
                                </div>
                            )}
                         </div>
                      </div>

                      <div>
                         {status === 'downloaded' ? (
                           <div className="flex items-center gap-2">
                              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">محملة</span>
                              <button onClick={() => handleDeleteSurah(surah)} className="p-2 text-red-400 bg-red-50 dark:bg-red-900/10 rounded-full hover:bg-red-100 transition-colors">
                                 <Trash2 size={18} />
                              </button>
                           </div>
                         ) : isDownloading ? (
                            <div className="flex items-center gap-2">
                                <span className="text-[10px] font-bold text-gold-600">{toArabicDigits(pct)}%</span>
                                <button 
                                    onClick={() => handleCancelSurah(surah.number)}
                                    className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors relative"
                                >
                                    <Square size={12} fill="currentColor" />
                                </button>
                            </div>
                         ) : isQueued ? (
                           <span className="text-[10px] font-bold text-navy-400 bg-navy-50 dark:bg-navy-800 px-2 py-1 rounded">في الانتظار...</span>
                         ) : (
                           <button 
                             onClick={() => handleDownloadSurah(surah)}
                             disabled={isBulkActive}
                             className="flex items-center gap-2 px-3 py-2 bg-navy-50 dark:bg-navy-800 hover:bg-gold-500 hover:text-white dark:hover:bg-gold-500 text-navy-600 dark:text-navy-300 rounded-lg text-xs font-bold transition-all disabled:opacity-50"
                           >
                             <Download size={16} />
                             <span>تحميل</span>
                           </button>
                         )}
                      </div>
                   </div>
                 );
               })
           )}
        </div>

      </div>
    </div>
  );
};
