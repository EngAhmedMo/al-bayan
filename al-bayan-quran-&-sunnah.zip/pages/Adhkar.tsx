import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { TopBar } from '../components/TopBar';
import { ADHKAR_DATA } from '../services/adhkarData';
import { Zekr } from '../types';
import { 
  ArrowLeft, CheckCircle2, Heart, Plus, Trash2, PenTool, Shield, Star, Grid, 
  Moon, Sun, Sunrise, Sunset, Edit2, Book, Coffee, Home, Plane, Info, AlertTriangle, Sparkles 
} from 'lucide-react';
import { toArabicDigits } from '../services/normalization';
import { useSettings } from '../components/Layout';
import { 
  getFavoriteAdhkarIds, 
  toggleFavoriteAdhkar, 
  getCustomAdhkar, 
  addCustomAdhkar, 
  updateCustomAdhkar,
  deleteCustomAdhkar,
  getLastUsedCategory,
  setLastUsedCategory,
  getLastUsedZekrId,
  setLastUsedZekrId
} from '../services/storage';

export const Adhkar: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'all' | 'favorites'>('all');
  const [favIds, setFavIds] = useState<number[]>([]);
  const [customAdhkar, setCustomAdhkar] = useState<Zekr[]>([]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingZekr, setEditingZekr] = useState<Zekr | undefined>(undefined);

  const refreshData = () => {
    setFavIds(getFavoriteAdhkarIds());
    setCustomAdhkar(getCustomAdhkar());
  };

  useEffect(() => { refreshData(); }, []);

  // History API for Mobile Back Button
  useEffect(() => {
    const handlePopState = () => {
      // FIX: Ensure selectedCategory is checked properly before setting to null
      if (selectedCategory !== null) setSelectedCategory(null);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
    // FIX: ensured narrowing in logic below and used explicit null check above
  }, [selectedCategory]);

  const handleCategorySelect = (cat: string) => {
    window.history.pushState({ category: cat }, '');
    setLastUsedCategory(cat);
    setSelectedCategory(cat);
  };

  const handleBackToCategories = () => window.history.back();

  const timeBasedCategory = useMemo(() => {
    const hour = new Date().getHours();
    if (hour >= 4 && hour < 12) return 'أذكار الصباح';
    if (hour >= 14 && hour < 20) return 'أذكار المساء';
    if (hour >= 20 || hour < 4) return 'أذكار النوم';
    return null;
  }, []);

  const getCategoryIcon = (cat: string) => {
    if (cat.includes('الصباح')) return <Sunrise size={24} className="text-amber-500" />;
    if (cat.includes('المساء')) return <Sunset size={24} className="text-orange-500" />;
    if (cat.includes('النوم')) return <Moon size={24} className="text-indigo-500" />;
    if (cat.includes('الاستيقاظ')) return <Sun size={24} className="text-yellow-500" />;
    if (cat.includes('الصلاة')) return <Shield size={24} className="text-blue-500" />;
    if (cat.includes('المنزل')) return <Home size={24} className="text-emerald-500" />;
    if (cat.includes('سفر')) return <Plane size={24} className="text-sky-500" />;
    if (cat.includes('الطعام')) return <Coffee size={24} className="text-amber-700" />;
    if (cat === "أذكاري الخاصة") return <PenTool size={24} className="text-emerald-500" />;
    return <Sparkles size={24} className="text-gold-500" />;
  };

  const allAdhkarCombined = useMemo(() => [...customAdhkar, ...ADHKAR_DATA], [customAdhkar]);
  const sortedCategories = useMemo(() => {
    const baseCats = Array.from(new Set(allAdhkarCombined.map(item => item.category)));
    const lastUsed = getLastUsedCategory();
    const priorityList: string[] = [];
    
    // FIX: Using explicit type checks and narrowing for line 91 and related logic to avoid 'unknown' type assignment issues
    if (typeof timeBasedCategory === 'string' && baseCats.includes(timeBasedCategory)) {
      priorityList.push(timeBasedCategory);
    }
    
    if (typeof lastUsed === 'string' && lastUsed !== timeBasedCategory && baseCats.includes(lastUsed)) {
      priorityList.push(lastUsed);
    }
    
    return [...priorityList, ...baseCats.filter(c => !priorityList.includes(c))];
  }, [allAdhkarCombined, timeBasedCategory]);

  const favoriteAdhkarList = useMemo(() => allAdhkarCombined.filter(item => favIds.includes(item.id)), [favIds, allAdhkarCombined]);

  const handleSaveZekr = (zekrData: any) => {
    if (editingZekr) {
      updateCustomAdhkar(editingZekr.id, zekrData);
    } else {
      addCustomAdhkar({ ...zekrData, category: "أذكاري الخاصة" });
    }
    refreshData();
    setIsModalOpen(false);
  };

  if (selectedCategory !== null) {
    return (
      <CategoryDetail 
        category={selectedCategory} 
        onBack={handleBackToCategories} 
        favIds={favIds}
        customAdhkar={customAdhkar}
        onToggleFav={(id) => { toggleFavoriteAdhkar(id); refreshData(); }}
        onDeleteCustom={(id) => { deleteCustomAdhkar(id); refreshData(); }}
        onEditCustom={(z) => { setEditingZekr(z); setIsModalOpen(true); }}
      />
    );
  }

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="حصن المسلم" />
      
      <div className="px-5 pt-5">
        <div className="bg-white dark:bg-navy-900 p-1.5 rounded-2xl border border-navy-100 dark:border-navy-800 shadow-sm flex">
          <button onClick={() => setViewMode('all')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${viewMode === 'all' ? 'bg-navy-900 text-white shadow-lg' : 'text-navy-400'}`}>
            <Grid size={18} /> التصنيفات
          </button>
          <button onClick={() => setViewMode('favorites')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${viewMode === 'favorites' ? 'bg-gold-500 text-white shadow-lg' : 'text-navy-400'}`}>
            <Heart size={18} fill={viewMode === 'favorites' ? "currentColor" : "none"} /> المفضلة
          </button>
        </div>
      </div>

      <div className="flex-1 p-5 overflow-y-auto pb-24 custom-scrollbar">
        {viewMode === 'all' ? (
          <div className="space-y-6">
            <button onClick={() => { setEditingZekr(undefined); setIsModalOpen(true); }} className="w-full p-4 rounded-2xl border-2 border-dashed border-navy-200 dark:border-navy-800 text-navy-500 hover:border-gold-500 hover:text-gold-600 transition-all font-bold flex items-center justify-center gap-2 group bg-white/50 dark:bg-navy-900/30">
              <Plus size={20} className="group-hover:scale-125 transition-transform" /> إضافة ذكر جديد
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {sortedCategories.map((cat, idx) => (
                <button
                  key={idx}
                  onClick={() => handleCategorySelect(cat)}
                  className={`p-5 rounded-3xl shadow-sm border transition-all text-right flex items-center gap-4 group overflow-hidden relative ${
                    cat === timeBasedCategory
                      ? 'bg-gradient-to-br from-navy-800 to-navy-900 text-white border-navy-700 shadow-navy-900/20' 
                      : 'bg-white dark:bg-navy-900 border-navy-100 dark:border-navy-800 hover:border-gold-400'
                  }`}
                >
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-inner ${
                    cat === timeBasedCategory ? 'bg-white/10' : 'bg-gold-50 dark:bg-navy-800'
                  }`}>
                    {getCategoryIcon(cat)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-base truncate">{cat}</h3>
                    <p className={`text-[10px] font-bold mt-1 opacity-60 ${cat === timeBasedCategory ? 'text-gold-400' : 'text-navy-500'}`}>
                      {toArabicDigits(allAdhkarCombined.filter(i => i.category === cat).length)} ذكر متاح
                    </p>
                  </div>
                  {cat === timeBasedCategory && (
                    <div className="absolute -top-1 -left-1">
                      <div className="bg-gold-500 text-[8px] font-bold px-2 py-0.5 rounded-br-lg text-navy-900 uppercase tracking-tighter">مقترح الآن</div>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {favoriteAdhkarList.length > 0 ? (
              favoriteAdhkarList.map(zekr => (
                <ZekrCard 
                  key={zekr.id} 
                  data={zekr} 
                  isFav={true} 
                  onToggleFav={(id) => { toggleFavoriteAdhkar(id); refreshData(); }}
                />
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-center opacity-30">
                <Heart size={64} className="mb-4" />
                <p className="font-bold">قائمة المفضلة فارغة حالياً</p>
              </div>
            )}
          </div>
        )}
      </div>

      {isModalOpen && (
        <AddZekrModal 
          onClose={() => setIsModalOpen(false)} 
          onSave={handleSaveZekr} 
          initialData={editingZekr} 
        />
      )}
    </div>
  );
};

const CategoryDetail: React.FC<{ 
  category: string; 
  onBack: () => void;
  favIds: number[];
  customAdhkar: Zekr[];
  onToggleFav: (id: number) => void;
  onDeleteCustom: (id: number) => void;
  onEditCustom: (zekr: Zekr) => void;
}> = ({ category, onBack, favIds, customAdhkar, onToggleFav, onDeleteCustom, onEditCustom }) => {
  const allList = useMemo(() => [...customAdhkar, ...ADHKAR_DATA], [customAdhkar]);
  const adhkarList = useMemo(() => {
    return allList.filter(i => i.category === category).sort((a, b) => a.zekr.length - b.zekr.length);
  }, [category, allList]);

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar 
        title={category} 
        showBack={false} 
        extra={<button onClick={onBack} className="p-2 bg-navy-100 dark:bg-navy-800 rounded-xl"><ArrowLeft size={20} /></button>} 
      />
      <div className="flex-1 overflow-y-auto p-5 space-y-6 pb-24 custom-scrollbar">
        {adhkarList.map(zekr => (
          <ZekrCard 
            key={zekr.id} 
            data={zekr} 
            isFav={favIds.includes(zekr.id)}
            onToggleFav={onToggleFav}
            onDelete={category === "أذكاري الخاصة" ? () => onDeleteCustom(zekr.id) : undefined}
            onEdit={category === "أذكاري الخاصة" ? () => onEditCustom(zekr) : undefined}
          />
        ))}
      </div>
    </div>
  );
};

const ZekrCard: React.FC<{ 
  data: Zekr; 
  isFav: boolean;
  onToggleFav: (id: number) => void;
  onDelete?: () => void;
  onEdit?: () => void;
}> = React.memo(({ data, isFav, onToggleFav, onDelete, onEdit }) => {
  const target = parseInt(data.count) || 1;
  const [count, setCount] = useState(0);
  const completed = count >= target;
  const { fontSize } = useSettings();

  // Smart text cleaner: Removes unwanted brackets, indexes (1), and metadata symbols
  const cleanText = (text: string) => {
    return text
      .replace(/[{}()]/g, '')           // Remove brackets
      .replace(/\s*\[\d+\]\s*/g, ' ')   // Remove [1]
      .replace(/\s*\(\d+\)\s*/g, ' ')   // Remove (1)
      .trim();
  };

  const handleTap = useCallback(() => {
    if (!completed) {
      setCount(prev => {
        const next = prev + 1;
        if (navigator.vibrate) navigator.vibrate(next === target ? [50, 50, 50] : 10);
        if (next === target) setLastUsedZekrId(data.id);
        return next;
      });
    }
  }, [completed, target, data.id]);

  const progressPercent = Math.min(100, (count / target) * 100);

  return (
    <div 
      onClick={handleTap}
      className={`relative rounded-[2rem] transition-all cursor-pointer select-none overflow-hidden shadow-sm border ${
        completed 
          ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800' 
          : 'bg-white dark:bg-navy-900 border-navy-100 dark:border-navy-800'
      }`}
    >
      <div className="absolute bottom-0 left-0 h-1.5 bg-gold-500/30 transition-all duration-300" style={{ width: `${progressPercent}%` }} />
      {completed && <div className="absolute inset-0 bg-emerald-500/5 pointer-events-none" />}

      <div className="flex justify-between items-center px-6 pt-5 mb-2 relative z-10">
         <div className="flex gap-2">
            <button 
              onClick={(e) => { e.stopPropagation(); onToggleFav(data.id); }}
              className={`p-2.5 rounded-full transition-all ${isFav ? 'bg-rose-50 text-rose-500 shadow-sm' : 'bg-navy-50 dark:bg-navy-800 text-navy-400'}`}
            >
              <Heart size={18} fill={isFav ? "currentColor" : "none"} />
            </button>
            {onEdit && (
              <button onClick={(e) => { e.stopPropagation(); onEdit(); }} className="p-2.5 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-500"><Edit2 size={18} /></button>
            )}
            {onDelete && (
              <button onClick={(e) => { e.stopPropagation(); if(confirm('حذف الذكر؟')) onDelete(); }} className="p-2.5 rounded-full bg-red-50 dark:bg-red-900/20 text-red-500"><Trash2 size={18} /></button>
            )}
         </div>
         
         <div className={`px-4 py-1.5 rounded-xl text-xs font-bold font-sans border ${
           completed 
             ? 'bg-emerald-100 text-emerald-700 border-emerald-200' 
             : 'bg-gold-50 dark:bg-navy-800 text-gold-700 dark:text-gold-400 border-gold-100 dark:border-navy-700'
         }`}>
            {completed ? '✓ تم الإنجاز' : `${toArabicDigits(count)} / ${toArabicDigits(target)}`}
         </div>
      </div>

      <div className="px-6 pb-8 text-center relative z-10">
        <p 
          className="font-quran text-navy-900 dark:text-white mb-6 leading-[2.4] text-justify"
          style={{ fontSize: `${fontSize}px`, textAlignLast: 'center' }}
        >
           {cleanText(data.zekr)}
        </p>

        {data.description && (
          <div className="flex gap-2 items-start text-right bg-gold-50/50 dark:bg-navy-800/50 p-4 rounded-2xl border border-gold-100 dark:border-navy-700/50 mb-3">
             <Star size={16} className="text-gold-500 mt-0.5 shrink-0 fill-gold-500" />
             <span className="text-[11px] font-bold text-navy-600 dark:text-navy-300 leading-relaxed">{data.description}</span>
          </div>
        )}
        
        <div className="flex justify-between items-center opacity-40 mt-4">
           <span className="text-[9px] font-bold text-navy-400">{data.reference || 'مرجع غير محدد'}</span>
           {!completed && <span className="text-[10px] text-gold-600 animate-pulse font-bold">المس للعد</span>}
        </div>
      </div>
    </div>
  );
});

const AddZekrModal = ({ onClose, onSave, initialData }: any) => {
  const [text, setText] = useState(initialData?.zekr || '');
  const [count, setCount] = useState(initialData?.count || '1');
  const [description, setDescription] = useState(initialData?.description || '');
  const [reference, setReference] = useState(initialData?.reference || '');

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md bg-white dark:bg-navy-900 rounded-[2.5rem] shadow-2xl overflow-hidden border border-navy-100 dark:border-navy-800">
        <div className="p-6 border-b border-navy-100 dark:border-navy-800 bg-gold-50 dark:bg-navy-950 flex justify-between items-center">
          <h3 className="font-bold text-xl">{initialData ? 'تعديل الذكر' : 'إضافة ذكر جديد'}</h3>
          <button onClick={onClose} className="p-2 bg-white dark:bg-navy-800 rounded-full shadow-sm"><XCircleIcon /></button>
        </div>
        
        <form onSubmit={(e) => { e.preventDefault(); onSave({ zekr: text, count, description, reference }); }} className="p-6 space-y-5">
          <div className="space-y-2">
            <label className="text-xs font-bold text-navy-400">نص الذكر</label>
            <textarea value={text} onChange={(e) => setText(e.target.value)} className="w-full p-4 rounded-2xl border-2 border-navy-50 dark:border-navy-800 bg-white dark:bg-navy-950 focus:border-gold-500 outline-none h-28 font-quran text-lg" placeholder="اكتب الذكر هنا..." required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-navy-400">عدد التكرار</label>
              <input type="number" min="1" value={count} onChange={(e) => setCount(e.target.value)} className="w-full p-3 rounded-xl border-2 border-navy-50 dark:border-navy-800 text-center font-bold" />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-navy-400">المصدر</label>
              <input type="text" value={reference} onChange={(e) => setReference(e.target.value)} className="w-full p-3 rounded-xl border-2 border-navy-50 dark:border-navy-800" placeholder="البخاري، مسلم..." />
            </div>
          </div>
          <div className="space-y-2">
              <label className="text-xs font-bold text-navy-400">الفضل أو الملاحظة</label>
              <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} className="w-full p-3 rounded-xl border-2 border-navy-50 dark:border-navy-800" placeholder="أجر هذا الذكر..." />
          </div>
          <button type="submit" className="w-full py-4 bg-navy-900 dark:bg-gold-500 text-white dark:text-navy-900 font-bold rounded-2xl shadow-xl transition-all">حفظ الذكر</button>
        </form>
      </div>
    </div>
  );
};

const XCircleIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <path d="m15 9-6 6" />
    <path d="m9 9 6 6" />
  </svg>
);