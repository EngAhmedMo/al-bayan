
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { TopBar } from '../components/TopBar';
import { RotateCcw, Infinity as InfinityIcon, ChevronLeft, ChevronRight, Activity, CheckCircle2, List, Plus, Trash2, X, Target } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';
import { getLastTasbihTarget, setLastTasbihTarget, getCustomTasbihs, addCustomTasbih, deleteCustomTasbih } from '../services/storage';
import { useSettings } from '../components/Layout';
import { TasbihItem } from '../types';

// Default built-in Adhkar
const BASE_ADHKAR_ITEMS: TasbihItem[] = [
  { id: "std_1", label: "سبحان الله", count: 0, target: 33 },
  { id: "std_2", label: "الحمد لله", count: 0, target: 33 },
  { id: "std_3", label: "لا إله إلا الله", count: 0, target: 33 },
  { id: "std_4", label: "الله أكبر", count: 0, target: 33 },
  { id: "std_5", label: "أستغفر الله", count: 0, target: 33 },
  { id: "std_6", label: "لا حول ولا قوة إلا بالله", count: 0, target: 33 },
  { id: "std_7", label: "اللهم صل على محمد", count: 0, target: 10 },
  { id: "std_8", label: "سبحان الله وبحمده", count: 0, target: 100 }
];

export const Tasbih: React.FC = () => {
  // State
  const [count, setCount] = useState(0);
  const [rounds, setRounds] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [target, setTarget] = useState<number>(33); // Current active target
  const [isPressed, setIsPressed] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [customItems, setCustomItems] = useState<TasbihItem[]>([]);
  
  // Interaction Lock for Accuracy
  const isTransitioning = useRef(false);
  
  // Modals State
  const [isListOpen, setIsListOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);

  const { fontSize } = useSettings();

  // Combine Default and Custom
  const allTasbihs = useMemo(() => {
    return [...customItems, ...BASE_ADHKAR_ITEMS];
  }, [customItems]);

  const currentTasbih = allTasbihs[currentIndex] || BASE_ADHKAR_ITEMS[0];

  // Initialize: Restore preferences & Load Custom
  useEffect(() => {
    setCustomItems(getCustomTasbihs());
    const savedTarget = getLastTasbihTarget();
    if (savedTarget !== null) {
      setTarget(savedTarget);
    }
  }, []);

  const handleTargetChange = (newTarget: number) => {
    setTarget(newTarget);
    setLastTasbihTarget(newTarget);
    setCount(0);
    // Safety unlock when manual change happens
    isTransitioning.current = false;
  };

  const changeZekr = (direction: 'next' | 'prev') => {
    let newIndex = 0;
    if (direction === 'next') {
      newIndex = (currentIndex + 1) % allTasbihs.length;
    } else {
      newIndex = (currentIndex - 1 + allTasbihs.length) % allTasbihs.length;
    }
    
    setCurrentIndex(newIndex);
    setCount(0);
    
    // Safety unlock when manual change happens
    isTransitioning.current = false;

    // When switching, update target to the item's default preference
    if (allTasbihs[newIndex].target > 0) {
       setTarget(allTasbihs[newIndex].target);
    }

    if (navigator.vibrate) navigator.vibrate(10);
  };

  const selectTasbihFromList = (index: number) => {
    setCurrentIndex(index);
    const item = allTasbihs[index];
    if (item.target > 0) setTarget(item.target);
    setCount(0);
    setIsListOpen(false);
    isTransitioning.current = false;
  };

  const handleAddCustom = (text: string, defaultTarget: number) => {
    const newItem: TasbihItem = {
      id: Date.now().toString(),
      label: text,
      count: 0,
      target: defaultTarget
    };
    addCustomTasbih(newItem);
    setCustomItems(getCustomTasbihs());
    setIsAddOpen(false);
    
    // Switch to the new item immediately
    setTimeout(() => {
       setCurrentIndex(0); // Because we prepend custom items
       setTarget(defaultTarget);
       setCount(0);
       isTransitioning.current = false;
    }, 100);
  };

  const handleDeleteCustom = (id: string) => {
    if (window.confirm("هل أنت متأكد من حذف هذا الذكر؟")) {
      deleteCustomTasbih(id);
      setCustomItems(getCustomTasbihs());
      // If we deleted the current one, reset index
      if (currentTasbih.id === id) {
        setCurrentIndex(0);
        setCount(0);
        isTransitioning.current = false;
      }
    }
  };

  // Haptic Feedback Helper
  const triggerHaptic = (pattern: number | number[] = 10) => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(pattern);
    }
  };

  const handleTap = () => {
    // 1. SECURITY LOCK: Prevent rapid taps from messing up the logic during transition
    if (isTransitioning.current) return;

    setIsPressed(true);
    setTimeout(() => setIsPressed(false), 80);

    const newCount = count + 1;
    setTotalCount(t => t + 1);

    if (target > 0 && newCount >= target) {
      // --- COMPLETION & AUTO-ADVANCE LOGIC ---
      
      // Lock immediately to ignore any extra taps (Ghost touch prevention)
      isTransitioning.current = true;

      triggerHaptic([30, 50, 30]); 
      setCount(target); // Visually reach the target

      // Short delay to show completion, then switch
      setTimeout(() => {
        // Increment completed rounds (Sets)
        setRounds(r => r + 1);
        
        // Move to NEXT Dhikr automatically
        const nextIndex = (currentIndex + 1) % allTasbihs.length;
        setCurrentIndex(nextIndex);
        
        // Update target for the new Dhikr
        const nextItem = allTasbihs[nextIndex];
        if (nextItem.target > 0) {
           setTarget(nextItem.target);
        }

        // Reset count for the NEW Dhikr
        setCount(0);
        
        // Unlock for interaction
        isTransitioning.current = false;
      }, 400); // 400ms transition delay
    } else {
      // --- NORMAL INCREMENT ---
      triggerHaptic(8);
      setCount(newCount);
    }
  };

  const resetCounter = () => {
    triggerHaptic(20);
    setCount(0);
    setRounds(0);
    isTransitioning.current = false;
  };

  // Consistent Button Style
  const headerBtnClass = "w-10 h-10 flex items-center justify-center rounded-xl bg-white/80 dark:bg-navy-800/80 backdrop-blur-sm border border-navy-100 dark:border-navy-700 text-navy-600 dark:text-navy-300 hover:border-gold-400 dark:hover:border-gold-500 hover:text-gold-600 dark:hover:text-gold-400 hover:bg-white dark:hover:bg-navy-800 shadow-sm hover:shadow-md transition-all duration-200 active:scale-95";

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans overflow-hidden">
      <TopBar 
        title="السبحة الإلكترونية" 
        extra={
          <button onClick={() => setIsListOpen(true)} className={headerBtnClass} title="قائمة التسابيح">
            <List size={22} />
          </button>
        }
      />

      {/* Main Content Area - Scrollable */}
      <div className="flex-1 relative overflow-y-auto custom-scrollbar">
        <div className="absolute inset-0 opacity-5 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/arabesque.png')] min-h-full"></div>
        
        <div className="min-h-full flex flex-col justify-between items-center pb-24">
          
          {/* Top: Stats */}
          <div className="w-full px-6 pt-6 z-10 flex flex-col items-center">
             <div className="flex items-center gap-4 mb-6">
                <div className="bg-white/60 dark:bg-navy-900/60 backdrop-blur-md px-3 py-1 rounded-full border border-gold-200 dark:border-navy-700 shadow-sm flex items-center gap-2">
                   <Activity size={14} className="text-gold-600" />
                   <span className="text-xs font-bold text-navy-600 dark:text-navy-300">المجموع: {toArabicDigits(totalCount)}</span>
                </div>
                {rounds > 0 && (
                  <div className="bg-emerald-100/60 dark:bg-emerald-900/30 backdrop-blur-md px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-800 shadow-sm flex items-center gap-2 animate-in fade-in">
                     <CheckCircle2 size={14} className="text-emerald-600" />
                     <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400">{toArabicDigits(rounds)} دورة</span>
                  </div>
                )}
             </div>

             {/* Dhikr Display (Improved for Long Text) */}
             <div className="w-full max-w-sm bg-white/80 dark:bg-navy-900/80 backdrop-blur-lg rounded-3xl p-4 shadow-xl shadow-gold-500/5 border border-white/50 dark:border-navy-700 relative overflow-hidden text-center min-h-[140px] flex flex-col">
                <div className="flex items-center justify-between gap-4 mb-2">
                   <button onClick={() => changeZekr('prev')} className="w-8 h-8 flex shrink-0 items-center justify-center rounded-full bg-navy-50 dark:bg-navy-800 text-navy-400 hover:text-gold-500 transition-colors">
                      <ChevronRight size={18} />
                   </button>
                   
                   {/* Current Index Indicator */}
                   <span className="text-[10px] font-bold text-navy-400 bg-navy-50 dark:bg-navy-800 px-2 py-0.5 rounded-full">
                     {toArabicDigits(currentIndex + 1)} / {toArabicDigits(allTasbihs.length)}
                   </span>

                   <button onClick={() => changeZekr('next')} className="w-8 h-8 flex shrink-0 items-center justify-center rounded-full bg-navy-50 dark:bg-navy-800 text-navy-400 hover:text-gold-500 transition-colors">
                      <ChevronLeft size={18} />
                   </button>
                </div>
                
                <div className="flex-1 flex items-center justify-center overflow-y-auto custom-scrollbar px-2 py-1">
                  <h2 
                    className="font-quran font-bold text-navy-900 dark:text-white leading-[1.8] text-center break-words w-full"
                    style={{ fontSize: `${Math.max(20, Math.min(fontSize * 1.2, 32))}px` }}
                  >
                    {currentTasbih.label}
                  </h2>
                </div>
             </div>
          </div>

          {/* Center: Main Tap Button */}
          <div className="flex-1 flex items-center justify-center w-full z-10 py-8">
             <button 
               onClick={handleTap}
               className="relative group outline-none focus:outline-none"
               style={{ WebkitTapHighlightColor: 'transparent' }}
             >
                <div className={`absolute inset-0 rounded-full bg-gold-500/20 blur-xl transition-all duration-200 ${isPressed ? 'scale-110 opacity-100' : 'scale-100 opacity-0'}`}></div>
                
                <div className={`
                   w-60 h-60 md:w-64 md:h-64 rounded-full 
                   bg-gradient-to-br from-white to-gold-50 dark:from-navy-800 dark:to-navy-950
                   shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1),inset_0_-5px_10px_rgba(0,0,0,0.05)] 
                   dark:shadow-[0_10px_40px_-10px_rgba(0,0,0,0.3),inset_0_1px_1px_rgba(255,255,255,0.1)]
                   border-4 border-white dark:border-navy-700
                   flex flex-col items-center justify-center
                   transition-transform duration-100 ease-out
                   ${isPressed ? 'scale-95 shadow-inner' : 'scale-100'}
                `}>
                   <span className="text-7xl font-sans font-bold text-navy-800 dark:text-white tracking-tighter drop-shadow-sm select-none">
                      {toArabicDigits(count)}
                   </span>
                   <div className="flex items-center gap-1 mt-2">
                      <span className="text-xs font-bold text-navy-400 dark:text-navy-500 uppercase tracking-widest">
                        الهدف: {target === 0 ? '∞' : toArabicDigits(target)}
                      </span>
                   </div>
                </div>

                <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 100 100">
                   <circle cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="2" className="text-navy-100 dark:text-navy-800 opacity-50" />
                   <circle 
                     cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="4" 
                     strokeDasharray={289} 
                     strokeDashoffset={289 - (target > 0 ? (count / target) * 289 : 289)} 
                     strokeLinecap="round"
                     className="text-gold-500 transition-all duration-300"
                   />
                </svg>
             </button>
          </div>

          {/* Bottom: Controls */}
          <div className="w-full px-8 pb-6 z-10 mt-auto">
             <div className="bg-white/80 dark:bg-navy-900/80 backdrop-blur-md rounded-2xl p-2 flex justify-between items-center shadow-lg shadow-gold-500/5 border border-white/50 dark:border-navy-700">
                
                <button 
                  onClick={resetCounter}
                  className="w-12 h-12 flex items-center justify-center rounded-xl text-navy-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  title="تصفير"
                >
                  <RotateCcw size={20} />
                </button>

                <div className="h-8 w-px bg-navy-100 dark:bg-navy-800 mx-2"></div>

                <div className="flex-1 flex justify-center gap-2">
                   {[33, 100, 1000, 0].map(val => (
                     <button
                       key={val}
                       onClick={() => handleTargetChange(val)}
                       className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                         target === val 
                           ? 'bg-gold-500 text-white shadow-md' 
                           : 'text-navy-500 hover:bg-navy-50 dark:hover:bg-navy-800'
                       }`}
                     >
                       {val === 0 ? <InfinityIcon size={16} className="mx-auto" /> : toArabicDigits(val)}
                     </button>
                   ))}
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* --- Management List Modal --- */}
      {isListOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-navy-900/80 backdrop-blur-sm" onClick={() => setIsListOpen(false)}></div>
          <div className="relative w-full max-w-sm bg-white dark:bg-navy-900 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 border border-navy-100 dark:border-navy-800 flex flex-col max-h-[80vh]">
             
             <div className="p-4 border-b border-navy-100 dark:border-navy-800 flex justify-between items-center bg-navy-50 dark:bg-navy-950">
               <h3 className="font-bold text-lg text-navy-900 dark:text-white flex items-center gap-2">
                 <List size={20} className="text-gold-500" /> قائمة التسابيح
               </h3>
               <button onClick={() => setIsListOpen(false)}><X size={20} className="text-navy-400" /></button>
             </div>

             <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-2 bg-white dark:bg-navy-900">
                <button 
                  onClick={() => { setIsListOpen(false); setIsAddOpen(true); }}
                  className="w-full mb-2 flex items-center justify-center gap-2 p-3 rounded-xl border-2 border-dashed border-navy-200 dark:border-navy-700 text-navy-500 hover:border-gold-500 hover:text-gold-600 hover:bg-gold-50/50 transition-all font-bold"
                >
                  <Plus size={18} /> إضافة تسبيح جديد
                </button>

                {allTasbihs.map((item, idx) => (
                  <div key={item.id} className={`flex items-center gap-2 p-3 rounded-xl border transition-all ${idx === currentIndex ? 'bg-gold-50 dark:bg-gold-900/20 border-gold-500' : 'bg-white dark:bg-navy-800 border-navy-100 dark:border-navy-700'}`}>
                     <button 
                       onClick={() => selectTasbihFromList(idx)} 
                       className="flex-1 text-right"
                     >
                       <p className={`font-bold font-quran text-sm ${idx === currentIndex ? 'text-navy-900 dark:text-white' : 'text-navy-600 dark:text-navy-300'}`}>{item.label}</p>
                       <span className="text-[10px] text-navy-400">الهدف الافتراضي: {toArabicDigits(item.target)}</span>
                     </button>
                     {/* Only custom items (those not starting with 'std_') can be deleted */}
                     {!item.id.startsWith('std_') && (
                       <button 
                         onClick={() => handleDeleteCustom(item.id)}
                         className="p-2 text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                       >
                         <Trash2 size={16} />
                       </button>
                     )}
                  </div>
                ))}
             </div>
          </div>
        </div>
      )}

      {/* --- Add New Tasbih Modal --- */}
      {isAddOpen && (
        <AddTasbihModal onClose={() => setIsAddOpen(false)} onAdd={handleAddCustom} />
      )}

    </div>
  );
};

const AddTasbihModal = ({ onClose, onAdd }: { onClose: () => void, onAdd: (text: string, target: number) => void }) => {
  const [text, setText] = useState('');
  const [target, setTarget] = useState('33');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    onAdd(text, parseInt(target) || 33);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative w-full max-w-md bg-white dark:bg-navy-900 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 border border-navy-100 dark:border-navy-800">
        <div className="p-5 border-b border-navy-100 dark:border-navy-800 flex justify-between items-center bg-navy-50 dark:bg-navy-800/50">
          <h3 className="font-bold text-lg text-navy-800 dark:text-white font-sans">إضافة تسبيح جديد</h3>
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-navy-200 dark:hover:bg-navy-700 text-navy-500">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label className="block text-sm font-bold text-navy-700 dark:text-navy-300 mb-2">نص الذكر / التسبيح</label>
            <textarea 
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full p-4 rounded-2xl border bg-white dark:bg-navy-950 border-navy-200 dark:border-navy-700 focus:ring-2 focus:ring-gold-500 outline-none h-32 font-quran text-xl text-navy-900 dark:text-white placeholder:font-sans placeholder:text-sm"
              placeholder="اكتب الذكر هنا..."
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-bold text-navy-700 dark:text-navy-300 mb-2 flex items-center gap-2">
              <Target size={16} className="text-gold-500" /> العدد المستهدف (افتراضي)
            </label>
            <div className="flex gap-2">
               {[33, 100, 1000].map(val => (
                 <button
                   key={val}
                   type="button"
                   onClick={() => setTarget(val.toString())}
                   className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all border ${target === val.toString() ? 'bg-gold-500 text-white border-gold-500' : 'bg-white dark:bg-navy-950 text-navy-500 border-navy-200 dark:border-navy-700'}`}
                 >
                   {toArabicDigits(val)}
                 </button>
               ))}
            </div>
            <input 
              type="number" 
              min="1"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="w-full p-3.5 mt-3 rounded-xl border bg-white dark:bg-navy-950 border-navy-200 dark:border-navy-700 focus:ring-2 focus:ring-gold-500 outline-none text-navy-900 dark:text-white font-bold text-center"
              placeholder="أو اكتب عدداً مخصصاً"
            />
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-gold-500 hover:bg-gold-600 text-navy-900 font-bold rounded-2xl transition-colors shadow-lg shadow-gold-500/20 mt-2"
          >
            حفظ وإضافة
          </button>
        </form>
      </div>
    </div>
  );
};
    