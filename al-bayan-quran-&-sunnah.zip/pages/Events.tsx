
import React, { useState, useEffect } from 'react';
import { TopBar } from '../components/TopBar';
import { EVENTS_DATA, TITLE_MAP, MONTH_MAP, getHijriDate, getNextEvent } from '../services/eventsData';
import { IslamicEvent } from '../types';
import { Calendar, Bell, ChevronLeft, BookOpen, Quote, Star, ArrowLeft, Clock } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';

export const Events: React.FC = () => {
  const [hijriDate, setHijriDate] = useState({ day: 1, month: 1, year: 1445 });
  const [nextEvent, setNextEvent] = useState<IslamicEvent | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<IslamicEvent | null>(null);
  const [daysRemaining, setDaysRemaining] = useState<number | null>(null);

  useEffect(() => {
    const today = getHijriDate();
    setHijriDate(today);
    
    const next = getNextEvent();
    setNextEvent(next);

    // Simple day difference calculation assuming 30 days per month for estimation
    // This is a heuristic, real moon sighting varies.
    if (next) {
        let currentTotal = today.month * 30 + today.day;
        let eventTotal = next.month * 30 + next.day[0];
        
        // If event is next year
        if (eventTotal < currentTotal) {
            eventTotal += 354; // Approx days in lunar year
        }
        
        setDaysRemaining(eventTotal - currentTotal);
    }

  }, []);

  const isToday = (event: IslamicEvent) => {
    return event.month === hijriDate.month && event.day.includes(hijriDate.day);
  };

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="المناسبات الإسلامية" />
      
      <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 space-y-8 custom-scrollbar">
        <div className="max-w-4xl mx-auto space-y-8">
            
            {/* Today's Date Hero Card */}
            <div className="bg-gradient-to-br from-navy-900 to-navy-800 rounded-3xl p-6 md:p-10 text-white shadow-xl relative overflow-hidden flex flex-col items-center justify-center text-center">
               <div className="absolute inset-0 opacity-10" style={{backgroundImage: "url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMiIgZmlsbD0ibm9uZSIgb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMjAgMEwyMCA0ME0wIDIwTDQwIDIwIiAvPjwvc3ZnPg==')"}}></div>
               <div className="absolute top-0 right-0 w-48 h-48 bg-gold-500/10 rounded-full -mr-12 -mt-12 blur-3xl"></div>
               
               <div className="relative z-10 space-y-2">
                 <h2 className="text-sm md:text-base font-bold text-navy-200 uppercase tracking-widest">التاريخ الهجري اليوم</h2>
                 <div className="text-5xl md:text-7xl font-bold font-sans tracking-tight text-white drop-shadow-md">
                   {toArabicDigits(hijriDate.day)} <span className="text-gold-400 font-quran">{MONTH_MAP[hijriDate.month]}</span>
                 </div>
                 <div className="text-xl md:text-2xl text-navy-300 font-medium">{toArabicDigits(hijriDate.year)} هـ</div>
               </div>
            </div>

            {/* Next Event Card with Countdown */}
            {nextEvent && (
              <div className="bg-white dark:bg-navy-900 p-6 rounded-3xl border border-navy-100 dark:border-navy-800 shadow-sm relative overflow-hidden">
                 <div className="absolute top-0 left-0 w-1.5 h-full bg-gold-500"></div>
                 
                 <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
                    <div className="text-center md:text-right flex-1">
                        <div className="flex items-center justify-center md:justify-start gap-2 mb-2 text-gold-600 dark:text-gold-500 font-bold text-sm uppercase tracking-wider">
                           <Star size={16} fill="currentColor" />
                           <span>المناسبة القادمة</span>
                        </div>
                        <h3 className="text-2xl font-bold text-navy-900 dark:text-white mb-2">
                           {TITLE_MAP[nextEvent.title]}
                        </h3>
                        <p className="text-navy-500 dark:text-navy-400 text-sm font-medium">
                           الموعد: {toArabicDigits(nextEvent.day[0])} {MONTH_MAP[nextEvent.month]}
                        </p>
                    </div>

                    {/* Countdown Circle */}
                    <div className="flex-shrink-0 relative group">
                        {isToday(nextEvent) ? (
                           <div className="w-24 h-24 rounded-full bg-emerald-500 flex flex-col items-center justify-center text-white shadow-lg shadow-emerald-500/30 animate-pulse">
                             <span className="text-xl font-bold">اليوم!</span>
                           </div>
                        ) : (
                           <div className="w-24 h-24 rounded-full border-4 border-gold-100 dark:border-navy-700 flex flex-col items-center justify-center relative bg-white dark:bg-navy-800 shadow-sm">
                              <span className="text-3xl font-bold text-navy-900 dark:text-white font-sans">{daysRemaining !== null ? toArabicDigits(daysRemaining) : '-'}</span>
                              <span className="text-[10px] font-bold text-navy-400 uppercase tracking-widest mt-1">يوم متبقي</span>
                              
                              {/* Decorative ring */}
                              <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none">
                                <circle cx="50%" cy="50%" r="46%" fill="none" stroke="currentColor" strokeWidth="3" className="text-gold-500" strokeDasharray="100 100" />
                              </svg>
                           </div>
                        )}
                    </div>
                 </div>
              </div>
            )}

            {/* Events Timeline List */}
            <div>
              <h3 className="font-bold text-lg text-navy-800 dark:text-white mb-4 flex items-center gap-2 px-1">
                 <Calendar size={20} className="text-gold-500" />
                 <span>تقويم السنة الهجرية</span>
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {EVENTS_DATA.sort((a, b) => (a.month * 30 + a.day[0]) - (b.month * 30 + b.day[0])).map((event) => {
                  const active = isToday(event);
                  return (
                    <button 
                      key={event.id}
                      onClick={() => setSelectedEvent(event)}
                      className={`relative p-4 rounded-2xl border transition-all text-right group hover:shadow-md ${
                        active 
                          ? 'bg-navy-800 text-white border-navy-800' 
                          : 'bg-white dark:bg-navy-900 border-navy-100 dark:border-navy-800 hover:border-gold-500 dark:hover:border-navy-600'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        {/* Modified Date Badge: Shows Day Number and Arabic Month Name */}
                        <div className={`w-16 h-16 flex flex-col items-center justify-center rounded-2xl shrink-0 border transition-all ${
                            active 
                              ? 'bg-gold-500 border-gold-500 text-navy-900 shadow-lg shadow-gold-500/20' 
                              : 'bg-navy-50 dark:bg-navy-800 border-navy-100 dark:border-navy-700'
                          }`}>
                           <span className={`text-2xl font-bold font-sans leading-none mb-0.5 ${active ? 'text-navy-900' : 'text-navy-700 dark:text-white'}`}>
                             {toArabicDigits(event.day[0])}
                           </span>
                           <span className={`text-[10px] font-bold truncate w-full text-center px-1 ${active ? 'text-navy-800/80' : 'text-gold-600 dark:text-gold-500'}`}>
                             {MONTH_MAP[event.month]}
                           </span>
                        </div>

                        <div className="flex-1 min-w-0">
                          <h4 className={`font-bold text-base truncate ${active ? 'text-white' : 'text-navy-800 dark:text-white'}`}>
                            {TITLE_MAP[event.title]}
                          </h4>
                          {event.isReminder && (
                            <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full w-fit mt-1.5 font-bold ${active ? 'bg-white/10 text-gold-400' : 'bg-gold-50 dark:bg-navy-800 text-gold-600 dark:text-gold-500'}`}>
                              <Bell size={10} /> تذكير بالصيام
                            </span>
                          )}
                        </div>
                        <ChevronLeft size={20} className={`${active ? 'text-white/50' : 'text-navy-300 group-hover:text-gold-500'} transition-colors`} />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-navy-900/80 backdrop-blur-sm" onClick={() => setSelectedEvent(null)}></div>
          <div className="relative w-full max-w-lg bg-white dark:bg-navy-900 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 border border-navy-100 dark:border-navy-800">
            
            {/* Header */}
            <div className="p-6 bg-navy-50 dark:bg-navy-950 border-b border-navy-100 dark:border-navy-800 flex items-center gap-4">
               <button onClick={() => setSelectedEvent(null)} className="p-2 -mr-2 rounded-full hover:bg-navy-200 dark:hover:bg-navy-800 text-navy-500">
                 <ArrowLeft size={20} />
               </button>
               <div>
                 <h2 className="text-xl font-bold text-navy-900 dark:text-white">
                   {TITLE_MAP[selectedEvent.title]}
                 </h2>
                 <p className="text-xs text-navy-500 dark:text-navy-400 mt-0.5 font-bold">
                   {selectedEvent.day.map(d => toArabicDigits(d)).join(' - ')} {MONTH_MAP[selectedEvent.month]}
                 </p>
               </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar bg-white dark:bg-navy-900">
              {selectedEvent.hadith.map((h, idx) => (
                <div key={idx} className="bg-white dark:bg-navy-800 p-5 rounded-2xl border border-navy-100 dark:border-navy-700 shadow-sm">
                   <Quote size={24} className="text-gold-500 mb-3 rotate-180" />
                   <p className="font-quran text-xl leading-loose text-justify text-navy-800 dark:text-white mb-4 pl-2">
                     {h.hadith}
                   </p>
                   <div className="flex items-start gap-2 pt-4 border-t border-navy-50 dark:border-navy-700">
                     <BookOpen size={14} className="text-navy-400 mt-0.5 shrink-0" />
                     <p className="text-xs text-navy-500 dark:text-navy-400 leading-relaxed">
                       {h.bookInfo}
                     </p>
                   </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
