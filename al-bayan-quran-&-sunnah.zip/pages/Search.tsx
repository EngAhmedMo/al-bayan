
import React, { useState, useContext, useEffect, useRef, useCallback } from 'react';
import { TopBar } from '../components/TopBar';
import { normalizeArabic, toArabicDigits } from '../services/normalization';
import { NavigationContext } from '../components/Layout';
import { Search as SearchIcon, ArrowUpLeft, BookOpen, AlertCircle, FileText, ChevronLeft, ArrowDownCircle, X, CheckCircle2 } from 'lucide-react';
import { Surah, QuranSearchResult } from '../types';
import { fetchSurahs, searchQuranText, isStrictMatch } from '../services/api';
import { SURAH_START_PAGES } from '../services/quranStaticData';
import { useSearchParams } from 'react-router-dom';

export const Search: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<QuranSearchResult[]>([]);
  const [displayedResults, setDisplayedResults] = useState<QuranSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [surahs, setSurahs] = useState<Surah[]>([]);
  
  const { navigateToAyah } = useContext(NavigationContext);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollPositionRef = useRef<number>(0);
  const PAGE_SIZE = 20;

  // 1. Fetch Static Data
  useEffect(() => {
    fetchSurahs().then(setSurahs);
  }, []);

  // 2. Restore Scroll Position on Return
  useEffect(() => {
    const savedScroll = sessionStorage.getItem('search_scroll_pos');
    if (savedScroll && displayedResults.length > 0) {
      window.scrollTo(0, parseInt(savedScroll));
    }
  }, [displayedResults]);

  // 3. Perform Search Logic (Smart Sorting)
  const performSearch = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      setResults([]);
      setDisplayedResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    setHasSearched(true);

    try {
      const data = await searchQuranText(searchTerm);
      
      // --- SMART SORTING ALGORITHM (Strict Order) ---
      // 1. Exact Phrase Match ('exact' type from API).
      // 2. Surah Order (1 -> 114).
      // 3. Ayah Order.
      const sortedData = data.sort((a, b) => {
        // Priority 1: Exact Phrase
        if (a.matchType === 'exact' && b.matchType !== 'exact') return -1;
        if (b.matchType === 'exact' && a.matchType !== 'exact') return 1;

        // Priority 2: Surah Order
        if (a.surah.number !== b.surah.number) {
          return a.surah.number - b.surah.number;
        }

        // Priority 3: Ayah Order
        return a.ayah.numberInSurah - b.ayah.numberInSurah;
      });

      setResults(sortedData);
      setDisplayedResults(sortedData.slice(0, PAGE_SIZE));
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearching(false);
    }
  }, []);

  // 4. Initial Load (Deep Link / Back Navigation)
  useEffect(() => {
    if (initialQuery) {
      performSearch(initialQuery);
    }
  }, []); // Run once on mount

  // 5. Handle Input Change & Debounce URL Update
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);

    if (val === '') {
      setHasSearched(false);
      setResults([]);
      setSearchParams({}, { replace: true });
      return;
    }

    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    
    timeoutRef.current = setTimeout(() => {
      setSearchParams({ q: val }, { replace: true });
      performSearch(val);
    }, 500);
  };

  // 6. Handle Result Click (Navigation)
  const handleResultClick = (surahNum: number, ayahNum: number, pageNum: number) => {
    sessionStorage.setItem('search_scroll_pos', window.scrollY.toString());
    navigateToAyah(surahNum, ayahNum, pageNum > 0 ? pageNum : undefined);
  };

  const handleLoadMore = () => {
    setDisplayedResults(results); // Sets to full array immediately
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setDisplayedResults([]);
    setHasSearched(false);
    setSearchParams({}, { replace: true });
    inputRef.current?.focus();
  };

  const matchedSurahs = query ? surahs.filter(s => 
    s.name.includes(query) || 
    s.number.toString() === query ||
    normalizeArabic(s.name).includes(normalizeArabic(query))
  ) : [];

  // SMART HIGHLIGHTING (Uses Strict Match Logic from API)
  const HighlightText = ({ text, term }: { text: string, term: string }) => {
    if (!term.trim()) return <>{text}</>;
    
    // Normalize term exactly like the API does
    const normTerm = normalizeArabic(term);
    const termParts = normTerm.split(/\s+/).filter(t => t.length > 0);
    const words = text.split(' ');

    return (
      <span className="text-navy-900 dark:text-white">
        {words.map((word, i) => {
           // We use the SAME strict match function from API to decide if this word should be highlighted
           const isMatch = termParts.some(part => isStrictMatch(word, part));
           
           return (
             <React.Fragment key={i}>
               {isMatch ? (
                 <span className="bg-gold-200 dark:bg-gold-600/60 text-navy-900 dark:text-white rounded px-0.5 shadow-sm font-bold">
                   {word}
                 </span>
               ) : word}
               {' '}
             </React.Fragment>
           );
        })}
      </span>
    );
  };

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="البحث في المصحف" />
      
      <div className="flex-1 overflow-y-auto pb-24">
        
        {/* Sticky Search Header */}
        <div className="sticky top-0 z-30 bg-gold-50/95 dark:bg-navy-950/95 backdrop-blur-md px-4 py-4 border-b border-navy-100 dark:border-navy-800 transition-all duration-300">
          <div className="relative">
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={handleInputChange}
              placeholder="ابحث عن آية (مثال: أمن، جنات عدن)..."
              className="w-full h-14 pl-14 pr-12 rounded-2xl border-2 border-transparent bg-white dark:bg-navy-900 text-navy-900 dark:text-white shadow-sm focus:border-gold-500 focus:ring-0 outline-none transition-all text-lg font-bold placeholder:font-normal placeholder:text-navy-300"
              autoFocus={!initialQuery}
            />
            <div className="absolute right-4 top-4 text-navy-400">
               <SearchIcon size={24} />
            </div>
            {query && (
              <button onClick={clearSearch} className="absolute left-3 top-3 p-2 bg-navy-100 dark:bg-navy-800 text-navy-500 rounded-full hover:bg-red-100 hover:text-red-500 transition-colors">
                <X size={16} />
              </button>
            )}
          </div>
        </div>

        <div className="px-4 py-4 space-y-6">
          
          {/* LOADING STATE */}
          {isSearching && (
             <div className="flex flex-col items-center justify-center py-20 animate-pulse">
                <div className="w-16 h-16 bg-navy-100 dark:bg-navy-800 rounded-full flex items-center justify-center mb-4">
                   <SearchIcon size={32} className="text-navy-300" />
                </div>
                <p className="text-navy-500 dark:text-navy-400 font-bold">جاري البحث...</p>
             </div>
          )}

          {/* RESULTS STATE */}
          {!isSearching && (query.trim() !== '') && (
            <div className="space-y-6 animate-in slide-in-from-bottom-4">
              
              {/* Surah Matches */}
              {matchedSurahs.length > 0 && (
                <div>
                   <h3 className="font-bold text-navy-800 dark:text-white mb-3 flex items-center gap-2">
                     <BookOpen size={18} className="text-gold-500" />
                     السور المطابقة ({toArabicDigits(matchedSurahs.length)})
                   </h3>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {matchedSurahs.map(s => (
                        <button 
                          key={s.number}
                          onClick={() => handleResultClick(s.number, 1, SURAH_START_PAGES[s.number] || 1)}
                          className="flex items-center justify-between p-4 bg-white dark:bg-navy-900 rounded-xl border border-navy-100 dark:border-navy-800 hover:border-gold-500 hover:shadow-md transition-all group"
                        >
                          <div className="flex items-center gap-3">
                             <div className="w-10 h-10 bg-navy-50 dark:bg-navy-800 rounded-lg flex items-center justify-center text-navy-600 dark:text-navy-300 font-bold group-hover:bg-gold-500 group-hover:text-white transition-colors">
                                {toArabicDigits(s.number)}
                             </div>
                             <span className="text-lg font-bold text-navy-800 dark:text-white group-hover:text-gold-600 dark:group-hover:text-gold-400">{s.name}</span>
                          </div>
                          <ChevronLeft size={20} className="text-navy-300 group-hover:text-gold-500" />
                        </button>
                      ))}
                   </div>
                </div>
              )}

              {/* Ayah Matches */}
              {displayedResults.length > 0 ? (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-navy-800 dark:text-white flex items-center gap-2">
                       <FileText size={18} className="text-gold-500" />
                       نتائج الآيات ({toArabicDigits(results.length)})
                    </h3>
                    <span className="text-[10px] text-navy-400 bg-navy-50 dark:bg-navy-800 px-2 py-1 rounded-lg">
                      بحث دقيق
                    </span>
                  </div>
                  
                  <div className="space-y-4">
                    {displayedResults.map((res, idx) => (
                      <div key={`${res.surah.number}-${res.ayah.number}-${idx}`} className="bg-white dark:bg-navy-900 p-5 rounded-2xl shadow-sm border border-navy-100 dark:border-navy-800 hover:border-gold-300 dark:hover:border-navy-600 transition-colors group">
                        
                        <div className="flex justify-between items-start mb-4 border-b border-navy-50 dark:border-navy-800 pb-3">
                          <div className="flex items-center gap-2">
                             <span className="text-xs font-bold text-navy-600 dark:text-navy-300 bg-navy-50 dark:bg-navy-800 px-3 py-1 rounded-full">
                               {res.surah.name}
                             </span>
                             <span className="text-xs text-navy-400">آية {toArabicDigits(res.ayah.numberInSurah)}</span>
                          </div>
                          <button 
                            onClick={() => handleResultClick(res.surah.number, res.ayah.numberInSurah, res.ayah.page)}
                            className="flex items-center gap-1 text-[10px] font-bold text-white bg-gold-500 hover:bg-gold-600 px-3 py-1.5 rounded-lg transition-colors shadow-sm"
                          >
                            <span>انتقال</span>
                            <ArrowUpLeft size={14} />
                          </button>
                        </div>

                        <p className="font-quran text-xl md:text-2xl text-navy-900 dark:text-white leading-[2.6] text-justify" dir="rtl">
                          <HighlightText text={res.ayah.text} term={query} />
                        </p>
                      </div>
                    ))}
                  </div>

                  {displayedResults.length < results.length && (
                    <button 
                      onClick={handleLoadMore}
                      className="w-full py-4 mt-6 bg-navy-100 dark:bg-navy-800 text-navy-600 dark:text-navy-300 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gold-500 hover:text-white transition-all"
                    >
                      <ArrowDownCircle size={20} />
                      عرض باقي النتائج ({toArabicDigits(results.length - displayedResults.length)})
                    </button>
                  )}
                </div>
              ) : (
                hasSearched && matchedSurahs.length === 0 && (
                   <div className="flex flex-col items-center justify-center py-10 text-center border-2 border-dashed border-navy-200 dark:border-navy-800 rounded-3xl bg-navy-50/50 dark:bg-navy-900/20">
                      <div className="bg-white dark:bg-navy-900 p-4 rounded-full mb-3 shadow-sm">
                        <AlertCircle size={32} className="text-navy-300" />
                      </div>
                      <h3 className="text-base font-bold text-navy-700 dark:text-navy-200">لم يتم العثور على نتائج دقيقة</h3>
                      <p className="text-xs text-navy-500 mt-1">جرب البحث عن جذر الكلمة أو تأكد من الإملاء الصحيح.</p>
                   </div>
                )
              )}
            </div>
          )}

          {/* EMPTY STATE (Index) */}
          {!hasSearched && !query && (
            <div className="animate-in fade-in">
               <h3 className="font-bold text-navy-800 dark:text-white mb-4 flex items-center gap-2">
                 <BookOpen size={18} className="text-gold-500" />
                 فهرس السور (انتقال سريع)
               </h3>
               
               <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {surahs.map(s => (
                    <button 
                      key={s.number}
                      onClick={() => handleResultClick(s.number, 1, SURAH_START_PAGES[s.number] || 1)}
                      className="flex items-center justify-between p-3 bg-white dark:bg-navy-900 rounded-xl border border-navy-100 dark:border-navy-800 hover:border-gold-500 hover:shadow-md transition-all group text-right"
                    >
                      <span className="text-sm font-bold text-navy-700 dark:text-white group-hover:text-gold-600">{s.name}</span>
                      <span className="text-xs text-navy-400 bg-navy-50 dark:bg-navy-800 px-1.5 py-0.5 rounded font-sans">{s.number}</span>
                    </button>
                  ))}
               </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
