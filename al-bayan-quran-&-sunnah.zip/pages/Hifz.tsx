
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar } from '../components/TopBar';
import { CheckCircle2, Circle, Calendar, Trophy, ArrowLeft, ScrollText, BookOpen, Target, History, Flame, TrendingUp, ChevronRight, Clock, Award, ArrowUpRight, ArrowLeftRight, HelpCircle, Trash2, AlertTriangle, X, Edit2 } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';
import { getMetadataFromGlobalAyah, getApproxGlobalAyahFromPage, getApproxPageFromGlobalAyah } from '../services/quranStaticData';

// --- Types & Constants ---
interface HifzState {
  isSetup: boolean;
  planType: 'pages' | 'ayahs';
  amountPerDay: number;
  daysPerWeek: number; // 1-7
  currentProgress: number; // Cumulative pages or ayahs completed
  startPoint: number; // Starting page/ayah (usually 1)
  history: string[]; // ISO Date strings (YYYY-MM-DD) of completed days
  lastCompletedDate: string | null;
}

const TOTAL_PAGES = 604;
const TOTAL_AYAHS = 6236;
const STORAGE_KEY = 'albayan_hifz_plan_v1';

export const Hifz: React.FC = () => {
  const navigate = useNavigate();
  const [state, setState] = useState<HifzState | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  
  // Temp state for setup form
  const [tempType, setTempType] = useState<'pages' | 'ayahs'>('pages');
  const [tempAmount, setTempAmount] = useState<number>(1);
  const [tempDays, setTempDays] = useState<number>(6);
  const [tempStart, setTempStart] = useState<number>(1);

  // --- Logic Helper: Get Local Date String (YYYY-MM-DD) ---
  const getLocalTodayString = (): string => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Load from storage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setState(JSON.parse(saved));
    } else {
      // Default initial state
      setState({
        isSetup: false,
        planType: 'pages',
        amountPerDay: 2,
        daysPerWeek: 6,
        currentProgress: 0,
        startPoint: 1,
        history: [],
        lastCompletedDate: null
      });
    }
  }, []);

  const saveState = (newState: HifzState) => {
    setState(newState);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
  };

  // --- Delete Plan Logic ---
  const handleDeletePlan = () => {
    const freshState: HifzState = {
        isSetup: false,
        planType: 'pages',
        amountPerDay: 2,
        daysPerWeek: 6,
        currentProgress: 0,
        startPoint: 1,
        history: [],
        lastCompletedDate: null
    };
    saveState(freshState);
    setIsEditing(false);
    setIsDeleteModalOpen(false);
    
    // Reset temp values for fresh start
    setTempType('pages');
    setTempAmount(2);
    setTempDays(6);
    setTempStart(1);
  };

  // --- Logic: Streak Calculation ---
  const currentStreak = useMemo(() => {
    if (!state || state.history.length === 0) return 0;
    
    const sortedHistory = [...new Set<string>(state.history)].sort(); 
    const todayStr = getLocalTodayString();
    
    const lastEntry = sortedHistory[sortedHistory.length - 1];
    
    if (!lastEntry) return 0; 

    const todayDate = new Date(todayStr);
    const lastDate = new Date(lastEntry);
    
    const diffTime = Math.abs(todayDate.getTime() - lastDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 

    if (diffDays > 1) return 0;

    let streak = 0;
    let currentDateToCheck = lastDate;
    
    for (let i = sortedHistory.length - 1; i >= 0; i--) {
        const entryStr = sortedHistory[i];
        if (!entryStr) break;
        
        const entryDate = new Date(entryStr);
        if (entryDate.getTime() === currentDateToCheck.getTime()) {
            streak++;
            currentDateToCheck.setDate(currentDateToCheck.getDate() - 1);
        } else {
            break; 
        }
    }
    return streak;
  }, [state?.history]);

  // --- Start / Update Plan Logic ---
  const handleStartPlan = () => {
    if (!state) return;

    let newStartPoint = tempStart;
    let newProgress = 0;
    let newHistory = state.history; 
    let newLastCompletedDate = state.lastCompletedDate;

    if (state.isSetup) {
        if (state.planType !== tempType) {
            const currentTotalProgress = state.startPoint + state.currentProgress;
            
            if (state.planType === 'pages' && tempType === 'ayahs') {
                newStartPoint = getApproxGlobalAyahFromPage(currentTotalProgress);
            } else if (state.planType === 'ayahs' && tempType === 'pages') {
                newStartPoint = getApproxPageFromGlobalAyah(currentTotalProgress);
            }
            newProgress = 0;
            alert(`تم تحويل تقدمك بنجاح! \nنقطة البداية الجديدة: ${tempType === 'pages' ? 'صفحة' : 'آية'} ${newStartPoint}`);
        } 
        else if (state.startPoint !== tempStart) {
            newStartPoint = tempStart;
            newProgress = 0;
        } 
        else {
            newStartPoint = state.startPoint;
            newProgress = state.currentProgress;
        }
    } else {
        newHistory = [];
        newLastCompletedDate = null;
    }

    saveState({
      ...state,
      isSetup: true,
      planType: tempType,
      amountPerDay: tempAmount,
      daysPerWeek: tempDays,
      startPoint: newStartPoint,
      history: newHistory,
      currentProgress: newProgress,
      lastCompletedDate: newLastCompletedDate
    });
    setIsEditing(false);
  };

  const handleCompleteToday = () => {
    if (!state) return;
    const todayStr = getLocalTodayString();
    
    if (state.lastCompletedDate === todayStr) return;

    const totalTarget = state.planType === 'pages' ? TOTAL_PAGES : TOTAL_AYAHS;
    const nextProgress = Math.min(state.currentProgress + state.amountPerDay, totalTarget - (state.startPoint - 1));

    saveState({
      ...state,
      currentProgress: nextProgress,
      lastCompletedDate: todayStr,
      history: [...state.history, todayStr]
    });

    if (navigator.vibrate) navigator.vibrate([50, 50, 50]);
  };

  const handleGoToLocation = () => {
    if (!state) return;
    
    const targetLocation = state.startPoint + state.currentProgress;
    
    if (state.planType === 'pages') {
        const page = Math.min(Math.max(targetLocation, 1), 604);
        navigate(`/reader?page=${page}`);
    } else {
        const globalAyah = Math.min(Math.max(targetLocation, 1), 6236);
        const meta = getMetadataFromGlobalAyah(globalAyah);
        const pageOfAyah = getApproxPageFromGlobalAyah(globalAyah);
        navigate(`/reader?surah=${meta.surahNumber}&ayah=${meta.ayahInSurah}&page=${pageOfAyah}&highlight=${meta.surahNumber}:${meta.ayahInSurah}`);
    }
  };

  // --- Logic Helpers ---
  const getIntensityLabel = (amount: number, type: 'pages' | 'ayahs') => {
    if (type === 'pages') {
      if (amount <= 1) return 'بداية هادئة';
      if (amount <= 2) return 'ميسر (ننصح به)';
      if (amount <= 5) return 'همة متوسطة';
      return 'همة عالية';
    } else {
      if (amount <= 5) return 'بداية هادئة';
      if (amount <= 10) return 'ميسر (ننصح به)';
      if (amount <= 30) return 'همة متوسطة';
      return 'همة عالية';
    }
  };
  
  const getEstimation = () => {
    if (!state) return { date: '', remainingDays: 0 };
    
    const currentAmount = isEditing || !state.isSetup ? tempAmount : state.amountPerDay;
    const currentDays = isEditing || !state.isSetup ? tempDays : state.daysPerWeek;
    const currentType = isEditing || !state.isSetup ? tempType : state.planType;
    const currentStart = isEditing || !state.isSetup ? tempStart : state.startPoint;
    
    const progress = (state.isSetup && !isEditing && currentType === state.planType) ? state.currentProgress : 0;

    const total = currentType === 'pages' ? TOTAL_PAGES : TOTAL_AYAHS;
    const remainingUnits = Math.max(0, total - (currentStart - 1) - progress);
    
    if (remainingUnits <= 0) return { date: 'مكتمل', remainingDays: 0 };

    const weeklySpeed = currentAmount * currentDays;
    if (weeklySpeed === 0) return { date: 'غير محدد', remainingDays: 0 };

    const weeksLeft = remainingUnits / weeklySpeed;
    const daysLeft = weeksLeft * 7;
    
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + daysLeft);
    
    return {
      date: targetDate.toLocaleDateString('ar-EG', { month: 'long', year: 'numeric' }),
      remainingDays: Math.ceil(daysLeft)
    };
  };

  const getCurrentLocation = () => {
    if (!state) return 0;
    const loc = state.startPoint + state.currentProgress;
    const max = state.planType === 'pages' ? TOTAL_PAGES : TOTAL_AYAHS;
    return Math.min(loc, max);
  };

  const isTodayDone = state?.lastCompletedDate === getLocalTodayString();
  const estimation = getEstimation();
  const currentLocation = getCurrentLocation();
  const totalTarget = state?.planType === 'pages' ? TOTAL_PAGES : TOTAL_AYAHS;
  const totalToMemorize = totalTarget - (state ? (state.startPoint - 1) : 0);
  const progressPercent = totalToMemorize > 0 
    ? Math.min(100, Math.round(((state?.currentProgress || 0) / totalToMemorize) * 100))
    : 100;

  const isKhatmaComplete = state?.currentProgress !== undefined && state.startPoint + state.currentProgress > totalTarget;

  const conversionMessage = useMemo(() => {
    if (!state?.isSetup || !isEditing) return null;
    if (state.planType === tempType) return null;

    const currentLoc = state.startPoint + state.currentProgress;
    let newLoc = 0;
    if (state.planType === 'pages' && tempType === 'ayahs') {
        newLoc = getApproxGlobalAyahFromPage(currentLoc);
    } else {
        newLoc = getApproxPageFromGlobalAyah(currentLoc);
    }

    return {
        from: state.planType === 'pages' ? `الصفحة ${currentLoc}` : `الآية ${currentLoc}`,
        to: tempType === 'pages' ? `الصفحة ${newLoc}` : `الآية ${newLoc}`,
        newStart: newLoc
    };
  }, [state, isEditing, tempType]);

  // --- Render ---

  if (!state) return null;

  // --- Setup / Edit View ---
  if (!state.isSetup || isEditing) {
    const previewEstimation = getEstimation(); 

    return (
      <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
        <TopBar 
          title={isEditing ? "تعديل الخطة" : "إعداد خطة الحفظ"} 
          showBack={isEditing} 
          extra={
            isEditing && (
              <div className="flex gap-2">
                <button 
                  onClick={() => setIsDeleteModalOpen(true)}
                  className="p-2 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-500 hover:bg-red-100 transition-all shadow-sm border border-red-100 dark:border-red-900/30"
                  title="حذف الخطة"
                >
                  <Trash2 size={20} />
                </button>
                <button onClick={() => setIsEditing(false)} className="p-2 rounded-xl bg-navy-50 dark:bg-navy-800 text-navy-600 dark:text-navy-300 hover:bg-navy-100 transition-all border border-navy-100 dark:border-navy-700">
                  <ArrowLeft size={20}/>
                </button>
              </div>
            )
          }
        />
        <div className="flex-1 overflow-y-auto p-6 pb-24 space-y-8 max-w-lg mx-auto w-full custom-scrollbar">
          
          <div className="text-center space-y-2">
             <div className="w-16 h-16 bg-gradient-to-br from-gold-400 to-gold-600 rounded-2xl mx-auto flex items-center justify-center text-white shadow-lg shadow-gold-500/30 transform rotate-3">
               <Target size={32} />
             </div>
             <h2 className="text-2xl font-bold text-navy-900 dark:text-white">بناء العادة القرآنية</h2>
             <p className="text-navy-500 dark:text-navy-400 text-sm">حدد هدفك اليومي وأيام التفرغ، وسنحسب لك خطة الختم.</p>
             <p className="text-xs text-gold-600 dark:text-gold-400 font-bold bg-gold-50 dark:bg-navy-900 px-3 py-1.5 rounded-full inline-block mt-2">
                "قليل دائم خير من كثير منقطع"
             </p>
          </div>

          <div className="space-y-6">
            {/* Step 1: Type */}
            <div className="space-y-3">
              <label className="text-sm font-bold text-navy-700 dark:text-navy-300 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-navy-200 dark:bg-navy-700 flex items-center justify-center text-xs font-bold">1</span>
                طريقة الحفظ
              </label>
              <div className="grid grid-cols-2 gap-4">
                 {(['pages', 'ayahs'] as const).map(t => (
                   <button 
                     key={t}
                     onClick={() => setTempType(t)}
                     className={`py-4 px-2 rounded-2xl text-sm font-bold transition-all border-2 flex flex-col items-center gap-2 ${
                       tempType === t 
                        ? 'bg-navy-900 text-white border-navy-900 dark:bg-gold-500 dark:border-gold-500 dark:text-navy-900 shadow-md' 
                        : 'bg-white dark:bg-navy-900 text-navy-500 border-transparent hover:border-navy-100 dark:hover:border-navy-700'
                     }`}
                   >
                     {t === 'pages' ? <BookOpen size={20} /> : <ScrollText size={20} />}
                     {t === 'pages' ? 'بالصفحات' : 'بالآيات'}
                   </button>
                 ))}
               </div>
            </div>

            {/* Warning if type changed while editing */}
            {conversionMessage && (
                <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-800 dark:text-indigo-200 text-xs font-medium rounded-2xl border border-indigo-100 dark:border-indigo-800 animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center gap-2 mb-2 font-bold text-indigo-900 dark:text-white">
                        <ArrowLeftRight size={16} />
                        <span>تغيير نظام الحفظ</span>
                    </div>
                    <p className="leading-relaxed mb-2">
                       سيتم تحويل تقدمك الحالي من <b>({conversionMessage.from})</b> إلى ما يعادله <b>({conversionMessage.to})</b> تقريباً.
                    </p>
                    <div className="flex items-center gap-2 text-[10px] bg-white/50 dark:bg-black/20 p-2 rounded-lg">
                        <HelpCircle size={12} />
                        <span>سيتم تحديث "نقطة البدء" تلقائياً لتكمل من مكانك الحالي.</span>
                    </div>
                </div>
            )}

            {/* Step 2: Amount */}
            <div className="space-y-3">
               <label className="text-sm font-bold text-navy-700 dark:text-navy-300 flex items-center gap-2">
                 <span className="w-6 h-6 rounded-full bg-navy-200 dark:bg-navy-700 flex items-center justify-center text-xs font-bold">2</span>
                 الكمية اليومية
               </label>
               <div className="bg-white dark:bg-navy-900 p-6 rounded-3xl shadow-sm">
                 <div className="flex justify-between items-end mb-6">
                   <span className="text-3xl font-bold text-navy-900 dark:text-white">
                      {toArabicDigits(tempAmount)}
                      <span className="text-sm font-medium text-navy-400 mr-2">{tempType === 'pages' ? 'صفحات' : 'آيات'}</span>
                   </span>
                   <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400">
                      {getIntensityLabel(tempAmount, tempType)}
                   </span>
                 </div>
                 <input 
                   type="range" 
                   min="1" 
                   max={tempType === 'pages' ? 20 : 50} 
                   value={tempAmount}
                   onChange={(e) => setTempAmount(parseInt(e.target.value))}
                   className="w-full accent-emerald-500 h-2 bg-navy-100 dark:bg-navy-800 rounded-lg appearance-none cursor-pointer"
                 />
                 <div className="flex justify-between text-[10px] text-navy-400 font-bold mt-4">
                   <span>سهل</span>
                   <span>مكثف</span>
                 </div>
               </div>
            </div>

            {/* Step 3: Days per Week */}
            <div className="space-y-3">
               <label className="text-sm font-bold text-navy-700 dark:text-navy-300 flex items-center gap-2">
                 <span className="w-6 h-6 rounded-full bg-navy-200 dark:bg-navy-700 flex items-center justify-center text-xs font-bold">3</span>
                 أيام الحفظ أسبوعياً
               </label>
               <div className="bg-white dark:bg-navy-900 p-4 rounded-3xl shadow-sm border border-navy-50 dark:border-navy-800">
                  <div className="flex justify-between items-center gap-2">
                    {[1, 2, 3, 4, 5, 6, 7].map((day) => (
                      <button
                        key={day}
                        onClick={() => setTempDays(day)}
                        className={`w-10 h-12 rounded-xl flex flex-col items-center justify-center transition-all ${
                          tempDays === day
                            ? 'bg-gold-500 text-white shadow-lg scale-110'
                            : 'bg-navy-50 dark:bg-navy-800 text-navy-400 hover:bg-navy-100 dark:hover:bg-navy-700'
                        }`}
                      >
                        <span className="text-lg font-bold font-sans">{toArabicDigits(day)}</span>
                      </button>
                    ))}
                  </div>
                  <p className="text-center text-xs text-navy-400 mt-3 font-medium">
                    {tempDays === 7 ? 'حفظ يومي (همة عالية)' : `سيتم الحفظ ${toArabicDigits(tempDays)} أيام في الأسبوع`}
                  </p>
               </div>
            </div>

            {/* Step 4: Start Point */}
            <div className={`space-y-3 transition-opacity ${conversionMessage ? 'opacity-50 pointer-events-none' : ''}`}>
               <label className="text-sm font-bold text-navy-700 dark:text-navy-300 flex items-center gap-2">
                 <span className="w-6 h-6 rounded-full bg-navy-200 dark:bg-navy-700 flex items-center justify-center text-xs font-bold">4</span>
                 {conversionMessage ? 'نقطة البدء (محسوبة تلقائياً)' : 'البدء من'}
               </label>
               <div className="relative">
                 <input 
                   type="number" 
                   min="1"
                   max={tempType === 'pages' ? 604 : 6236}
                   value={conversionMessage ? conversionMessage.newStart : tempStart}
                   onChange={(e) => setTempStart(parseInt(e.target.value))}
                   className="w-full p-4 rounded-2xl bg-white dark:bg-navy-900 border-2 border-transparent focus:border-gold-500 outline-none text-navy-900 dark:text-white font-bold text-lg shadow-sm pl-20 transition-all"
                   disabled={!!conversionMessage}
                 />
                 <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs font-bold text-navy-400 bg-navy-50 dark:bg-navy-800 px-2 py-1 rounded-lg">
                    {tempType === 'pages' ? 'رقم الصفحة' : 'رقم الآية'}
                 </span>
               </div>
            </div>

            {/* Live Estimation Badge */}
            <div className="bg-emerald-50 dark:bg-emerald-900/10 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-800 flex items-center gap-3">
               <div className="p-2 bg-emerald-100 dark:bg-emerald-800 rounded-full text-emerald-600 dark:text-emerald-300">
                 <Clock size={20} />
               </div>
               <div>
                 <p className="text-xs text-emerald-800 dark:text-emerald-300 font-bold">تاريخ الختم المتوقع</p>
                 <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{previewEstimation.date} ({toArabicDigits(previewEstimation.remainingDays)} يوم)</p>
               </div>
            </div>

          </div>

          <button 
            onClick={handleStartPlan}
            className="w-full py-4 bg-navy-900 hover:bg-navy-800 dark:bg-gold-500 dark:hover:bg-gold-400 text-white dark:text-navy-900 font-bold rounded-2xl shadow-xl shadow-navy-900/20 dark:shadow-gold-500/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 text-lg mt-8"
          >
            <span>{isEditing ? 'حفظ التعديلات' : 'بدء الرحلة'}</span>
            {!isEditing && <ChevronRight className="rotate-180" size={20} />}
          </button>

        </div>

        {/* Delete Confirmation Modal */}
        {isDeleteModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-navy-900/80 backdrop-blur-sm" onClick={() => setIsDeleteModalOpen(false)}></div>
            <div className="relative w-full max-w-sm bg-white dark:bg-navy-900 rounded-[2rem] shadow-2xl overflow-hidden animate-in zoom-in-95 border border-navy-100 dark:border-navy-800 p-6">
               <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center text-red-500">
                     <AlertTriangle size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-navy-900 dark:text-white">حذف خطة الحفظ</h3>
                  <p className="text-navy-500 dark:text-navy-400 text-sm leading-relaxed">
                    هل أنت متأكد من رغبتك في حذف الخطة الحالية نهائياً؟ سيتم فقدان جميع سجلات التقدم.
                  </p>
                  
                  <div className="flex gap-3 w-full pt-4">
                     <button 
                       onClick={() => setIsDeleteModalOpen(false)}
                       className="flex-1 py-3 rounded-xl font-bold text-navy-600 dark:text-white hover:bg-navy-50 dark:hover:bg-navy-800 transition-colors"
                     >
                       إلغاء
                     </button>
                     <button 
                       onClick={handleDeletePlan}
                       className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-bold shadow-md shadow-red-500/30 transition-colors"
                     >
                       نعم، احذف
                     </button>
                  </div>
               </div>
            </div>
          </div>
        )}

      </div>
    );
  }

  // --- Dashboard View ---
  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar 
        title="متابعة الحفظ" 
        extra={
          <div className="flex gap-2">
            <button 
              onClick={() => setIsDeleteModalOpen(true)}
              className="p-2 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-500 hover:bg-red-100 transition-all border border-red-100 dark:border-red-900/30 shadow-sm"
              title="حذف الخطة"
            >
              <Trash2 size={20} />
            </button>
            <button 
              onClick={() => {
                setTempType(state.planType);
                setTempAmount(state.amountPerDay);
                setTempDays(state.daysPerWeek);
                setTempStart(state.startPoint);
                setIsEditing(true);
              }} 
              className="p-2 rounded-xl bg-white dark:bg-navy-800 text-navy-600 dark:text-white hover:border-gold-500 transition-all border border-navy-100 dark:border-navy-700 shadow-sm"
              title="تعديل الخطة"
            >
              <Edit2 size={20} />
            </button>
          </div>
        } 
      />
      
      <div className="flex-1 overflow-y-auto p-5 pb-24 space-y-5">
        {/* Hero Progress Card */}
        <div className="relative bg-gradient-to-br from-navy-900 to-navy-800 dark:from-black dark:to-navy-900 rounded-[2.5rem] p-6 text-white shadow-2xl shadow-navy-900/30 overflow-hidden">
           {/* Decorative Elements */}
           <div className="absolute inset-0 opacity-10" style={{backgroundImage: "url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMiIgZmlsbD0ibm9uZSIgb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMjAgMEwyMCA0ME0wIDIwTDQwIDIwIiAvPjwvc3ZnPg==')"}}></div>
           <div className="absolute -top-24 -right-24 w-64 h-64 bg-gold-500/20 rounded-full blur-3xl"></div>
           <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-navy-950/50 to-transparent"></div>

           <div className="relative z-10">
             <div className="flex justify-between items-start mb-8">
               <div>
                 <div className="flex items-center gap-2 mb-1">
                    {isKhatmaComplete ? (
                        <span className="w-2 h-2 rounded-full bg-gold-400 animate-pulse"></span>
                    ) : (
                        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                    )}
                    <span className="text-xs font-bold text-navy-200 uppercase tracking-wider">
                        {isKhatmaComplete ? 'مبارك!' : 'ورد اليوم'}
                    </span>
                 </div>
                 {isKhatmaComplete ? (
                    <h2 className="text-3xl font-bold font-quran text-gold-400 mt-2">
                        أتممت الختمة
                    </h2>
                 ) : (
                    <h2 className="text-3xl font-bold font-quran text-white">
                        {toArabicDigits(state.amountPerDay)} <span className="text-lg text-navy-300">{state.planType === 'pages' ? 'صفحات' : 'آيات'}</span>
                    </h2>
                 )}
               </div>
               
               {/* Circular Progress Small */}
               <div className="relative w-14 h-14">
                  <svg className="w-full h-full -rotate-90">
                    <circle cx="50%" cy="50%" r="24" stroke="currentColor" strokeWidth="4" fill="transparent" className="text-white/10" />
                    <circle 
                      cx="50%" cy="50%" r="24" stroke="currentColor" strokeWidth="4" fill="transparent" 
                      strokeDasharray={2 * Math.PI * 24} 
                      strokeDashoffset={2 * Math.PI * 24 * (1 - progressPercent / 100)} 
                      strokeLinecap="round"
                      className="text-gold-400 transition-all duration-1000"
                    />
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold">
                    {toArabicDigits(progressPercent)}%
                  </span>
               </div>
             </div>

             <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/5">
                   <span className="block text-[10px] text-navy-300 mb-1">الموقع الحالي</span>
                   <div className="flex items-center gap-1.5 font-bold">
                      <BookOpen size={14} className="text-gold-400" />
                      <span>{state.planType === 'pages' ? 'صفحة' : 'آية'} {toArabicDigits(currentLocation)}</span>
                   </div>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/5">
                   <span className="block text-[10px] text-navy-300 mb-1">تاريخ الختم المتوقع</span>
                   <div className="flex items-center gap-1.5 font-bold">
                      <Calendar size={14} className="text-gold-400" />
                      <span className="text-xs truncate">{estimation.date}</span>
                   </div>
                </div>
             </div>

             {/* Action Buttons */}
             {isKhatmaComplete ? (
               <div className="w-full bg-gold-500 text-navy-900 font-bold py-3.5 rounded-xl shadow-lg flex items-center justify-center gap-2 animate-in zoom-in duration-500">
                 <Award size={20} />
                 <span>تقبل الله منك! ابدأ ختمة جديدة</span>
               </div>
             ) : (
               <div className="flex flex-col gap-2">
                   {/* Main Action: Log Progress */}
                   {!isTodayDone ? (
                       <button 
                         onClick={handleCompleteToday}
                         className="w-full bg-white text-navy-900 font-bold py-3.5 rounded-xl shadow-lg hover:bg-gold-50 transition-all active:scale-95 flex items-center justify-center gap-2 group"
                       >
                         <div className="w-5 h-5 rounded-full border-2 border-navy-900 group-hover:bg-navy-900/10 transition-colors"></div>
                         تسجيل إتمام الحفظ
                       </button>
                   ) : (
                       <div className="w-full bg-emerald-500/20 backdrop-blur-md border border-emerald-500/30 text-emerald-100 font-bold py-3.5 rounded-xl shadow-lg flex items-center justify-center gap-2 animate-in zoom-in duration-300">
                         <CheckCircle2 size={20} className="text-emerald-400" />
                         <span>أحسنت! تم إنجاز الورد</span>
                       </div>
                   )}

                   {/* Secondary Action: Go to Location (New) */}
                   <button 
                     onClick={handleGoToLocation}
                     className="w-full bg-white/10 hover:bg-white/20 text-white font-bold py-3 rounded-xl backdrop-blur-sm border border-white/10 flex items-center justify-center gap-2 transition-all"
                   >
                     <ArrowUpRight size={18} />
                     <span>
                        الذهاب للورد: {state.planType === 'pages' ? `صفحة ${toArabicDigits(Math.min(state.startPoint + state.currentProgress, 604))}` : `آية ${toArabicDigits(Math.min(state.startPoint + state.currentProgress, 6236))}`}
                     </span>
                   </button>
               </div>
             )}
           </div>
        </div>

        {/* Streak Section */}
        <div>
           <div className="flex justify-between items-center mb-3 px-2">
             <h3 className="font-bold text-navy-800 dark:text-white flex items-center gap-2">
               <Flame size={18} className="text-orange-500 fill-orange-500" />
               سجل الالتزام
             </h3>
             <span className="text-[10px] text-navy-400 bg-navy-100 dark:bg-navy-800 px-2 py-0.5 rounded-lg">
                {toArabicDigits(state.daysPerWeek)} أيام أسبوعياً
             </span>
           </div>
           <div className="bg-white dark:bg-navy-900 p-4 rounded-3xl shadow-sm border border-navy-100 dark:border-navy-800 overflow-x-auto no-scrollbar">
             <div className="flex justify-between items-center min-w-max gap-3">
               {Array.from({ length: 7 }).map((_, i) => {
                 const d = new Date();
                 d.setDate(d.getDate() - (6 - i)); // Past 6 days + Today
                 
                 const y = d.getFullYear();
                 const m = String(d.getMonth() + 1).padStart(2, '0');
                 const dayStr = String(d.getDate()).padStart(2, '0');
                 const dateKey = `${y}-${m}-${dayStr}`;
                 
                 const isDone = state.history.includes(dateKey);
                 const dayName = d.toLocaleDateString('ar-EG', { weekday: 'short' }).replace('ال', '');
                 const isToday = i === 6;

                 return (
                   <div key={i} className={`flex flex-col items-center gap-2 p-2 rounded-2xl min-w-[3rem] transition-all ${isToday ? 'bg-navy-50 dark:bg-navy-800' : ''}`}>
                     <span className={`text-[10px] font-bold ${isToday ? 'text-navy-800 dark:text-white' : 'text-navy-400'}`}>{dayName}</span>
                     <div className={`w-8 h-10 rounded-xl flex items-center justify-center transition-all duration-500 ${
                       isDone 
                         ? 'bg-gold-500 text-navy-900 shadow-md scale-110' 
                         : 'bg-navy-100 dark:bg-navy-800 text-navy-300 dark:text-navy-600'
                     }`}>
                       {isDone ? <CheckCircle2 size={16} /> : <div className="w-1.5 h-1.5 rounded-full bg-current opacity-50"></div>}
                     </div>
                   </div>
                 );
               })}
             </div>
           </div>
        </div>

        {/* Motivational Stat */}
        <div className="grid grid-cols-2 gap-4">
           <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-3xl border border-emerald-100 dark:border-emerald-800 flex flex-col justify-center items-center text-center">
              <TrendingUp size={24} className="text-emerald-600 mb-2" />
              <span className="text-2xl font-bold text-navy-900 dark:text-white font-sans">{toArabicDigits(currentStreak)}</span>
              <span className="text-[10px] font-bold text-navy-500 dark:text-navy-400">أيام متتالية (Streak)</span>
           </div>
           <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-3xl border border-blue-100 dark:border-blue-800 flex flex-col justify-center items-center text-center">
              <Trophy size={24} className="text-blue-600 mb-2" />
              <span className="text-2xl font-bold text-navy-900 dark:text-white font-sans">{toArabicDigits(state.currentProgress)}</span>
              <span className="text-[10px] font-bold text-navy-500 dark:text-navy-400">إجمالي {state.planType === 'pages' ? 'الصفحات' : 'الآيات'}</span>
           </div>
        </div>

      </div>

      {/* Delete Confirmation Modal (Persistent for Dashboard as well) */}
      {isDeleteModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-navy-900/80 backdrop-blur-sm" onClick={() => setIsDeleteModalOpen(false)}></div>
            <div className="relative w-full max-w-sm bg-white dark:bg-navy-900 rounded-[2rem] shadow-2xl overflow-hidden animate-in zoom-in-95 border border-navy-100 dark:border-navy-800 p-6">
               <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center text-red-500">
                     <AlertTriangle size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-navy-900 dark:text-white">حذف خطة الحفظ</h3>
                  <p className="text-navy-500 dark:text-navy-400 text-sm leading-relaxed">
                    هل أنت متأكد من رغبتك في حذف الخطة الحالية نهائياً؟ سيتم فقدان جميع سجلات التقدم.
                  </p>
                  
                  <div className="flex gap-3 w-full pt-4">
                     <button 
                       onClick={() => setIsDeleteModalOpen(false)}
                       className="flex-1 py-3 rounded-xl font-bold text-navy-600 dark:text-white hover:bg-navy-50 dark:hover:bg-navy-800 transition-colors"
                     >
                       إلغاء
                     </button>
                     <button 
                       onClick={handleDeletePlan}
                       className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-bold shadow-md shadow-red-500/30 transition-colors"
                     >
                       نعم، احذف
                     </button>
                  </div>
               </div>
            </div>
          </div>
        )}
    </div>
  );
};
