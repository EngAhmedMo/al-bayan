
import React, { useEffect, useState, useContext } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BookOpen, Activity, Grid, BookHeart, Shield, Calendar, Bookmark, Bell, Library, ChevronLeft, Moon, Sun, RefreshCw, Quote, Search, Sparkles, Clock, MapPin, X, Sunrise, Sunset, Moon as MoonIcon, Menu, Radio, WifiOff, Settings, Info } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';
import { useTheme, NavigationContext, useSettings } from '../components/Layout';
import { getUnreadCount, getStoredBenefit, setStoredBenefit, saveDailyPrayers, getDailyPrayers } from '../services/storage';
import { getHijriDate, MONTH_MAP } from '../services/eventsData';
import { fetchRandomBenefit, DailyBenefit, fetchPrayerTimes } from '../services/api';
import { PrayerData } from '../types';
import { Geolocation } from '@capacitor/geolocation';
import { scheduleAllNotifications } from '../services/notificationManager';
import { FirebaseService } from '../services/firebase'; 

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { isDark, toggleTheme } = useTheme();
  const { openSidebar } = useContext(NavigationContext);
  const { openSettings } = useSettings();
  const [lastRead, setLastRead] = useState<{surah: string, page: number} | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [hijri, setHijri] = useState({ day: 1, month: 1, year: 1446 });
  
  // Daily Benefit State
  const [dailyBenefit, setDailyBenefit] = useState<DailyBenefit | null>(null);
  const [loadingBenefit, setLoadingBenefit] = useState(false);

  // Prayer Times State
  const [prayerData, setPrayerData] = useState<PrayerData | null>(null);
  const [isPrayerModalOpen, setIsPrayerModalOpen] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [loadingPrayer, setLoadingPrayer] = useState(false);
  const [nextPrayer, setNextPrayer] = useState<{name: string, time: string, timeLeft: string} | null>(null);

  // --- Remote Config State ---
  const [remoteBanner, setRemoteBanner] = useState<{ active: boolean, text: string } | null>(null);

  // Unified button style class
  const headerBtnClass = "w-10 h-10 flex items-center justify-center rounded-xl bg-white dark:bg-navy-800 border border-navy-100 dark:border-navy-700 text-navy-600 dark:text-navy-300 hover:border-gold-400 dark:hover:border-gold-500 hover:text-gold-600 dark:hover:text-gold-400 shadow-sm hover:shadow-md transition-all duration-200 active:scale-95 relative overflow-hidden";

  useEffect(() => {
    const saved = localStorage.getItem('lastRead');
    if (saved) {
      setLastRead(JSON.parse(saved));
    }
    setUnreadCount(getUnreadCount());
    setHijri(getHijriDate());
    
    // Initial Load of Benefit (Respects Date)
    loadDailyBenefit();

    // Load cached prayers if available for today
    const cachedPrayers = getDailyPrayers();
    if (cachedPrayers) {
      setPrayerData(cachedPrayers);
      calculateNextPrayer(cachedPrayers);
      scheduleAllNotifications(cachedPrayers);
    }

    // --- Check URL for Deep Actions (e.g. from About page) ---
    const action = searchParams.get('action');
    if (action === 'prayers') {
      handleOpenPrayerTimes();
      // Remove the param so it doesn't reopen on refresh
      setSearchParams(prev => {
        const newParams = new URLSearchParams(prev);
        newParams.delete('action');
        return newParams;
      }, { replace: true });
    }

    // --- Load Remote Config (Banner) ---
    const loadRemoteConfig = async () => {
      const isActive = await FirebaseService.getBoolean('home_banner_active');
      if (isActive) {
        const text = await FirebaseService.getString('home_banner_text');
        setRemoteBanner({ active: true, text: text || 'أهلاً بكم في تطبيق البيان' });
      }
    };
    loadRemoteConfig();

  }, []);

  // Update Next Prayer Countdown every minute
  useEffect(() => {
    if (prayerData) {
      const interval = setInterval(() => {
        calculateNextPrayer(prayerData);
      }, 60000);
      calculateNextPrayer(prayerData);
      return () => clearInterval(interval);
    }
  }, [prayerData]);

  const loadDailyBenefit = async (forceNew = false) => {
    setLoadingBenefit(true);
    const todayStr = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    
    const stored = getStoredBenefit();
    if (!forceNew && stored && stored.date === todayStr && stored.data) {
      setDailyBenefit(stored.data);
      setLoadingBenefit(false);
      return;
    }

    try {
        const newData = await fetchRandomBenefit();
        if (newData) {
          setDailyBenefit(newData);
          setStoredBenefit(newData);
        }
    } catch (error) {
        console.error("Error loading benefit", error);
    }
    setLoadingBenefit(false);
  };

  const handleOpenPrayerTimes = () => {
    setIsPrayerModalOpen(true);
    const cachedPrayers = getDailyPrayers();
    if (!cachedPrayers) {
      fetchLocationAndPrayers();
    }
  };

  const fetchLocationAndPrayers = async () => {
    setLoadingPrayer(true);
    setLocationError(null);

    try {
      let lat, lng;
      try {
        const perm = await Geolocation.requestPermissions();
        if (perm.location === 'granted') {
           const pos = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 10000 });
           lat = pos.coords.latitude;
           lng = pos.coords.longitude;
        } else {
           throw new Error('Permission denied');
        }
      } catch (capError) {
        if (!navigator.geolocation) throw new Error("Geolocation not supported");
        await new Promise<void>((resolve, reject) => {
           navigator.geolocation.getCurrentPosition(
             (pos) => { lat = pos.coords.latitude; lng = pos.coords.longitude; resolve(); },
             (err) => reject(err)
           );
        });
      }

      if (lat && lng) {
        const data = await fetchPrayerTimes(lat, lng);
        if (data) {
          setPrayerData(data);
          saveDailyPrayers(data);
          calculateNextPrayer(data);
          scheduleAllNotifications(data);
        } else {
          setLocationError("تعذر جلب المواقيت من الخادم");
        }
      }
    } catch (error) {
      console.error(error);
      setLocationError("يرجى تفعيل خدمة الموقع (GPS) ومنح الصلاحيات");
    } finally {
      setLoadingPrayer(false);
    }
  };

  const calculateNextPrayer = (data: PrayerData) => {
    const now = new Date();
    const timings = data.timings;
    const prayers = [
      { name: 'الفجر', time: timings.Fajr },
      { name: 'الشروق', time: timings.Sunrise },
      { name: 'الظهر', time: timings.Dhuhr },
      { name: 'العصر', time: timings.Asr },
      { name: 'المغرب', time: timings.Maghrib },
      { name: 'العشاء', time: timings.Isha },
    ];

    for (let p of prayers) {
      const [hours, minutes] = p.time.split(':').map(Number);
      const pDate = new Date();
      pDate.setHours(hours, minutes, 0, 0);
      
      if (pDate > now) {
        const diff = pDate.getTime() - now.getTime();
        const diffHrs = Math.floor(diff / (1000 * 60 * 60));
        const diffMins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        
        setNextPrayer({
          name: p.name,
          time: p.time,
          timeLeft: `متبقي ${toArabicDigits(diffHrs)} ساعة و ${toArabicDigits(diffMins)} دقيقة`
        });
        return;
      }
    }
    
    setNextPrayer({ name: 'الفجر', time: timings.Fajr, timeLeft: 'غداً' });
  };

  const formatTime12 = (time24: string) => {
    if (!time24) return { time: '', period: '' };
    const [hStr, mStr] = time24.split(':');
    const h = parseInt(hStr);
    const m = parseInt(mStr);
    
    const period = h >= 12 ? 'م' : 'ص';
    const h12 = h % 12 || 12;
    
    return {
      time: `${toArabicDigits(h12)}:${toArabicDigits(m)}`,
      period
    };
  };

  const menuItems = [
    { title: 'المصحف الكريم', icon: <BookOpen size={28} />, path: '/reader', bg: 'bg-navy-800', text: 'text-white' },
    { title: 'الإذاعة المباشرة', icon: <Radio size={28} />, path: '/radio', bg: 'bg-emerald-600', text: 'text-white' },
    { title: 'حصن المسلم', icon: <Shield size={28} />, path: '/adhkar', bg: 'bg-gold-600', text: 'text-white' },
    { title: 'الحديث الشريف', icon: <BookHeart size={28} />, path: '/hadith', bg: 'bg-navy-700', text: 'text-white' },
    { title: 'بحث في القرآن', icon: <Search size={28} />, path: '/search', bg: 'bg-sky-600', text: 'text-white' },
    { title: 'خطة الحفظ', icon: <Activity size={28} />, path: '/hifz', bg: 'bg-gold-500', text: 'text-white' },
    { title: 'السبحة', icon: <Grid size={28} />, path: '/tasbih', bg: 'bg-navy-600', text: 'text-white' },
    { title: 'المحفوظات', icon: <Bookmark size={28} />, path: '/bookmarks', bg: 'bg-gold-700', text: 'text-white' },
    { title: 'المناسبات', icon: <Calendar size={28} />, path: '/events', bg: 'bg-navy-500', text: 'text-white' },
    { title: 'التحميلات (أوفلاين)', icon: <WifiOff size={28} />, path: '/downloads', bg: 'bg-slate-600', text: 'text-white' },
  ];

  const daysRemaining = 30 - hijri.day;
  const gregorianDateStr = new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <div className="flex flex-col min-h-full bg-gold-50 dark:bg-navy-950 pb-24 font-sans">
      
      {/* Top Bar */}
      <div className="flex justify-between items-center px-6 pt-6 pb-2">
         <div className="flex items-center gap-3">
            <button onClick={openSidebar} className={`${headerBtnClass} md:hidden`} title="القائمة الجانبية">
              <Menu size={20} />
            </button>
            <div className="flex items-center gap-2 cursor-pointer group select-none" onClick={() => navigate('/about')} title="عن التطبيق">
                <div className="flex items-center gap-2">
                   <div className="w-10 h-10 bg-navy-900 dark:bg-white rounded-xl flex items-center justify-center text-white dark:text-navy-900 shadow-md">
                      <span className="font-quran text-2xl font-bold mt-1">ب</span>
                   </div>
                   <div>
                      <h1 className="text-xl font-bold text-navy-900 dark:text-white font-quran leading-none">البيان</h1>
                      <p className="text-[9px] font-bold text-gold-600 dark:text-gold-400 tracking-wider">القرآن والسنة</p>
                   </div>
                </div>
            </div>
         </div>
         <div className="flex gap-2">
            <button className={headerBtnClass} onClick={() => navigate('/notifications')}>
               <Bell size={20} />
               {unreadCount > 0 && (
                 <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white dark:ring-navy-900 animate-pulse"></span>
               )}
            </button>
            <button onClick={toggleTheme} className={headerBtnClass}>
               <div className={`absolute inset-0 flex items-center justify-center transition-all duration-300 transform ${isDark ? 'opacity-100 scale-100 rotate-0' : 'opacity-0 scale-50 rotate-90'}`}>
                  <Sun size={20} className="text-gold-500" fill="currentColor" />
               </div>
               <div className={`absolute inset-0 flex items-center justify-center transition-all duration-300 transform ${!isDark ? 'opacity-100 scale-100 rotate-0' : 'opacity-0 scale-50 -rotate-90'}`}>
                  <Moon size={20} className="text-navy-600" />
               </div>
            </button>
         </div>
      </div>

      {remoteBanner && remoteBanner.active && (
        <div className="mx-5 mt-4 p-3 bg-gradient-to-r from-gold-500 to-amber-500 text-navy-900 rounded-2xl shadow-lg flex items-center gap-3 animate-in slide-in-from-top-4 duration-500">
           <div className="bg-white/20 p-2 rounded-full backdrop-blur-sm"><Info size={18} /></div>
           <p className="text-sm font-bold flex-1">{remoteBanner.text}</p>
           <button onClick={() => setRemoteBanner(null)} className="p-1 rounded-full hover:bg-white/10"><X size={16} /></button>
        </div>
      )}

      {/* --- PREMIUM DATE CARD --- */}
      <div className="px-5 mt-4">
        <div className="relative w-full h-56 bg-[#0F2238] rounded-[2.5rem] shadow-2xl overflow-hidden text-white">
           
           {/* 1. Left Gold Square (Day) - Balanced with light frame */}
           <div className="absolute top-6 left-6 w-20 h-20 bg-gradient-to-b from-[#C6AD73] to-[#886E38] rounded-[1.5rem] flex flex-col items-center justify-center shadow-lg border-2 border-navy-400/30">
              <span className="text-4xl font-bold font-sans text-white drop-shadow-sm mt-1">
                {toArabicDigits(hijri.day)}
              </span>
           </div>

           {/* 2. Right Month & Year */}
           <div className="absolute top-8 right-8 text-right">
              <h2 className="text-5xl font-bold font-quran text-white mb-1 drop-shadow-md">
                {MONTH_MAP[hijri.month]}
              </h2>
              <div className="text-lg font-light text-gray-300 opacity-90 flex items-center justify-end gap-2 font-sans">
                 <span>{toArabicDigits(hijri.year)}</span>
                 <span className="text-sm font-bold">هـ</span>
              </div>
           </div>

           {/* 3. Middle Right - Gregorian Date Pill */}
           <div className="absolute top-32 right-6">
              <div className="bg-[#1A314D] px-5 py-3 rounded-2xl border border-[#2A4566] shadow-sm">
                 <span className="text-sm font-bold text-gray-300 font-sans tracking-wide">
                   {gregorianDateStr}
                 </span>
              </div>
           </div>

           {/* 4. Bottom Row */}
           <div className="absolute bottom-0 left-0 w-full px-6 pb-6 flex items-end justify-between">
              
              {/* Left: Days Remaining */}
              <div className="flex items-center gap-2 text-[#C6AD73] mb-2">
                 <span className="text-[10px] font-bold">●</span>
                 <span className="text-xs font-bold tracking-wide">
                   {toArabicDigits(daysRemaining > 0 ? daysRemaining : 0)} يوم لنهاية الشهر الهجري
                 </span>
              </div>

              {/* Right: Prayer Times Button - PROMINENT GOLD FRAME */}
              <button 
                onClick={handleOpenPrayerTimes}
                className="bg-[#1A314D] hover:bg-[#233D5C] text-white px-5 py-3 rounded-2xl border-2 border-gold-500 flex items-center gap-2 transition-all active:scale-95 shadow-[0_0_15px_rgba(176,141,85,0.2)]"
              >
                 <span className="text-sm font-bold text-gold-50">مواقيت الصلاة</span>
                 <Clock size={18} className="text-[#C6AD73]" />
              </button>
           </div>

        </div>
      </div>

      {/* Prayer Times Modal */}
      {isPrayerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-navy-950/80 backdrop-blur-sm transition-opacity" onClick={() => setIsPrayerModalOpen(false)}></div>
          <div className="relative w-full max-w-sm bg-white dark:bg-navy-900 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 border border-navy-100 dark:border-navy-800 flex flex-col max-h-[85vh]">
             
             <div className="p-5 border-b border-navy-100 dark:border-navy-800 flex justify-between items-center bg-gold-50 dark:bg-navy-950">
               <h3 className="font-bold text-lg text-navy-900 dark:text-white flex items-center gap-2">
                 <Clock size={20} className="text-gold-500" /> مواقيت الصلاة
               </h3>
               <div className="flex gap-2">
                   <button onClick={() => { setIsPrayerModalOpen(false); openSettings(); }} className="p-1.5 rounded-full hover:bg-navy-200 dark:hover:bg-navy-800 text-navy-500"><Settings size={20} /></button>
                   <button onClick={() => setIsPrayerModalOpen(false)} className="p-1.5 rounded-full hover:bg-navy-200 dark:hover:bg-navy-800 text-navy-500"><X size={20} /></button>
               </div>
             </div>

             <div className="flex-1 overflow-y-auto p-5 custom-scrollbar bg-slate-50 dark:bg-navy-900">
                {loadingPrayer ? (
                  <div className="flex flex-col items-center justify-center py-10 space-y-4">
                    <div className="w-10 h-10 border-4 border-gold-200 border-t-gold-500 rounded-full animate-spin"></div>
                    <p className="text-sm font-bold text-navy-500 dark:text-navy-300">جاري تحديد الموقع...</p>
                  </div>
                ) : locationError ? (
                  <div className="flex flex-col items-center justify-center py-10 text-center space-y-3">
                    <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center text-red-500">
                      <MapPin size={28} />
                    </div>
                    <p className="text-sm font-bold text-navy-800 dark:text-white px-4">{locationError}</p>
                    <button onClick={fetchLocationAndPrayers} className="px-4 py-2 bg-navy-800 text-white rounded-xl text-sm font-bold shadow-md mt-2">إعادة المحاولة</button>
                  </div>
                ) : prayerData ? (
                  <div className="space-y-5">
                     <div className="text-center mb-2">
                        <div className="inline-flex items-center gap-1.5 bg-white dark:bg-navy-800 px-3 py-1 rounded-full border border-navy-100 dark:border-navy-700 shadow-sm text-xs font-bold text-navy-500 dark:text-navy-300 mb-2">
                           <MapPin size={12} /> بتوقيت {prayerData.meta.timezone}
                        </div>
                        <p className="text-xs text-navy-400 font-medium">{prayerData.date.hijri.weekday.ar} {prayerData.date.hijri.date}</p>
                     </div>

                     {nextPrayer && (
                       <div className="bg-gradient-to-br from-navy-800 to-navy-900 rounded-2xl p-5 text-white shadow-lg relative overflow-hidden text-center">
                          <div className="relative z-10">
                             <p className="text-xs text-navy-300 font-bold uppercase tracking-wider mb-1">الصلاة القادمة</p>
                             <h2 className="text-3xl font-bold font-quran mb-1 text-gold-400">{nextPrayer.name}</h2>
                             <div className="text-4xl font-bold font-sans tracking-tight mb-2 flex items-baseline justify-center gap-2" dir="ltr">
                               <span>{formatTime12(nextPrayer.time).time}</span>
                               <span className="text-lg text-gold-500">{formatTime12(nextPrayer.time).period}</span>
                             </div>
                             <div className="inline-block bg-white/10 px-3 py-1 rounded-lg text-xs font-medium backdrop-blur-sm border border-white/10">
                               {nextPrayer.timeLeft}
                             </div>
                          </div>
                       </div>
                     )}

                     <div className="space-y-2">
                        {[
                          { name: 'الفجر', key: 'Fajr', icon: <MoonIcon size={16} /> },
                          { name: 'الشروق', key: 'Sunrise', icon: <Sunrise size={16} /> },
                          { name: 'الظهر', key: 'Dhuhr', icon: <Sun size={16} /> },
                          { name: 'العصر', key: 'Asr', icon: <Sun size={16} className="opacity-70" /> },
                          { name: 'المغرب', key: 'Maghrib', icon: <Sunset size={16} /> },
                          { name: 'العشاء', key: 'Isha', icon: <Moon size={16} /> },
                        ].map((p, idx) => {
                           const time24 = prayerData.timings[p.key];
                           const formatted = formatTime12(time24);
                           const isNext = nextPrayer?.name === p.name;
                           
                           return (
                             <div key={idx} className={`flex justify-between items-center p-3.5 rounded-xl border transition-all ${isNext ? 'bg-gold-50 dark:bg-gold-900/10 border-gold-50 shadow-sm scale-[1.02]' : 'bg-white dark:bg-navy-800 border-navy-100 dark:border-navy-700'}`}>
                                <div className="flex items-center gap-3">
                                   <div className={`p-2 rounded-full ${isNext ? 'bg-gold-500 text-white' : 'bg-navy-50 dark:bg-navy-900 text-navy-400'}`}>{p.icon}</div>
                                   <span className={`font-bold ${isNext ? 'text-navy-900 dark:text-gold-400' : 'text-navy-700 dark:text-white'}`}>{p.name}</span>
                                </div>
                                <div className="flex items-center gap-1 dir-ltr">
                                  <span className={`font-bold font-sans text-lg ${isNext ? 'text-navy-900 dark:text-gold-400' : 'text-navy-600 dark:text-navy-300'}`}>{formatted.time}</span>
                                  <span className={`text-xs font-bold ${isNext ? 'text-gold-600 dark:text-gold-500' : 'text-navy-400'}`}>{formatted.period}</span>
                                </div>
                             </div>
                           );
                        })}
                     </div>
                  </div>
                ) : null}
             </div>
          </div>
        </div>
      )}

      <div className="px-5 mt-6">
         <div className="grid grid-cols-2 gap-3">
            {menuItems.map((item, idx) => (
               <button 
                 key={idx}
                 onClick={() => navigate(item.path)}
                 className={`${item.bg} ${item.text} p-4 rounded-xl shadow-sm flex items-center gap-3 hover:scale-[1.02] active:scale-95 transition-all relative overflow-hidden group`}
               >
                  <div className="absolute right-0 top-0 w-16 h-16 bg-white/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-150"></div>
                  <div className="relative z-10 p-2 bg-white/20 rounded-lg">
                     {item.icon}
                  </div>
                  <span className="relative z-10 font-bold text-sm">{item.title}</span>
               </button>
            ))}
         </div>
      </div>

      <div className="px-5 mt-6">
         <div className="bg-white dark:bg-navy-900 rounded-2xl p-5 shadow-sm border-r-4 border-gold-500 flex justify-between items-center cursor-pointer hover:shadow-md transition-all" onClick={() => navigate(lastRead ? `/reader?page=${lastRead.page}` : '/reader')}>
            <div>
               <h3 className="text-xs font-bold text-navy-400 dark:text-navy-300 mb-1">آخر قراءة</h3>
               <p className="text-xl font-bold text-navy-900 dark:text-white font-quran">{lastRead ? `سورة ${lastRead.surah}` : 'القرآن الكريم'}</p>
               <p className="text-xs text-navy-500 mt-1">{lastRead ? `صفحة ${toArabicDigits(lastRead.page)}` : 'اضغط للبدء'}</p>
            </div>
            <div className="w-10 h-10 bg-navy-50 dark:bg-navy-800 rounded-full flex items-center justify-center text-navy-600 dark:text-gold-400"><ChevronLeft size={20} /></div>
         </div>
      </div>

      <div className="px-5 mt-6 mb-4">
         <div className="bg-white dark:bg-navy-900 rounded-2xl p-6 shadow-sm relative overflow-hidden border border-navy-100 dark:border-navy-800">
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-gold-400 to-navy-500"></div>
            <div className="flex justify-between items-center mb-4">
               <div className="flex items-center gap-2">
                  <BookHeart size={20} className="text-gold-500" />
                  <span className="text-sm font-bold text-navy-800 dark:text-white">فائدة اليوم</span>
               </div>
               <button 
                 onClick={() => loadDailyBenefit(true)} 
                 disabled={loadingBenefit}
                 className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-navy-50 dark:bg-navy-800 text-navy-600 dark:text-navy-300 hover:bg-gold-500 hover:text-white transition-all text-[10px] font-bold ${loadingBenefit ? 'opacity-50' : ''}`}
               >
                 {loadingBenefit ? (<RefreshCw size={14} className="animate-spin" />) : (<Sparkles size={14} />)}
                 <span>فائدة جديدة</span>
               </button>
            </div>
            {loadingBenefit ? (
              <div className="space-y-4 animate-pulse">
                <div className="h-6 bg-navy-100 dark:bg-navy-800 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-navy-50 dark:bg-navy-800 rounded w-full"></div>
                <div className="h-4 bg-navy-50 dark:bg-navy-800 rounded w-5/6"></div>
              </div>
            ) : dailyBenefit ? (
              <>
                <div className="relative mb-5">
                   <Quote size={24} className="text-gold-200 dark:text-navy-700 absolute -top-2 right-0 rotate-180" />
                   <p className="font-quran text-xl leading-[2.4] text-center text-navy-900 dark:text-white px-4">{dailyBenefit.ayah.text}</p>
                   <p className="text-[10px] text-center text-navy-400 mt-2 font-bold">{dailyBenefit.surahName} - آية {toArabicDigits(dailyBenefit.ayah.numberInSurah)}</p>
                </div>
                <div className="bg-navy-50 dark:bg-navy-950/50 p-4 rounded-xl border border-navy-100 dark:border-navy-800">
                   <h4 className="text-[10px] font-bold text-gold-600 mb-2 flex items-center gap-1"><Library size={12} /> التفسير الميسر:</h4>
                   <p className="text-xs sm:text-sm text-navy-600 dark:text-navy-200 leading-relaxed text-justify">{dailyBenefit.tafsir}</p>
                </div>
              </>
            ) : (
              <div className="text-center text-red-400 text-sm py-4">فشل في تحميل الفائدة. تأكد من الاتصال بالإنترنت.</div>
            )}
         </div>
      </div>
    </div>
  );
};
