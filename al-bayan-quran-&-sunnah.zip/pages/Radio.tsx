
import React, { useState } from 'react';
import { TopBar } from '../components/TopBar';
import { RADIO_STATIONS } from '../services/radioData';
import { RadioStation } from '../types';
import { Play, Pause, Radio as RadioIcon, Volume2, Globe, User, RefreshCw, Star, Info } from 'lucide-react';
import { useRadio } from '../components/Layout'; 

export const Radio: React.FC = () => {
  // Use Global Context
  const { activeStation, isPlaying, isLoading, error, playStation, toggleRadio } = useRadio();
  
  const [category, setCategory] = useState<'all' | 'quran' | 'cairo' | 'reciters'>('all');
  
  // Filter Stations
  const filteredStations = RADIO_STATIONS.filter(s => {
    if (category === 'all') return true;
    if (category === 'cairo') return s.category === 'cairo';
    if (category === 'quran') return s.category === 'quran';
    if (category === 'reciters') return s.category === 'reciters';
    return true;
  });

  const handleStationClick = (station: RadioStation) => {
    if (activeStation?.id === station.id) {
      toggleRadio();
    } else {
      playStation(station);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="الإذاعة المباشرة" />
      
      <div className="flex-1 overflow-y-auto p-4 md:p-6 pb-24 custom-scrollbar">
        
        {/* Category Tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto no-scrollbar pb-2">
           {[
             { id: 'all', label: 'الكل' },
             { id: 'cairo', label: 'القاهرة' },
             { id: 'quran', label: 'الحرمين' },
             { id: 'reciters', label: 'المشايخ' },
           ].map((tab) => (
             <button
               key={tab.id}
               onClick={() => setCategory(tab.id as any)}
               className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                 category === tab.id 
                   ? 'bg-navy-800 text-white border-navy-800 shadow-md' 
                   : 'bg-white dark:bg-navy-900 text-navy-500 dark:text-navy-300 border-navy-100 dark:border-navy-800'
               }`}
             >
               {tab.label}
             </button>
           ))}
        </div>

        {/* Helper Tip */}
        <div className="mb-6 mx-1">
          <div className="flex items-start gap-3 p-3 rounded-xl bg-gold-50/50 dark:bg-navy-800/50 border border-gold-200 dark:border-gold-500/20 text-navy-700 dark:text-gold-100 text-xs sm:text-sm leading-relaxed animate-in fade-in shadow-sm">
             <Info size={18} className="text-gold-500 mt-0.5 shrink-0" />
             <p className="opacity-90">
               يمكنك تصفح باقي أقسام التطبيق أثناء الاستماع للراديو. سيظهر شريط التحكم في الأسفل.
             </p>
          </div>
        </div>

        {/* Active Player Card (Hero) - Shows info for currently playing station */}
        {activeStation && (
           <div className="mb-8 relative overflow-hidden rounded-3xl bg-[#1e293b] text-white p-6 shadow-2xl animate-in slide-in-from-top-4 duration-500">
              {/* Visualizer Background Effect */}
              {isPlaying && !error && (
                 <div className="absolute inset-0 flex items-center justify-center gap-1 opacity-10 pointer-events-none">
                    {[...Array(20)].map((_, i) => (
                       <div key={i} className="w-2 bg-emerald-500 rounded-full animate-[music-bar_1s_ease-in-out_infinite]" style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 0.1}s` }}></div>
                    ))}
                 </div>
              )}
              
              <div className="relative z-10 flex flex-col items-center text-center">
                 <div className={`w-24 h-24 rounded-full border-4 border-emerald-500/30 flex items-center justify-center mb-4 bg-white/10 backdrop-blur-md shadow-lg ${isPlaying ? 'animate-pulse' : ''}`}>
                    {activeStation.img ? (
                        <img src={activeStation.img} alt={activeStation.name} className="w-full h-full object-cover rounded-full" />
                    ) : (
                        <RadioIcon size={40} className="text-emerald-400" />
                    )}
                 </div>
                 
                 <h2 className="text-2xl font-bold mb-1 px-4 leading-tight">{activeStation.name}</h2>
                 
                 {error ? (
                    <div className="flex items-center gap-2 text-red-400 bg-red-900/20 px-3 py-1 rounded-lg text-xs font-bold mb-6 mt-1 animate-in fade-in">
                       {error}
                    </div>
                 ) : (
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-6 flex items-center gap-2">
                       <span className={`w-2 h-2 rounded-full ${isLoading ? 'bg-amber-500' : 'bg-red-500'} animate-pulse`}></span>
                       {isLoading 
                         ? 'جاري الاتصال...' 
                         : (isPlaying ? 'بث مباشر' : 'متوقف')}
                    </p>
                 )}

                 <button 
                   onClick={() => toggleRadio()}
                   className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20 transition-transform active:scale-95"
                 >
                    {isLoading ? (
                        <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : isPlaying ? (
                        <Pause size={28} fill="currentColor" />
                    ) : (
                        <Play size={28} fill="currentColor" className="ml-1" />
                    )}
                 </button>
              </div>
           </div>
        )}

        {/* Grid List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
           {filteredStations.map((station) => (
             <div 
               key={station.id}
               onClick={() => handleStationClick(station)}
               className={`p-4 rounded-2xl border transition-all cursor-pointer group hover:shadow-md flex items-center gap-4 min-h-[90px] ${
                 activeStation?.id === station.id 
                   ? 'bg-emerald-50 dark:bg-emerald-900/10 border-emerald-500 ring-1 ring-emerald-500' 
                   : 'bg-white dark:bg-navy-900 border-navy-100 dark:border-navy-800 hover:border-gold-300'
               }`}
             >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${activeStation?.id === station.id ? 'bg-emerald-500 text-white' : 'bg-navy-50 dark:bg-navy-800 text-navy-400 dark:text-navy-300'}`}>
                   {station.category === 'reciters' ? <User size={20} /> : station.category === 'cairo' ? <RadioIcon size={20} /> : <Globe size={20} />}
                </div>
                
                <div className="flex-1 min-w-0 text-right">
                   <h3 className={`font-bold text-sm leading-tight mb-1 ${activeStation?.id === station.id ? 'text-navy-900 dark:text-emerald-400' : 'text-navy-800 dark:text-white'}`}>
                     {station.name}
                     {station.id === 'mustafa_ismail' && <Star size={12} className="text-gold-500 fill-gold-500 inline-block mr-1" />}
                   </h3>
                   <div className="flex items-center gap-1">
                       {activeStation?.id === station.id && isLoading && (
                           <RefreshCw size={10} className="animate-spin text-amber-500" />
                       )}
                       <p className={`text-[10px] ${activeStation?.id === station.id && error ? 'text-red-500' : 'text-navy-400 dark:text-navy-500'}`}>
                         {activeStation?.id === station.id 
                            ? (error ? 'خطأ' : (isPlaying ? 'جاري التشغيل...' : (isLoading ? 'جاري التحميل...' : 'متوقف'))) 
                            : 'اضغط للتشغيل'}
                       </p>
                   </div>
                </div>

                {activeStation?.id === station.id && isPlaying && !error && (
                   <Volume2 size={18} className="text-emerald-500 animate-pulse shrink-0" />
                )}
             </div>
           ))}
        </div>

      </div>
    </div>
  );
};
