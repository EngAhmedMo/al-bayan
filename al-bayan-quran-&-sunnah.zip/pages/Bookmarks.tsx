
import React, { useState, useEffect } from 'react';
import { TopBar } from '../components/TopBar';
import { getPageBookmarks, getAyahBookmarks, removePageBookmark, deleteAyahBookmark, getNotes, deleteNote } from '../services/storage';
import { PageBookmark, AyahBookmark, Note } from '../types';
import { Bookmark, FileText, Trash2, ArrowUpLeft, FileEdit, Clock, ChevronRight, Inbox, StickyNote } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';
import { useNavigate } from 'react-router-dom';

export const Bookmarks: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'pages' | 'ayahs' | 'notes'>('pages');
  const [pages, setPages] = useState<PageBookmark[]>([]);
  const [ayahs, setAyahs] = useState<AyahBookmark[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const navigate = useNavigate();

  const refreshData = () => {
    setPages(getPageBookmarks());
    setAyahs(getAyahBookmarks());
    setNotes(getNotes());
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleDeletePage = (pNum: number) => {
    if(window.confirm("هل أنت متأكد من حذف هذا الفاصل؟")) {
        removePageBookmark(pNum);
        refreshData();
    }
  };

  const handleDeleteAyah = (id: string) => {
    if(window.confirm("هل أنت متأكد من حذف هذه الآية من المفضلة؟")) {
        deleteAyahBookmark(id);
        refreshData();
    }
  };

  const handleDeleteNote = (id: string) => {
    if(window.confirm("هل أنت متأكد من حذف هذه الملاحظة؟")) {
        deleteNote(id);
        refreshData();
    }
  };

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="المحفوظات والملاحظات" />
      
      {/* Premium Segmented Control */}
      <div className="px-4 pt-4">
        <div className="max-w-md mx-auto bg-white dark:bg-navy-900 p-1.5 rounded-2xl border border-navy-100 dark:border-navy-800 shadow-sm flex">
          {[
            { id: 'pages', label: 'الفواصل', icon: <Bookmark size={16} /> },
            { id: 'ayahs', label: 'الآيات', icon: <FileText size={16} /> },
            { id: 'notes', label: 'الملاحظات', icon: <FileEdit size={16} /> },
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
                activeTab === tab.id 
                  ? 'bg-navy-800 text-white shadow-md' 
                  : 'text-navy-500 hover:bg-navy-50 dark:hover:bg-navy-800 dark:text-navy-400'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 custom-scrollbar">
        <div className="max-w-3xl mx-auto space-y-3">
            
            {/* --- Pages Tab --- */}
            {activeTab === 'pages' && (
              pages.length > 0 ? (
                pages.map((item) => (
                  <div key={item.id} className="bg-white dark:bg-navy-900 p-4 rounded-2xl border border-navy-100 dark:border-navy-800 shadow-sm flex items-center justify-between group hover:border-gold-300 dark:hover:border-navy-600 transition-colors animate-in fade-in slide-in-from-bottom-2">
                    <div className="flex items-center gap-4 cursor-pointer flex-1" onClick={() => navigate(`/reader?page=${item.pageNumber}`)}>
                      <div className="w-12 h-12 bg-gold-50 dark:bg-navy-800 text-gold-600 dark:text-gold-500 rounded-xl flex flex-col items-center justify-center border border-gold-100 dark:border-navy-700">
                         <span className="text-[10px] font-bold">ص</span>
                         <span className="text-lg font-bold leading-none font-sans">{toArabicDigits(item.pageNumber)}</span>
                      </div>
                      <div>
                        <h3 className="font-bold text-navy-900 dark:text-white text-lg">{item.surahName}</h3>
                        <p className="text-xs text-navy-400 mt-0.5 flex items-center gap-1">
                            <Clock size={10} />
                            {new Date(item.timestamp).toLocaleDateString('ar-EG')}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => handleDeletePage(item.pageNumber)}
                        className="p-2 text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors"
                        title="حذف"
                      >
                        <Trash2 size={18} />
                      </button>
                      <button 
                        onClick={() => navigate(`/reader?page=${item.pageNumber}`)}
                        className="p-2 bg-navy-50 dark:bg-navy-800 text-navy-600 dark:text-navy-300 rounded-xl hover:bg-gold-500 hover:text-white transition-colors"
                        title="انتقال"
                      >
                        <ChevronRight size={18} className="rotate-180" />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <EmptyState icon={<Bookmark size={48} />} text="لا توجد فواصل صفحات محفوظة" subtext="يمكنك إضافة فاصل أثناء القراءة للعودة لاحقاً" />
              )
            )}

            {/* --- Ayahs Tab --- */}
            {activeTab === 'ayahs' && (
              ayahs.length > 0 ? (
                ayahs.map((item) => (
                  <div key={item.id} className="bg-white dark:bg-navy-900 p-4 rounded-2xl border border-navy-100 dark:border-navy-800 shadow-sm flex items-center justify-between group hover:border-gold-300 dark:hover:border-navy-600 transition-colors animate-in fade-in slide-in-from-bottom-2">
                    <div className="flex items-center gap-4 cursor-pointer flex-1" onClick={() => navigate(`/reader?page=${item.pageNumber}&highlight=${item.surahNumber}:${item.ayahNumber}`)}>
                      <div className="w-12 h-12 bg-navy-50 dark:bg-navy-800 text-navy-600 dark:text-navy-300 rounded-xl flex flex-col items-center justify-center border border-navy-100 dark:border-navy-700">
                         <span className="text-[10px] font-bold">آية</span>
                         <span className="text-lg font-bold leading-none font-sans">{toArabicDigits(item.ayahNumber)}</span>
                      </div>
                      <div>
                        <h3 className="font-bold text-navy-900 dark:text-white text-lg">{item.surahName}</h3>
                        <p className="text-xs text-navy-400 mt-0.5">صفحة {toArabicDigits(item.pageNumber)}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => handleDeleteAyah(item.id)}
                        className="p-2 text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors"
                        title="حذف"
                      >
                        <Trash2 size={18} />
                      </button>
                      <button 
                        onClick={() => navigate(`/reader?page=${item.pageNumber}&highlight=${item.surahNumber}:${item.ayahNumber}`)}
                        className="p-2 bg-navy-50 dark:bg-navy-800 text-navy-600 dark:text-navy-300 rounded-xl hover:bg-gold-500 hover:text-white transition-colors"
                        title="انتقال"
                      >
                        <ArrowUpLeft size={18} />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <EmptyState icon={<Inbox size={48} />} text="لا توجد آيات محفوظة" subtext="اضغط على أي آية أثناء القراءة لحفظها" />
              )
            )}

            {/* --- Notes Tab --- */}
            {activeTab === 'notes' && (
              notes.length > 0 ? (
                notes.map((item) => (
                  <div key={item.id} className="bg-white dark:bg-navy-900 p-5 rounded-2xl border border-navy-100 dark:border-navy-800 shadow-sm hover:shadow-md transition-all group animate-in fade-in slide-in-from-bottom-2">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-2">
                         <span className="text-xs font-bold text-gold-700 bg-gold-50 dark:bg-navy-800 dark:text-gold-400 px-2 py-1 rounded-lg border border-gold-100 dark:border-navy-700">
                           {item.surahName} : {toArabicDigits(item.ayahNumber)}
                         </span>
                         <span className="text-[10px] text-navy-400 flex items-center gap-1">
                           <Clock size={10} /> {new Date(item.timestamp).toLocaleDateString('ar-EG')}
                         </span>
                      </div>
                      <div className="flex gap-1">
                        <button 
                          onClick={() => navigate(`/reader?page=${item.pageNumber}&highlight=${item.surahNumber}:${item.ayahNumber}`)}
                          className="p-1.5 text-navy-400 hover:text-gold-500 transition-colors"
                          title="انتقال للآية"
                        >
                          <ArrowUpLeft size={16} />
                        </button>
                        <button 
                          onClick={() => handleDeleteNote(item.id)}
                          className="p-1.5 text-navy-400 hover:text-red-500 transition-colors"
                          title="حذف"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                    
                    <p className="text-navy-800 dark:text-navy-100 text-sm leading-relaxed whitespace-pre-wrap bg-navy-50 dark:bg-navy-950/50 p-3 rounded-xl border border-navy-100 dark:border-navy-800">
                      {item.text}
                    </p>
                  </div>
                ))
              ) : (
                <EmptyState icon={<StickyNote size={48} />} text="لا توجد ملاحظات مدونة" subtext="دون خواطرك وتدبراتك على الآيات بسهولة" />
              )
            )}
        </div>
      </div>
    </div>
  );
};

const EmptyState = ({ icon, text, subtext }: { icon: React.ReactNode, text: string, subtext?: string }) => (
  <div className="flex flex-col items-center justify-center py-24 text-navy-300 dark:text-navy-600 animate-in fade-in zoom-in-95 text-center">
    <div className="mb-4 opacity-50 bg-navy-50 dark:bg-navy-900 p-4 rounded-full">{icon}</div>
    <p className="font-bold text-sm text-navy-600 dark:text-navy-400">{text}</p>
    {subtext && <p className="text-xs text-navy-400 mt-1 max-w-xs">{subtext}</p>}
  </div>
);
