
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar } from '../components/TopBar';
import { Heart, Code, Mail, MessageCircle, BookOpen, Activity, Mic, WifiOff, Radio, Clock, Shield, Database, ChevronLeft, Layers } from 'lucide-react';

export const About: React.FC = () => {
  const navigate = useNavigate();

  const handleEmail = () => {
    window.location.href = "mailto:engahmedmohammed00@gmail.com?subject=تواصل بخصوص تطبيق البيان";
  };

  const handleWhatsApp = () => {
    window.open("https://wa.me/201012489813", "_blank");
  };

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans transition-colors duration-500">
      <TopBar title="عن التطبيق" showBack />
      
      <div className="flex-1 overflow-y-auto pb-24 custom-scrollbar">
        <div className="max-w-3xl mx-auto p-6 space-y-10 animate-in slide-in-from-bottom-6 duration-500">
          
          {/* 1. Hero Section: Branding */}
          <div className="flex flex-col items-center text-center pt-6 relative">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-gold-500/10 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="relative z-10 w-28 h-28 bg-navy-900 dark:bg-white rounded-[2rem] flex items-center justify-center text-white dark:text-navy-900 shadow-2xl shadow-navy-900/20 dark:shadow-white/5 border-4 border-white dark:border-navy-800 transform hover:scale-105 transition-transform duration-500">
               <span className="font-quran text-7xl font-bold mt-3">ب</span>
            </div>
            
            <div className="mt-5 relative z-10">
              <h1 className="text-4xl font-bold text-navy-900 dark:text-white font-quran mb-1 drop-shadow-sm">البيان</h1>
              <div className="flex items-center justify-center gap-2">
                <span className="h-px w-8 bg-gold-500/50"></span>
                <p className="text-sm font-bold text-gold-600 dark:text-gold-400 tracking-widest uppercase">القرآن والسنة</p>
                <span className="h-px w-8 bg-gold-500/50"></span>
              </div>
              <span className="inline-block mt-2 px-3 py-1 bg-navy-100 dark:bg-navy-800 text-navy-600 dark:text-navy-300 text-[10px] font-bold rounded-full border border-navy-200 dark:border-navy-700">
                الإصدار 1.0.0
              </span>
            </div>
          </div>

          {/* 2. Dedication (Sadaqah Jariyah) - Elegant Card */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-800 text-white shadow-xl shadow-emerald-900/20 group">
             <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/arabesque.png')] opacity-10"></div>
             <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
             
             <div className="relative z-10 p-6 flex flex-col items-center text-center space-y-3">
                <div className="p-3 bg-white/10 rounded-full backdrop-blur-sm border border-white/20">
                  <Heart className="text-white fill-white/20 animate-pulse" size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">صدقة جارية</h3>
                  <p className="text-emerald-50 text-sm leading-relaxed max-w-sm mx-auto font-medium opacity-90">
                    هذا العمل وقف لله تعالى عن جميع أموات المسلمين.
                    <br />
                    <span className="block mt-2 font-bold bg-white/10 py-1 px-3 rounded-lg inline-block text-xs border border-white/10">
                      نسألكم الدعاء بالمغفرة والرحمة لوالدي
                    </span>
                  </p>
                </div>
             </div>
          </div>

          {/* 3. Features Grid - Bento Style */}
          <div>
            <div className="flex items-center gap-2 mb-4 px-2">
               <Layers size={18} className="text-gold-500" />
               <h3 className="text-sm font-bold text-navy-800 dark:text-white">مميزات التطبيق الشاملة</h3>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
               {/* Main Large Card */}
               <div className="col-span-2 bg-white dark:bg-navy-900 p-5 rounded-3xl border border-navy-100 dark:border-navy-800 shadow-sm flex items-center gap-4 hover:border-gold-400 dark:hover:border-gold-500/50 transition-colors cursor-pointer group" onClick={() => navigate('/reader')}>
                  <div className="w-14 h-14 bg-navy-50 dark:bg-navy-800 rounded-2xl flex items-center justify-center text-navy-600 dark:text-white group-hover:bg-gold-500 group-hover:text-navy-900 transition-colors">
                     <BookOpen size={28} />
                  </div>
                  <div>
                     <h4 className="font-bold text-navy-900 dark:text-white">المصحف الشريف</h4>
                     <p className="text-xs text-navy-500 dark:text-navy-400 mt-1">تلاوة، تفسير، بحث دقيق، وعلامات وقف</p>
                  </div>
                  <ChevronLeft className="mr-auto text-navy-300 group-hover:-translate-x-1 transition-transform" size={20} />
               </div>

               <FeatureCard 
                 icon={<Activity />} 
                 title="خطة الحفظ" 
                 desc="متابعة ذكية للورد اليومي" 
                 onClick={() => navigate('/hifz')}
                 color="text-blue-500"
                 bg="bg-blue-50 dark:bg-blue-900/20"
               />
               <FeatureCard 
                 icon={<Clock />} 
                 title="مواقيت الصلاة" 
                 desc="أذان وتنبيهات دقيقة" 
                 onClick={() => navigate('/?action=prayers')}
                 color="text-emerald-500"
                 bg="bg-emerald-50 dark:bg-emerald-900/20"
               />
               <FeatureCard 
                 icon={<Database />} 
                 title="الموسوعة الحديثية" 
                 desc="البخاري، مسلم، والنووي" 
                 onClick={() => navigate('/hadith')}
                 color="text-indigo-500"
                 bg="bg-indigo-50 dark:bg-indigo-900/20"
               />
               <FeatureCard 
                 icon={<Shield />} 
                 title="حصن المسلم" 
                 desc="أذكار الصباح والمساء" 
                 onClick={() => navigate('/adhkar')}
                 color="text-rose-500"
                 bg="bg-rose-50 dark:bg-rose-900/20"
               />
               <FeatureCard 
                 icon={<Radio />} 
                 title="الإذاعة المباشرة" 
                 desc="بث الحرمين والقراء" 
                 onClick={() => navigate('/radio')}
                 color="text-amber-500"
                 bg="bg-amber-50 dark:bg-amber-900/20"
               />
               <FeatureCard 
                 icon={<WifiOff />} 
                 title="بدون إنترنت" 
                 desc="تحميل وإدارة المحتوى" 
                 onClick={() => navigate('/downloads')}
                 color="text-slate-500"
                 bg="bg-slate-50 dark:bg-slate-800"
               />
            </div>
          </div>

          {/* 4. Developer Info & Contact */}
          <div className="bg-white dark:bg-navy-900 rounded-3xl p-6 shadow-sm border border-navy-100 dark:border-navy-800">
             <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-navy-900 dark:bg-white rounded-full flex items-center justify-center text-white dark:text-navy-900 shadow-md">
                   <Code size={20} />
                </div>
                <div>
                   <h3 className="font-bold text-navy-900 dark:text-white text-base">تطوير وبرمجة</h3>
                   <p className="text-gold-600 dark:text-gold-400 font-bold text-sm">م. أحمد محمد</p>
                </div>
             </div>
             
             <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={handleWhatsApp}
                  className="flex flex-col items-center justify-center gap-2 p-4 rounded-2xl bg-[#25D366]/5 hover:bg-[#25D366]/10 border border-[#25D366]/20 transition-colors group"
                >
                   <MessageCircle className="text-[#25D366] group-hover:scale-110 transition-transform" size={24} />
                   <span className="font-bold text-navy-800 dark:text-white text-xs">عبر واتساب</span>
                </button>

                <button 
                  onClick={handleEmail}
                  className="flex flex-col items-center justify-center gap-2 p-4 rounded-2xl bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/30 border border-blue-200 dark:border-blue-800 transition-colors group"
                >
                   <Mail className="text-blue-500 group-hover:scale-110 transition-transform" size={24} />
                   <span className="font-bold text-navy-800 dark:text-white text-xs">البريد الإلكتروني</span>
                </button>
             </div>
          </div>

          {/* Footer Rights */}
          <div className="text-center pb-8">
             <p className="text-[10px] text-navy-400 dark:text-navy-500 font-bold tracking-wider mb-2">
               اللهم اجعل هذا العمل خالصاً لوجهك الكريم
             </p>
             <p className="text-[10px] text-navy-300 dark:text-navy-600 font-sans">
                جميع الحقوق محفوظة © {new Date().getFullYear()} تطبيق البيان
             </p>
          </div>

        </div>
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, desc, onClick, color, bg }: { icon: React.ReactNode, title: string, desc: string, onClick: () => void, color: string, bg: string }) => (
  <button 
    onClick={onClick}
    className="bg-white dark:bg-navy-900 p-4 rounded-3xl border border-navy-50 dark:border-navy-800 flex flex-col items-start text-right shadow-sm hover:shadow-md hover:-translate-y-1 active:scale-95 transition-all duration-300 group h-full"
  >
     <div className={`p-3 rounded-2xl ${bg} ${color} mb-3 group-hover:scale-110 transition-transform`}>
        {React.cloneElement(icon as React.ReactElement, { size: 20 })}
     </div>
     <h4 className="font-bold text-navy-900 dark:text-white text-sm mb-1">{title}</h4>
     <p className="text-[10px] text-navy-500 dark:text-navy-400 leading-tight">{desc}</p>
  </button>
);
