
import React, { useState } from 'react';
import { TopBar } from '../components/TopBar';
import { TAFSIR_LIBRARY_DATA } from '../services/tafsirLibraryData';
import { Book, ChevronLeft, Info, Search, BookOpen, Library } from 'lucide-react';
import { toArabicDigits } from '../services/normalization';
import { TafsirBook, TafsirChapter } from '../types';

export const TafsirLibrary: React.FC = () => {
  const [selectedBook, setSelectedBook] = useState<TafsirBook | null>(null);
  const [selectedPartIndex, setSelectedPartIndex] = useState<number>(0);
  const [selectedChapter, setSelectedChapter] = useState<TafsirChapter | null>(null);

  if (selectedChapter && selectedBook) {
    return (
      <TafsirViewer 
        chapter={selectedChapter} 
        bookName={selectedBook.bookName}
        onBack={() => setSelectedChapter(null)} 
      />
    );
  }

  if (selectedBook) {
    return (
      <BookDetails 
        book={selectedBook} 
        onBack={() => setSelectedBook(null)}
        onSelectChapter={setSelectedChapter}
        partIndex={selectedPartIndex}
        setPartIndex={setSelectedPartIndex}
      />
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 font-sans">
      <TopBar title="المكتبة الإسلامية" />
      <div className="p-4 flex-1 overflow-y-auto pb-24">
        
        {/* Intro Banner */}
        <div className="mb-8 relative overflow-hidden rounded-3xl bg-[#1e293b] text-white p-6 shadow-xl">
           <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/20 rounded-full blur-3xl"></div>
           <div className="relative z-10 flex items-start gap-4">
             <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/10">
               <Library size={32} className="text-amber-400" />
             </div>
             <div>
               <h2 className="text-xl font-bold mb-2">أمهات كتب التفسير</h2>
               <p className="text-slate-300 text-sm leading-relaxed">
                 مجموعة مختارة من أهم كتب التفسير وعلوم القرآن الكريم، بتصميم مريح للقراءة والبحث.
               </p>
             </div>
           </div>
        </div>

        {/* Books Shelf Grid */}
        <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200 mb-4 px-1">الكتب المتاحة</h3>
        <div className="grid grid-cols-2 gap-4">
          {TAFSIR_LIBRARY_DATA.map((book) => (
            <div 
              key={book.bookNumber}
              onClick={() => { setSelectedBook(book); setSelectedPartIndex(0); }}
              className="bg-white dark:bg-[#0f172a] rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-800 hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer group flex flex-col items-center text-center relative overflow-hidden"
            >
              {/* Book Spine Graphic */}
              <div className="w-16 h-20 mb-4 bg-gradient-to-br from-amber-600 to-amber-800 rounded-r-md rounded-l-sm shadow-md flex items-center justify-center relative border-l-4 border-amber-900/30">
                 <div className="absolute right-2 top-0 bottom-0 w-[1px] bg-white/20"></div>
                 <BookOpen size={24} className="text-white/90" />
              </div>
              
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 line-clamp-1 mb-1 group-hover:text-amber-600 transition-colors">
                {book.bookName}
              </h3>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded-full font-bold">
                 {toArabicDigits(book.parts_count)} مجلدات
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const BookDetails: React.FC<{ 
  book: TafsirBook; 
  onBack: () => void; 
  onSelectChapter: (ch: TafsirChapter) => void;
  partIndex: number;
  setPartIndex: (i: number) => void;
}> = ({ book, onBack, onSelectChapter, partIndex, setPartIndex }) => {
  const [search, setSearch] = useState('');
  
  const currentPart = book.parts[partIndex];
  const chapters = currentPart ? currentPart.Chapter_names : [];
  const filteredChapters = chapters.filter(c => c.Chapter_name.includes(search));

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 font-sans">
      <TopBar 
        title={book.bookName} 
        extra={
          <button onClick={onBack} className="p-2 -mr-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <ChevronLeft size={20} className="rotate-180" />
          </button>
        }
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Book Info Card */}
        <div className="p-6 bg-white dark:bg-[#0f172a] border-b border-slate-100 dark:border-slate-800">
           <div className="flex items-start gap-4">
              <div className="w-16 h-20 shrink-0 bg-gradient-to-br from-amber-600 to-amber-800 rounded-lg shadow-lg flex items-center justify-center text-white">
                 <BookOpen size={28} />
              </div>
              <div>
                <h2 className="font-bold text-slate-900 dark:text-white text-lg mb-1">{book.bookFullName}</h2>
                <div className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
                  {book.aboutBook.length > 100 ? book.aboutBook.substring(0, 100) + '...' : book.aboutBook}
                </div>
              </div>
           </div>
        </div>

        {/* Part Selector */}
        {book.parts_count > 1 && (
          <div className="bg-white dark:bg-[#0f172a] border-b border-slate-100 dark:border-slate-800 pb-2 px-4">
            <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
              {book.parts.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => setPartIndex(idx)}
                  className={`flex-shrink-0 px-5 py-2 rounded-xl text-xs font-bold transition-all border ${
                    idx === partIndex
                      ? 'bg-amber-600 text-white border-amber-600 shadow-md'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  الجزء {toArabicDigits(parseInt(p.parts_number))}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Search */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950">
           <div className="relative">
             <input 
               type="text" 
               placeholder="ابحث في فصول الكتاب..." 
               className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500 outline-none shadow-sm"
               value={search}
               onChange={(e) => setSearch(e.target.value)}
             />
             <Search size={18} className="absolute left-3 top-4 text-slate-400" />
           </div>
        </div>

        {/* Chapters List */}
        <div className="flex-1 overflow-y-auto px-4 pb-20 space-y-2">
           {filteredChapters.length > 0 ? (
             filteredChapters.map((ch, idx) => (
               <button
                 key={idx}
                 onClick={() => onSelectChapter(ch)}
                 className="w-full flex items-center gap-4 p-4 bg-white dark:bg-[#0f172a] border border-slate-100 dark:border-slate-800 rounded-2xl hover:border-amber-400 transition-colors text-right group shadow-sm"
               >
                 <span className="w-8 h-8 flex shrink-0 items-center justify-center bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-500 rounded-lg text-xs font-bold font-sans">
                   {toArabicDigits(ch.Chapter_number)}
                 </span>
                 <span className="text-sm font-bold text-slate-700 dark:text-slate-200 flex-1 leading-relaxed">
                   {ch.Chapter_name}
                 </span>
                 <ChevronLeft size={16} className="text-slate-300 group-hover:text-amber-500 transition-colors" />
               </button>
             ))
           ) : (
             <div className="text-center py-20 text-slate-400 text-sm flex flex-col items-center gap-3">
               <Info size={40} className="opacity-20" />
               <p>لا توجد فصول مطابقة للبحث</p>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

const TafsirViewer: React.FC<{ chapter: TafsirChapter; bookName: string; onBack: () => void }> = ({ chapter, bookName, onBack }) => {
  return (
    <div className="flex flex-col h-full bg-[#fffcf5] dark:bg-[#0f172a]">
      <TopBar 
        title={bookName} 
        extra={
          <button onClick={onBack} className="p-2 -mr-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <ChevronLeft size={20} className="rotate-180" />
          </button>
        }
      />
      <div className="flex-1 overflow-y-auto p-6 md:p-12 relative">
         <div className="max-w-3xl mx-auto relative z-10">
           
           <div className="mb-8 text-center border-b-2 border-amber-900/10 dark:border-amber-500/20 pb-6">
             <h2 className="text-2xl font-bold text-slate-800 dark:text-amber-50 leading-relaxed font-quran">
               {chapter.Chapter_name}
             </h2>
           </div>
           
           <div className="prose dark:prose-invert max-w-none">
             <p className="text-lg leading-[2.4] text-justify text-slate-800 dark:text-slate-200 font-serif">
               {/* Content Placeholder */}
               <span className="block p-8 bg-amber-50 dark:bg-slate-900 rounded-2xl border border-dashed border-amber-200 dark:border-slate-700 text-center text-slate-500 dark:text-slate-400 text-sm">
                 محتوى هذا الفصل غير متوفر في البيانات الحالية.
                 <br />
                 (سيتم إضافة النصوص الكاملة في التحديث القادم)
               </span>
             </p>
           </div>
         </div>
      </div>
    </div>
  );
};
