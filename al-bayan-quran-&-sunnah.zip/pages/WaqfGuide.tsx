
import React from 'react';
import { TopBar } from '../components/TopBar';
import { Info, BookOpen, PauseCircle, AlertTriangle, CheckCircle, XCircle, ArrowRightCircle } from 'lucide-react';

export const WaqfGuide: React.FC = () => {
  const signs = [
    {
      symbol: 'مـ',
      name: 'الوقف اللازم',
      meaning: 'يلزم الوقف عنده، والوصل يغير المعنى ويفسده.',
      example: 'إِنَّمَا يَسْتَجِيبُ الَّذِينَ يَسْمَعُونَ ۘ وَالْمَوْتَىٰ يَبْعَثُهُمُ اللَّهُ',
      icon: <AlertTriangle size={20} />,
      colorClass: 'from-red-500 to-red-600',
      bgClass: 'bg-red-50 dark:bg-red-900/10',
      borderClass: 'border-red-200 dark:border-red-800'
    },
    {
      symbol: 'لا',
      name: 'الوقف الممنوع',
      meaning: 'يمنع الوقف عنده لأنه لا يفيد معنى تاماً بمفرده.',
      example: 'الَّذِينَ تَتَوَفَّاهُمُ الْمَلَائِكَةُ طَيِّبِينَ ۙ يَقُولُونَ سَلَامٌ عَلَيْكُمُ',
      icon: <XCircle size={20} />,
      colorClass: 'from-slate-600 to-slate-700',
      bgClass: 'bg-slate-50 dark:bg-slate-800/50',
      borderClass: 'border-slate-200 dark:border-slate-700'
    },
    {
      symbol: 'ج',
      name: 'الوقف الجائز',
      meaning: 'يجوز الوقف ويجوز الوصل، وكلاهما سواء في المعنى.',
      example: 'نَحْنُ نَقُصُّ عَلَيْكَ نَبَأَهُم بِالْحَقِّ ۚ إِنَّهُمْ فِتْيَةٌ آمَنُوا',
      icon: <CheckCircle size={20} />,
      colorClass: 'from-emerald-500 to-emerald-600',
      bgClass: 'bg-emerald-50 dark:bg-emerald-900/10',
      borderClass: 'border-emerald-200 dark:border-emerald-800'
    },
    {
      symbol: 'صلے',
      name: 'الوصل أولى',
      meaning: 'يجوز الوقف، ولكن الوصل أفضل لإتمام المعنى وتصله بما بعده.',
      example: 'وَإِن يَمْسَسْكَ اللَّهُ بِضُرٍّ فَلَا كَاشِفَ لَهُ إِلَّا هُوَ ۖ وَإِن يَمْسَسْكَ بِخَيْرٍ',
      icon: <ArrowRightCircle size={20} />,
      colorClass: 'from-amber-500 to-amber-600',
      bgClass: 'bg-amber-50 dark:bg-amber-900/10',
      borderClass: 'border-amber-200 dark:border-amber-800'
    },
    {
      symbol: 'قلي',
      name: 'الوقف أولى',
      meaning: 'يجوز الوصل، ولكن الوقف أفضل وأتم للمعنى.',
      example: 'قُل رَّبِّي أَعْلَمُ بِعِدَّتِهِم مَّا يَعْلَمُهُمْ إِلَّا قَلِيلٌ ۗ فَلَا تُمَارِ فِيهِمْ',
      icon: <PauseCircle size={20} />,
      colorClass: 'from-blue-500 to-blue-600',
      bgClass: 'bg-blue-50 dark:bg-blue-900/10',
      borderClass: 'border-blue-200 dark:border-blue-800'
    },
    {
      symbol: '∴',
      name: 'وقف التعانق',
      meaning: 'إذا وقفت على أحد الموضعين لا يصح الوقف على الآخر.',
      example: 'ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ',
      icon: <Info size={20} />,
      colorClass: 'from-indigo-500 to-indigo-600',
      bgClass: 'bg-indigo-50 dark:bg-indigo-900/10',
      borderClass: 'border-indigo-200 dark:border-indigo-800'
    }
  ];

  return (
    <div className="flex flex-col h-full bg-gold-50 dark:bg-navy-950 font-sans">
      <TopBar title="علامات الوقف" showBack />
      
      <div className="flex-1 overflow-y-auto p-4 md:p-6 pb-24 custom-scrollbar">
        <div className="max-w-3xl mx-auto">
          
          {/* Header Description */}
          <div className="mb-8 text-center space-y-2">
             <div className="w-16 h-16 bg-navy-900 dark:bg-white rounded-2xl flex items-center justify-center text-white dark:text-navy-900 shadow-xl mx-auto transform rotate-3 mb-4">
                <BookOpen size={32} />
             </div>
             <h2 className="text-2xl font-bold text-navy-900 dark:text-white">دليل علامات الوقف</h2>
             <p className="text-navy-600 dark:text-navy-300 text-sm max-w-sm mx-auto leading-relaxed">
               الرموز الموجودة في المصحف الشريف لتوجيه القارئ إلى مواضع الوقف والوصل الصحيحة لإتمام المعنى.
             </p>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            {signs.map((sign, idx) => (
              <div 
                key={idx} 
                className={`relative overflow-hidden rounded-3xl p-6 border transition-all hover:shadow-lg hover:-translate-y-1 group ${sign.bgClass} ${sign.borderClass}`}
              >
                {/* Symbol Circle */}
                <div className="flex items-start justify-between mb-4 relative z-10">
                   <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-quran font-bold text-white shadow-lg bg-gradient-to-br ${sign.colorClass}`}>
                     {sign.symbol}
                   </div>
                   <div className={`p-2 rounded-full bg-white/50 dark:bg-black/20 ${sign.colorClass.split(' ')[1].replace('to-', 'text-')}`}>
                      {sign.icon}
                   </div>
                </div>
                
                {/* Content */}
                <div className="relative z-10">
                  <h3 className="text-lg font-bold text-navy-900 dark:text-white mb-2 group-hover:text-gold-600 dark:group-hover:text-gold-400 transition-colors">
                    {sign.name}
                  </h3>
                  <p className="text-sm text-navy-700 dark:text-navy-200 mb-4 leading-relaxed font-medium min-h-[40px]">
                    {sign.meaning}
                  </p>
                  
                  {/* Example Box */}
                  <div className="bg-white/80 dark:bg-navy-950/60 p-3 rounded-xl border border-navy-100 dark:border-navy-800 backdrop-blur-sm">
                    <p className="text-[10px] text-navy-400 dark:text-navy-500 font-bold mb-1 uppercase tracking-wider">مثال توضيحي</p>
                    <p className="font-quran text-lg text-navy-800 dark:text-gray-100 leading-loose text-center">
                      {sign.example}
                    </p>
                  </div>
                </div>

                {/* Decorative Background Fade */}
                <div className={`absolute -top-10 -left-10 w-32 h-32 rounded-full opacity-10 bg-gradient-to-br ${sign.colorClass} blur-2xl`}></div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </div>
  );
};
