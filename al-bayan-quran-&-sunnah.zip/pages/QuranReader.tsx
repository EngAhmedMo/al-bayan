
import React, { useEffect, useState, useRef, useContext } from 'react';
import { useSearchParams, useLocation } from 'react-router-dom';
import { Ayah, Surah, TafsirResponse } from '../types';
import { fetchPage, fetchTafsir, fetchSurahs, RECITERS, getAudioUrl } from '../services/api';
import { toArabicDigits } from '../services/normalization';
import { SURAH_START_PAGES, SURAH_AYAH_COUNTS, getGlobalAyahNumber, getApproxPageFromGlobalAyah } from '../services/quranStaticData';
import { TopBar } from '../components/TopBar';
import { useAudio, useSettings, NavigationContext, useTheme } from '../components/Layout';
import { ChevronLeft, ChevronRight, PlayCircle, BookOpen, X, Copy, Bookmark, BookmarkPlus, BookmarkCheck, Settings, Type, Mic, FileEdit, Save, Maximize2, Minimize2, Share2, Grid, Book, Hash, Repeat, Play, Infinity as InfinityIcon, LogOut, Plus, Minus, Sun, Moon } from 'lucide-react';
import { 
  toggleAyahBookmark, 
  isAyahBookmarked, 
  addPageBookmark, 
  removePageBookmark, 
  isPageBookmarked, 
  saveNote, 
  getNoteForAyah,
  setLastUsedCategory 
} from '../services/storage';
import { AnalyticsService } from '../services/analytics'; // Analytics

export const QuranReader: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const location = useLocation();
  const { setIsFullscreen } = useContext(NavigationContext);
  const { isDark, toggleTheme } = useTheme();
  
  // -- Smart Logic: Session Context --
  // FIXED: Only consider it "Auxiliary" (Temporary) if there is a HIGHLIGHT param (Search Result).
  // If it's just a Surah navigation from sidebar, we consider it a read session and want to save it.
  const isAuxiliarySession = useRef<boolean>(!!searchParams.get('highlight'));

  // -- Entry Logic (Case A/B) --
  const [page, setPage] = useState<number>(() => {
    const urlPage = searchParams.get('page');
    if (urlPage) return parseInt(urlPage);
    
    // If no specific page/surah in URL, try to load last read
    if (!searchParams.get('surah') && !searchParams.get('highlight')) {
       const saved = localStorage.getItem('lastRead');
       if (saved) {
         try { return JSON.parse(saved).page; } catch(e) {}
       }
    }
    return 1;
  });

  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [loading, setLoading] = useState(false);
  const [isImmersive, setIsImmersive] = useState(false);
  const [allSurahs, setAllSurahs] = useState<Surah[]>([]);
  
  // Interactive State
  const [selectedAyah, setSelectedAyah] = useState<Ayah | null>(null);
  const [tafsirData, setTafsirData] = useState<TafsirResponse | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tafsirLoading, setTafsirLoading] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isNavOpen, setIsNavOpen] = useState(false); // Navigation Modal State
  const [navTab, setNavTab] = useState<'surahs' | 'pages'>('surahs');
  
  // Global Settings
  const { fontSize, setFontSize, reciterId, setReciterId } = useSettings();

  // Bookmark & Notes
  const [isAyahSaved, setIsAyahSaved] = useState(false);
  const [isPageSaved, setIsPageSaved] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [showNoteInput, setShowNoteInput] = useState(false);

  const { playTrack, currentTrack, isPlaying } = useAudio();
  const pageTopRef = useRef<HTMLDivElement>(null);

  // Common button class for header consistency
  const headerBtnClass = "w-10 h-10 flex items-center justify-center rounded-xl bg-white/80 dark:bg-navy-800/80 backdrop-blur-sm border border-navy-100 dark:border-navy-700 text-navy-600 dark:text-navy-300 hover:border-gold-400 dark:hover:border-gold-500 hover:text-gold-600 dark:hover:text-gold-400 hover:bg-white dark:hover:bg-navy-800 shadow-sm hover:shadow-md transition-all duration-200 active:scale-95";

  // Fetch Surahs for Nav Modal
  useEffect(() => {
    fetchSurahs().then(setAllSurahs);
  }, []);

  // -- Fullscreen Back Button Logic & Global Context Sync --
  useEffect(() => {
    setIsFullscreen(isImmersive); // Sync Global State for Sidebar Hiding

    if (isImmersive) {
      // Push state when entering immersive
      window.history.pushState({ immersive: true }, '');
      
      const handlePopState = () => {
        setIsImmersive(false);
      };

      window.addEventListener('popstate', handlePopState);
      return () => {
        window.removeEventListener('popstate', handlePopState);
        setIsFullscreen(false); // Ensure cleanup on unmount
      };
    }
  }, [isImmersive]);

  // -- AUDIO SYNC LOGIC (FOLLOW-ALONG) --
  useEffect(() => {
    if (currentTrack && currentTrack.globalAyahNumber) {
        // 1. SMART SELECTION CLEARING
        setSelectedAyah(null);

        if (isPlaying) {
            // Calculate which page this ayah belongs to
            const pageOfTrack = getApproxPageFromGlobalAyah(currentTrack.globalAyahNumber);
            
            // If the audio has moved to a new page, auto-navigate
            if (pageOfTrack !== page) {
                setPage(pageOfTrack);
            }

            // Auto-scroll to the highlighted ayah if it's on the current page
            // Wait briefly for DOM render
            setTimeout(() => {
                const el = document.getElementById(`ayah-${currentTrack.globalAyahNumber}`);
                if (el) {
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }, 100);
        }
    }
  }, [currentTrack?.globalAyahNumber, isPlaying]);

  // -- Smart Logic: Mode Switching & Return to Base --
  useEffect(() => {
    // If we simply navigated to /reader without params, we are in "Resume" mode
    if (location.pathname === '/reader' && location.search === '') {
        isAuxiliarySession.current = false;
        const saved = localStorage.getItem('lastRead');
        if (saved) {
            try {
                const savedPage = JSON.parse(saved).page;
                if (savedPage !== page) setPage(savedPage);
            } catch(e) {}
        }
    } 
    // If there is a highlight param, it's a search result (Auxiliary)
    else if (searchParams.get('highlight')) {
        isAuxiliarySession.current = true;
    }
    // If there is only a Surah param (Sidebar Nav), it is NOT auxiliary, we want to save.
    else if (searchParams.get('surah')) {
        isAuxiliarySession.current = false;
    }
  }, [location, searchParams]);

  // -- Smart Logic: Silent Reading Session --
  useEffect(() => {
    const startTime = Date.now();
    return () => {
      const sessionDurationSeconds = (Date.now() - startTime) / 1000;
      if (sessionDurationSeconds > 45) {
        setLastUsedCategory("الاستغفار و التوبة");
        
        // Log deep reading session to Analytics
        AnalyticsService.logEvent('deep_reading_session', {
            duration_seconds: sessionDurationSeconds,
            page_number: page
        });
      }
    };
  }, [page]); // Re-run when page changes to track per page

  // -- Deep Linking & Navigation Logic --
  useEffect(() => {
    const surahParam = searchParams.get('surah');
    const ayahParam = searchParams.get('ayah') || '1';
    const pageParam = searchParams.get('page');
    const highlightParam = searchParams.get('highlight');

    // Case: Navigating via Surah (Sidebar or List)
    if (surahParam && !pageParam) {
      setLoading(true);
      
      // If no highlight is present, this is a direct navigation intended to read.
      // So we mark it as NOT auxiliary to enable saving.
      if (!highlightParam) {
          isAuxiliarySession.current = false;
      }

      fetch(`https://api.alquran.cloud/v1/ayah/${surahParam}:${ayahParam}`)
        .then(res => res.json())
        .then(data => {
          if (data.code === 200 && data.data && data.data.page) {
            const targetPage = data.data.page;
            setPage(targetPage);
            setSearchParams(prev => {
                const newP = new URLSearchParams(prev);
                newP.set('page', targetPage.toString());
                if (highlightParam) {
                    newP.set('highlight', `${surahParam}:${ayahParam}`);
                } else {
                    // Clean URL if just surfing
                    newP.delete('surah');
                    newP.delete('ayah');
                }
                return newP;
            }, { replace: true });
          }
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
    // Case: Navigating via Page Number directly
    else if (pageParam) {
      const p = parseInt(pageParam);
      if (p !== page) setPage(p);
    }
  }, [searchParams, setSearchParams]);

  // -- Page Content Loading & Auto-Save --
  useEffect(() => {
    const loadPage = async () => {
      setLoading(true);
      const data = await fetchPage(page, reciterId);
      setAyahs(data);
      setLoading(false);
      setIsPageSaved(isPageBookmarked(page));

      if (data.length > 0) {
        const firstAyah = data[0];
        const sName = (firstAyah as any).surah?.name || "القرآن";
        
        // Log Page View to Analytics
        AnalyticsService.logEvent('view_quran_page', {
            page_number: page,
            surah_name: sName
        });

        // FIXED: Save 'lastRead' if not in auxiliary (search highlight) mode
        // Or if the user has started navigating (next/prev) which clears auxiliary flag
        if (!isAuxiliarySession.current) {
            localStorage.setItem('lastRead', JSON.stringify({ surah: sName, page: page }));
        }
      }
      
      const highlight = searchParams.get('highlight');
      if (highlight && data.length > 0) {
         setTimeout(() => {
           const el = document.getElementById(`ayah-${highlight}`);
           if (el) {
             el.scrollIntoView({ behavior: 'smooth', block: 'center' });
             el.classList.add('highlight-flash');
             setTimeout(() => el.classList.remove('highlight-flash'), 2000);
           }
         }, 600);
      } else {
         if(pageTopRef.current) pageTopRef.current.scrollTop = 0;
         if(!isImmersive) window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    
    loadPage();
    
    const currentUrlPage = searchParams.get('page');
    if (page.toString() !== currentUrlPage) {
        setSearchParams(prev => {
            const newP = new URLSearchParams(prev);
            newP.set('page', page.toString());
            // If user turns page, we remove highlight/deep link params 
            // and assume they are now in "Reading Mode", so we clear the params
            if (!isAuxiliarySession.current) {
                newP.delete('highlight');
                newP.delete('surah');
                newP.delete('ayah');
            }
            return newP;
        }, { replace: true });
    }
  }, [page, reciterId]);

  // ... (Rest of the component logic remains identical, omitting for brevity) ...
  // -- Handlers --

  const handleNext = () => { 
      // If user clicks Next, they are reading. Save state from now on.
      isAuxiliarySession.current = false; 
      if(page < 604) setPage(p => p + 1); 
  };
  const handlePrev = () => { 
      // If user clicks Prev, they are reading. Save state from now on.
      isAuxiliarySession.current = false;
      if(page > 1) setPage(p => p - 1); 
  };

  const onAyahClick = (ayah: Ayah) => {
    setSelectedAyah(ayah);
    const sNum = (ayah as any).surah?.number;
    if (sNum) {
      setIsAyahSaved(isAyahBookmarked(sNum, ayah.numberInSurah));
      const existingNote = getNoteForAyah(sNum, ayah.numberInSurah);
      setNoteText(existingNote || '');
    }
    setShowNoteInput(false);
    setIsModalOpen(true);
    setTafsirData(null);
  };

  const playFromHere = (autoAdvance: boolean, repeatCount: number = 0) => {
    if (selectedAyah) {
        const globalId = selectedAyah.number;
        const audioUrl = getAudioUrl(reciterId, globalId);

        // Log Audio Play
        AnalyticsService.logEvent('play_ayah', {
            surah_number: (selectedAyah as any).surah?.number,
            ayah_number: selectedAyah.numberInSurah,
            reciter_id: reciterId
        });

        playTrack(
            audioUrl, 
            (selectedAyah as any).surah?.name, 
            `الآية ${toArabicDigits(selectedAyah.numberInSurah)}`,
            globalId,
            autoAdvance,
            repeatCount,
            reciterId
        );
        setIsModalOpen(false);
        setSelectedAyah(null); 
    }
  };

  const playFullSurah = (surahNumber: number, surahName: string) => {
    let startGlobalId = 1;
    for (let i = 1; i < surahNumber; i++) {
        startGlobalId += SURAH_AYAH_COUNTS[i] || 0;
    }
    const url = getAudioUrl(reciterId, startGlobalId);
    
    AnalyticsService.logEvent('play_full_surah', {
        surah_number: surahNumber,
        reciter_id: reciterId
    });

    playTrack(url, surahName, `الآية ${toArabicDigits(1)}`, startGlobalId, true, 0, reciterId);
    setSelectedAyah(null);
  };

  const isHighlighted = (ayah: Ayah) => {
      const sNum = (ayah as any).surah?.number;
      const globalId = getGlobalAyahNumber(sNum, ayah.numberInSurah);
      if (currentTrack?.globalAyahNumber === globalId) return true;
      const highlight = searchParams.get('highlight');
      if (!highlight) return false;
      return highlight === `${sNum}:${ayah.numberInSurah}`;
  };

  const getSurahNameForPage = () => {
      if (ayahs.length === 0) return 'المصحف';
      const newSurah = ayahs.find(a => a.numberInSurah === 1);
      return (newSurah ? (newSurah as any).surah.name : (ayahs[0] as any).surah.name);
  };

  const navigateToSurah = (surahNum: number) => {
    const startPage = SURAH_START_PAGES[surahNum];
    if (startPage) {
      setPage(startPage);
      // Ensure we treat this as a reading session
      isAuxiliarySession.current = false;
      setIsNavOpen(false);
    }
  };

  const navigateToPage = (pageNum: number) => {
    if (pageNum >= 1 && pageNum <= 604) {
      setPage(pageNum);
      // Ensure we treat this as a reading session
      isAuxiliarySession.current = false;
      setIsNavOpen(false);
    }
  };

  return (
    <div className={`flex flex-col h-full bg-gold-50 dark:bg-navy-950 relative overflow-hidden transition-colors duration-500`}>
      
      {/* 1. Header (Collapsible) - Hidden in Immersive */}
      <div className={`transition-all duration-500 ease-in-out z-40 ${isImmersive ? '-mt-20 opacity-0 pointer-events-none' : 'opacity-100'}`}>
        <TopBar 
          title={`ص ${toArabicDigits(page)} - ${getSurahNameForPage()}`} 
          extra={
            <div className="flex items-center gap-1.5">
              <button onClick={() => setIsImmersive(!isImmersive)} className={headerBtnClass} title="ملء الشاشة">
                 {isImmersive ? <Minimize2 size={20} /> : <Maximize2 size={20} />}
              </button>
              <button onClick={() => setIsSettingsOpen(true)} className={headerBtnClass} title="الإعدادات">
                <Settings size={20} />
              </button>
              <button 
                onClick={() => {
                   if(isPageSaved) removePageBookmark(page); else addPageBookmark(getSurahNameForPage(), page);
                   setIsPageSaved(!isPageSaved);
                }}
                className={`${headerBtnClass} ${isPageSaved ? '!text-red-500 !border-red-200 dark:!border-red-900 bg-red-50 dark:bg-red-900/10' : ''}`}
                title={isPageSaved ? "إزالة الفاصل" : "حفظ الصفحة"}
              >
                {isPageSaved ? <BookmarkCheck size={20} /> : <BookmarkPlus size={20} />}
              </button>
            </div>
          }
        />
      </div>

      {/* 2. Main Content (The Page) */}
      <div 
        ref={pageTopRef}
        className={`
          flex-1 overflow-y-auto overflow-x-hidden flex justify-center relative transition-all duration-500 custom-scrollbar scroll-smooth
          ${isImmersive 
             ? 'fixed inset-0 z-50 bg-[#1a202c]/95 backdrop-blur-xl h-screen w-screen p-0' 
             : 'p-2 sm:p-4 pb-40'}
        `}
        onClick={(e) => { 
           // Clicking the "void" area exits immersive mode
           if(isImmersive && e.target === pageTopRef.current) setIsImmersive(false); 
        }}
      >
        {/* Top Left Floating Controls (Font & Theme) - Only in Immersive Mode */}
        {isImmersive && (
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="fixed top-6 left-6 z-[60] flex flex-col gap-3 animate-in fade-in slide-in-from-top-4"
          >
             {/* Font Controls */}
             <div className="flex flex-col bg-navy-900/80 dark:bg-black/50 backdrop-blur-md rounded-2xl p-1.5 border border-white/10 shadow-lg">
                <button 
                  onClick={() => setFontSize(Math.min(fontSize + 2, 50))}
                  className="w-10 h-10 flex items-center justify-center text-white hover:bg-white/10 rounded-xl transition-colors"
                  title="تكبير الخط"
                >
                  <Plus size={20} />
                </button>
                <div className="h-px bg-white/10 w-full my-1"></div>
                <button 
                  onClick={() => setFontSize(Math.max(fontSize - 2, 18))}
                  className="w-10 h-10 flex items-center justify-center text-white hover:bg-white/10 rounded-xl transition-colors"
                  title="تصغير الخط"
                >
                  <Minus size={20} />
                </button>
             </div>

             {/* Theme Toggle */}
             <button 
               onClick={toggleTheme}
               className="w-14 h-14 rounded-full bg-navy-900/80 dark:bg-gold-500/80 backdrop-blur-md flex items-center justify-center text-gold-500 dark:text-navy-900 shadow-lg border border-white/10 hover:scale-110 transition-transform"
               title={isDark ? "الوضع النهاري" : "الوضع الليلي"}
             >
                {isDark ? <Sun size={24} fill="currentColor" /> : <Moon size={24} />}
             </button>
          </div>
        )}

        {/* Professional Floating Exit Button for Immersive Mode (Bottom Left) */}
        {isImmersive && (
          <button 
            onClick={(e) => { e.stopPropagation(); setIsImmersive(false); }}
            className="fixed bottom-8 left-8 z-[60] group flex items-center justify-center gap-0 hover:gap-3 bg-navy-900/90 text-white dark:bg-gold-500/90 dark:text-navy-900 shadow-[0_10px_30px_rgba(0,0,0,0.3)] backdrop-blur-md rounded-full w-14 h-14 hover:w-32 transition-all duration-300 ease-out overflow-hidden border border-white/10 hover:border-gold-500"
            title="خروج من وضع القراءة"
          >
            <Minimize2 size={24} className="shrink-0" />
            <span className="max-w-0 group-hover:max-w-xs opacity-0 group-hover:opacity-100 whitespace-nowrap font-bold text-sm transition-all duration-300">
              خروج
            </span>
          </button>
        )}

        {loading ? (
          <div className="w-full max-w-4xl mx-auto h-[80vh] flex flex-col items-center justify-center space-y-6 animate-pulse">
             <div className="w-3/4 h-8 bg-gold-200 dark:bg-navy-800 rounded-lg"></div>
             <div className="w-full h-full bg-white dark:bg-navy-900 rounded-2xl shadow-sm border border-gold-100 dark:border-navy-800 opacity-60"></div>
          </div>
        ) : (
          <div 
            className={`
              transition-all duration-500 mx-auto
              ${isImmersive 
                 ? 'w-full md:w-[90%] lg:w-[80%] max-w-[1000px] min-h-full py-0 md:py-8' 
                 : 'w-full max-w-4xl'} 
            `}
          >
             
             {/* Mushaf Paper Container */}
             <div className={`
                relative bg-[#fffcf5] dark:bg-[#1a202c] shadow-2xl overflow-hidden min-h-[85vh] transition-all duration-500
                ${isImmersive 
                   ? 'min-h-full md:min-h-[calc(100vh-4rem)] md:rounded-2xl border-none md:border border-white/5 shadow-2xl' 
                   : 'rounded-2xl border border-gold-900/5 dark:border-navy-700'}
             `}>
                
                {/* Paper Texture Overlay */}
                <div className="absolute inset-0 pointer-events-none z-0 bg-gradient-to-r from-black/5 via-transparent to-black/5 dark:from-black/40 dark:via-transparent dark:to-black/40"></div>

                {/* Decorative Frame - Only shown in Normal Mode */}
                {!isImmersive && (
                  <div className="absolute inset-0 pointer-events-none p-2 sm:p-4 z-0">
                    <div className="w-full h-full border-2 border-gold-600/20 dark:border-gold-500/10 rounded-lg"></div>
                    <div className="absolute inset-3 sm:inset-5 border border-gold-600/10 dark:border-gold-500/5 rounded-md"></div>
                    <CornerDecoration className="top-2 right-2" />
                    <CornerDecoration className="top-2 left-2 -scale-x-100" />
                    <CornerDecoration className="bottom-2 right-2 -scale-y-100" />
                    <CornerDecoration className="bottom-2 left-2 -scale-x-100 -scale-y-100" />
                  </div>
                )}

                {/* Page Content - Adaptive Padding for Orientation */}
                <div className={`
                   relative z-10 flex flex-col items-center w-full
                   ${isImmersive 
                      ? 'px-4 py-12 pb-32 sm:px-12 md:px-16 lg:px-20' 
                      : 'px-4 sm:px-10 py-10 sm:py-14'}
                `}>
                    
                    {/* Ribbon */}
                    {isPageSaved && !isImmersive && (
                      <div className="absolute -top-1 left-8 w-6 h-12 bg-red-700 shadow-md z-20 animate-in fade-in slide-in-from-top-4">
                        <div className="absolute bottom-0 left-0 w-0 h-0 border-l-[12px] border-r-[12px] border-t-[8px] border-l-transparent border-r-transparent border-t-red-700 transform rotate-180 translate-y-full"></div>
                      </div>
                    )}

                    {/* Surah Headers */}
                    {ayahs.map((ayah, idx) => {
                      if (ayah.numberInSurah === 1) {
                         const surah = (ayah as any).surah;
                         return (
                            <div key={`head-${idx}`} className="w-full mt-2 mb-6 text-center">
                               <div className="relative flex items-center justify-center py-3 my-4">
                                  <div className="absolute inset-x-0 h-10 bg-[url('https://www.transparenttextures.com/patterns/arabesque.png')] opacity-10 dark:opacity-5 bg-gold-600"></div>
                                  <div className="absolute inset-x-10 top-1/2 h-[2px] bg-gradient-to-r from-transparent via-gold-400 to-transparent"></div>
                                  
                                  <div className="relative z-10 bg-[#fffcf5] dark:bg-[#1a202c] px-6 py-1 border border-gold-500/30 rounded-full shadow-sm flex items-center gap-3">
                                     <h2 className="font-quran text-2xl text-navy-900 dark:text-gold-100">
                                        {surah.name}
                                     </h2>
                                     <button 
                                       onClick={() => playFullSurah(surah.number, surah.name)}
                                       className="p-1.5 bg-gold-500 text-white rounded-full hover:bg-gold-600 transition-colors shadow-sm"
                                       title="تشغيل السورة كاملة"
                                     >
                                       <Play size={14} fill="currentColor" />
                                     </button>
                                  </div>
                                </div>
                               
                               {surah.number !== 1 && surah.number !== 9 && (
                                 <div className="font-quran text-2xl text-navy-800 dark:text-navy-200 mb-6 mt-2 opacity-90">
                                   بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
                                 </div>
                               )}
                            </div>
                         )
                      }
                      return null;
                    })}

                    {/* TEXT BLOCK */}
                    <div 
                      className="font-quran text-justify text-navy-950 dark:text-gray-200 leading-[3] w-full"
                      style={{ 
                        textAlignLast: 'center', 
                        fontSize: `${fontSize}px`,
                        fontFeatureSettings: '"cv01" on, "cv02" on' // Ligatures
                      }} 
                      dir="rtl"
                    >
                      {ayahs.map((ayah) => {
                        let displayText = ayah.text;
                        if (ayah.numberInSurah === 1 && ayah.number !== 1) { 
                           displayText = displayText.replace('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', '').trim();
                        }
                        const isMarked = isAyahBookmarked((ayah as any).surah?.number, ayah.numberInSurah);
                        const highlighted = isHighlighted(ayah);
                        const globalId = getGlobalAyahNumber((ayah as any).surah?.number, ayah.numberInSurah);
                        const isSelected = selectedAyah?.number === ayah.number;

                        return (
                          <React.Fragment key={ayah.number}>
                            <span 
                              id={`ayah-${globalId}`}
                              onClick={() => onAyahClick(ayah)}
                              className={`
                                relative rounded px-0.5 cursor-pointer decoration-clone transition-all duration-300
                                hover:bg-gold-100 dark:hover:bg-navy-800
                                ${isSelected ? 'bg-gold-200/50 dark:bg-gold-900/30' : ''}
                                ${highlighted 
                                    ? 'bg-gold-300/80 dark:bg-gold-600/60 shadow-sm text-navy-950 dark:text-white font-bold scale-[1.02] inline-block px-1' 
                                    : ''}
                                ${isMarked ? 'underline decoration-red-400 decoration-2 underline-offset-8' : ''}
                              `}
                            >
                              {displayText}
                            </span>
                            <span className="inline-flex items-center justify-center mx-1 align-middle select-none text-gold-600 dark:text-gold-500 font-sans font-bold h-[1em] w-[1em] relative"
                                  style={{ fontSize: `${fontSize * 0.9}px` }}>
                               <span className="absolute inset-0 opacity-100">
                                 <svg viewBox="0 0 36 36" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-full h-full drop-shadow-sm">
                                   <circle cx="18" cy="18" r="17" />
                                   <path d="M18 4V8 M18 28V32 M4 18H8 M28 18H32 M9 9L11 11 M25 25L27 27 M9 27L11 25 M25 11L27 9" strokeWidth="1" opacity="0.6" />
                                 </svg>
                               </span>
                               <span className="relative z-10 text-[0.45em] mt-0.5">{toArabicDigits(ayah.numberInSurah)}</span>
                            </span>
                          </React.Fragment>
                        );
                      })}
                    </div>
                </div>
             </div>
          </div>
        )}
      </div>

      {/* 3. Footer Navigation (Collapsible & Auto-Lift) */}
      <div 
        className={`fixed left-0 right-0 h-16 bg-white/95 dark:bg-navy-900/95 border-t border-navy-100 dark:border-navy-800 flex justify-between items-center px-6 z-40 transition-all duration-500 shadow-[0_-5px_20px_rgba(0,0,0,0.05)] backdrop-blur-md
          ${isImmersive ? 'translate-y-[200%]' : 'translate-y-0'}
          ${currentTrack ? 'bottom-[70px] md:bottom-[70px]' : 'bottom-[70px] md:bottom-0'} 
        `}
      >
        <button onClick={handleNext} disabled={page >= 604} className="flex flex-row-reverse items-center gap-2 text-navy-700 dark:text-navy-300 disabled:opacity-30 hover:bg-gold-50 dark:hover:bg-navy-800 px-4 py-2 rounded-xl transition-colors">
          <ChevronRight size={20} className="rotate-180" />
          <span className="font-bold text-sm hidden sm:inline">الصفحة التالية</span>
        </button>
        
        {/* Page Number / Navigation Trigger */}
        <div 
          className="flex flex-col items-center cursor-pointer hover:scale-105 transition-transform" 
          onClick={() => setIsNavOpen(true)}
        >
           <span className="text-[10px] text-navy-400 font-bold mb-0.5">رقم الصفحة</span>
           <span className="text-base font-bold text-navy-900 dark:text-white bg-gold-100 dark:bg-navy-800 px-4 py-0.5 rounded-lg border border-gold-200 dark:border-navy-700 shadow-inner flex items-center gap-2">
             <Grid size={14} className="text-gold-600 dark:text-gold-400 opacity-70" />
             {toArabicDigits(page)}
           </span>
        </div>

        <button onClick={handlePrev} disabled={page <= 1} className="flex flex-row-reverse items-center gap-2 text-navy-700 dark:text-navy-300 disabled:opacity-30 hover:bg-gold-50 dark:hover:bg-navy-800 px-4 py-2 rounded-xl transition-colors">
          <span className="font-bold text-sm hidden sm:inline">الصفحة السابقة</span>
          <ChevronLeft size={20} className="rotate-180" />
        </button>
      </div>

      {/* --- NEW: Navigation Modal (Surahs/Pages) --- */}
      {isNavOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in slide-in-from-bottom-10">
          <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={() => setIsNavOpen(false)}></div>
          <div className="relative w-full sm:max-w-md bg-white dark:bg-navy-950 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden border-t-4 border-gold-500 h-[70vh] flex flex-col">
            
            {/* Header / Tabs */}
            <div className="p-4 bg-navy-50 dark:bg-navy-900 border-b border-navy-100 dark:border-navy-800">
               <div className="flex justify-between items-center mb-4">
                 <h3 className="font-bold text-lg text-navy-900 dark:text-white flex items-center gap-2">
                   <Grid size={20} className="text-gold-500" /> الانتقال السريع
                 </h3>
                 <button onClick={() => setIsNavOpen(false)} className="p-1.5 rounded-full hover:bg-navy-200 dark:hover:bg-navy-800 text-navy-500"><X size={20} /></button>
               </div>
               
               <div className="flex bg-white dark:bg-navy-950 p-1 rounded-xl border border-navy-100 dark:border-navy-800">
                 <button 
                   onClick={() => setNavTab('surahs')}
                   className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${navTab === 'surahs' ? 'bg-gold-500 text-white shadow-md' : 'text-navy-500 hover:bg-navy-50 dark:hover:bg-navy-800'}`}
                 >
                   <BookOpen size={16} /> السور
                 </button>
                 <button 
                   onClick={() => setNavTab('pages')}
                   className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${navTab === 'pages' ? 'bg-gold-500 text-white shadow-md' : 'text-navy-500 hover:bg-navy-50 dark:hover:bg-navy-800'}`}
                 >
                   <Hash size={16} /> الصفحات
                 </button>
               </div>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-white dark:bg-navy-950">
               {navTab === 'surahs' ? (
                 <div className="grid grid-cols-3 gap-2">
                   {allSurahs.map(s => (
                     <button
                       key={s.number}
                       onClick={() => navigateToSurah(s.number)}
                       className="flex flex-col items-center justify-center p-3 rounded-xl border border-navy-100 dark:border-navy-800 hover:border-gold-500 dark:hover:border-gold-500 hover:bg-gold-50 dark:hover:bg-navy-900 transition-all text-center group"
                     >
                        <div className="w-8 h-8 rounded-full bg-navy-50 dark:bg-navy-800 flex items-center justify-center text-xs font-bold text-navy-400 group-hover:bg-gold-500 group-hover:text-white transition-colors mb-1 font-sans">
                          {s.number}
                        </div>
                        <span className="font-quran font-bold text-navy-800 dark:text-white text-base truncate w-full">{s.name}</span>
                     </button>
                   ))}
                 </div>
               ) : (
                 <div className="space-y-4">
                    <div className="flex items-center gap-2 bg-navy-50 dark:bg-navy-900 p-2 rounded-xl">
                       <span className="text-sm font-bold text-navy-500 px-2">رقم الصفحة:</span>
                       <input 
                         type="number" 
                         min="1" max="604" 
                         placeholder="1-604"
                         className="flex-1 p-2 rounded-lg bg-white dark:bg-navy-950 border border-navy-200 dark:border-navy-800 text-center font-bold outline-none focus:ring-2 focus:ring-gold-500"
                         onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                               navigateToPage(parseInt((e.target as HTMLInputElement).value));
                            }
                         }}
                       />
                       <button className="bg-gold-500 text-white p-2 rounded-lg font-bold text-sm shadow-md">
                         انتقال
                       </button>
                    </div>
                    
                    <div className="grid grid-cols-5 gap-2">
                       {/* Quick Jump Grid (Every 10 or 20 pages or Juz) */}
                       {Array.from({ length: 30 }).map((_, i) => (
                         <button
                           key={i}
                           onClick={() => navigateToPage((i * 20) + 2)} // Rough start of Juz
                           className="p-3 rounded-xl border border-navy-100 dark:border-navy-800 hover:bg-gold-50 dark:hover:bg-navy-900 transition-colors text-center"
                         >
                            <span className="text-[10px] text-navy-400 block">الجزء</span>
                            <span className="font-bold text-navy-800 dark:text-white text-lg">{toArabicDigits(i + 1)}</span>
                         </button>
                       ))}
                    </div>
                 </div>
               )}
            </div>

          </div>
        </div>
      )}

      {/* 4. Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={() => setIsSettingsOpen(false)}></div>
          <div className="relative w-full max-w-sm bg-white dark:bg-navy-900 rounded-3xl shadow-2xl overflow-hidden border border-navy-100 dark:border-navy-800">
            <div className="p-5 border-b border-navy-100 dark:border-navy-800 flex justify-between items-center bg-navy-50 dark:bg-navy-950">
              <h3 className="font-bold text-lg text-navy-900 dark:text-white flex items-center gap-2">
                <Settings size={20} className="text-gold-500" /> إعدادات العرض
              </h3>
              <button onClick={() => setIsSettingsOpen(false)} className="p-1.5 rounded-full hover:bg-navy-200 dark:hover:bg-navy-800 text-navy-500"><X size={20} /></button>
            </div>
            
            <div className="p-8 space-y-8">
              <div>
                <label className="flex items-center gap-2 text-sm font-bold text-navy-700 dark:text-navy-300 mb-3">
                  <Type size={18} className="text-gold-500" /> حجم الخط
                </label>
                <div className="flex items-center gap-3 bg-navy-50 dark:bg-navy-950 p-3 rounded-xl border border-navy-100 dark:border-navy-800">
                  <span className="text-xs font-bold text-navy-400">A</span>
                  <input type="range" min="18" max="50" value={fontSize} onChange={(e) => setFontSize(parseInt(e.target.value))} className="flex-1 accent-gold-600 h-2 bg-navy-200 dark:bg-navy-700 rounded-lg cursor-pointer" />
                  <span className="text-xl font-bold text-navy-900 dark:text-white">A</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Ayah Actions Modal */}
      {isModalOpen && selectedAyah && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center sm:items-center p-0 sm:p-4 isolate">
          
          <div 
            className="absolute inset-0 bg-navy-900/80 backdrop-blur-sm transition-opacity duration-300" 
            onClick={() => setIsModalOpen(false)}
          ></div>

          <div className="relative w-full sm:max-w-lg bg-white dark:bg-navy-950 rounded-t-3xl sm:rounded-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.3)] border-t-4 border-gold-500 overflow-hidden flex flex-col max-h-[85vh] animate-in slide-in-from-bottom-full duration-300 ease-out">
            
            <div className="flex-shrink-0 p-5 border-b border-navy-100 dark:border-navy-800 bg-gradient-to-b from-navy-50 to-white dark:from-navy-900 dark:to-navy-950 relative">
               
               <button 
                 onClick={() => setIsModalOpen(false)} 
                 className="absolute top-4 left-4 p-2 bg-white dark:bg-navy-800 rounded-full text-navy-400 hover:text-red-500 shadow-sm hover:shadow-md transition-all z-10"
               >
                 <X size={20} />
               </button>

               <div className="flex flex-col items-center justify-center gap-2 pt-2">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gold-500/20 rotate-45 rounded-xl blur-sm"></div>
                    <span className="relative w-14 h-14 flex items-center justify-center bg-gold-500 text-white font-bold text-2xl rounded-2xl shadow-lg font-sans border-2 border-white dark:border-navy-800">
                      {toArabicDigits(selectedAyah.numberInSurah)}
                    </span>
                  </div>
                  <div className="text-center mt-1">
                    <h3 className="font-quran text-2xl font-bold text-navy-900 dark:text-white">{(selectedAyah as any).surah?.name}</h3>
                    <div className="flex items-center justify-center gap-2 text-xs font-bold text-navy-500 dark:text-navy-400 mt-1">
                       <span className="bg-navy-100 dark:bg-navy-800 px-2 py-0.5 rounded-md">الجزء {toArabicDigits(selectedAyah.juz)}</span>
                       <span className="w-1 h-1 bg-gold-500 rounded-full"></span>
                       <span className="bg-navy-100 dark:bg-navy-800 px-2 py-0.5 rounded-md">صفحة {toArabicDigits(page)}</span>
                    </div>
                  </div>
               </div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar bg-slate-50 dark:bg-navy-950">
               <div className="p-5 pb-10 space-y-6">
                  
                  {/* Action Buttons: Desaturated/Darker Gradients & Softer Shadows */}
                  <div className="grid grid-cols-4 gap-3">
                     {[
                       { icon: <PlayCircle size={26} />, label: "استماع", action: () => playFromHere(false), color: "from-indigo-600 to-indigo-700 shadow-indigo-500/20" },
                       { icon: <Repeat size={26} />, label: "إكمال التلاوة", action: () => playFromHere(true), color: "from-purple-600 to-purple-700 shadow-purple-500/20" },
                       { icon: <BookOpen size={26} />, label: "تفسير", action: () => { setShowNoteInput(false); !tafsirData ? (setTafsirLoading(true), fetchTafsir((selectedAyah as any).surah.number, selectedAyah.numberInSurah).then(d => {setTafsirData(d); setTafsirLoading(false);})) : setTafsirData(null); }, color: "from-emerald-600 to-emerald-700 shadow-emerald-500/20" },
                       { icon: <Bookmark size={26} className={isAyahSaved ? "fill-current" : ""} />, label: isAyahSaved ? "محفوظة" : "حفظ", action: () => { toggleAyahBookmark({ surahName: (selectedAyah as any).surah.name, surahNumber: (selectedAyah as any).surah.number, ayahNumber: selectedAyah.numberInSurah, pageNumber: page, timestamp: Date.now() }); setIsAyahSaved(!isAyahSaved); }, color: isAyahSaved ? "from-red-600 to-red-700 shadow-red-500/20" : "from-navy-600 to-navy-700 shadow-navy-500/20" },
                     ].map((btn, i) => (
                       <button key={i} onClick={btn.action} className="group flex flex-col items-center gap-2">
                          <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${btn.color} text-white flex items-center justify-center shadow-lg transition-transform group-active:scale-95 group-hover:scale-105`}>
                             {btn.icon}
                          </div>
                          <span className="text-[11px] font-bold text-navy-700 dark:text-navy-300">{btn.label}</span>
                       </button>
                     ))}
                  </div>

                  {/* NEW: Hifz (Memorization) Repeater Tools */}
                  <div className="bg-white dark:bg-navy-900 rounded-xl p-3 border border-navy-100 dark:border-navy-800 shadow-sm">
                     <div className="flex items-center gap-2 mb-3 px-1">
                        <Repeat size={16} className="text-gold-500" />
                        <span className="text-xs font-bold text-navy-800 dark:text-white">أدوات التحفيظ (تكرار الآية)</span>
                     </div>
                     <div className="flex justify-between gap-2">
                        {[
                          { label: '3 مرات', count: 3 },
                          { label: '5 مرات', count: 5 },
                          { label: '10 مرات', count: 10 },
                          { label: 'لا نهائي', count: 100 }
                        ].map((opt, idx) => (
                          <button 
                            key={idx}
                            onClick={() => playFromHere(false, opt.count)}
                            className="flex-1 py-2 px-1 bg-navy-50 dark:bg-navy-800 hover:bg-gold-500 hover:text-white dark:hover:bg-gold-500 rounded-lg text-[10px] font-bold text-navy-600 dark:text-navy-300 transition-colors flex items-center justify-center gap-1"
                          >
                            {opt.count === 100 ? <InfinityIcon size={14} /> : opt.count}
                            {opt.count !== 100 && 'مرات'}
                          </button>
                        ))}
                     </div>
                  </div>
                  
                  <div className="flex gap-2">
                     <button onClick={() => { setTafsirData(null); setShowNoteInput(!showNoteInput); }} className="flex-1 py-3 bg-white dark:bg-navy-800 rounded-xl border border-navy-100 dark:border-navy-700 flex items-center justify-center gap-2 text-xs font-bold text-navy-600 dark:text-navy-300 hover:bg-gold-50 dark:hover:bg-navy-700 transition-colors">
                       <FileEdit size={16} /> تدوين ملاحظة
                     </button>
                     <button onClick={() => { navigator.clipboard.writeText(selectedAyah.text); setIsModalOpen(false); }} className="flex-1 py-3 bg-white dark:bg-navy-800 rounded-xl border border-navy-100 dark:border-navy-700 flex items-center justify-center gap-2 text-xs font-bold text-navy-600 dark:text-navy-300 hover:bg-gold-50 dark:hover:bg-navy-700 transition-colors">
                       <Copy size={16} /> نسخ النص
                     </button>
                  </div>

                  <hr className="border-navy-100 dark:border-navy-800" />

                  <div className="min-h-[150px] transition-all duration-300">
                     {tafsirLoading ? (
                       <div className="flex flex-col items-center justify-center py-8 gap-3">
                         <div className="animate-spin rounded-full h-8 w-8 border-4 border-navy-100 border-t-gold-500"></div>
                         <p className="text-xs font-bold text-navy-400">جاري جلب التفسير...</p>
                       </div>
                     ) : tafsirData ? (
                       <div className="bg-white dark:bg-navy-900 p-5 rounded-2xl shadow-sm border border-gold-100 dark:border-navy-800 animate-in fade-in zoom-in-95">
                          <div className="flex items-center justify-between mb-3 border-b border-navy-50 dark:border-navy-800 pb-2">
                             <h4 className="text-sm font-bold text-gold-600 dark:text-gold-500 flex items-center gap-2">
                               <BookOpen size={16} /> التفسير الميسر
                             </h4>
                             <button onClick={() => setTafsirData(null)} className="text-xs text-navy-400 hover:text-red-500 font-bold">إغلاق</button>
                          </div>
                          <p className="text-base leading-loose text-navy-800 dark:text-gray-300 font-serif text-justify">
                            {tafsirData.text}
                          </p>
                       </div>
                     ) : showNoteInput ? (
                       <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2">
                          <label className="text-sm font-bold text-navy-700 dark:text-navy-300 flex items-center gap-2">
                             <FileEdit size={16} className="text-gold-500" /> خواطرك حول الآية
                          </label>
                          <textarea 
                            value={noteText} 
                            onChange={(e) => setNoteText(e.target.value)} 
                            placeholder="اكتب تدبرك هنا..." 
                            className="w-full p-4 rounded-2xl bg-white dark:bg-navy-900 border border-navy-200 dark:border-navy-800 focus:ring-2 focus:ring-gold-500 outline-none text-base min-h-[120px] text-navy-900 dark:text-white resize-none shadow-inner" 
                          />
                          <button 
                            onClick={() => { saveNote({ surahName: (selectedAyah as any).surah.name, surahNumber: (selectedAyah as any).surah.number, ayahNumber: selectedAyah.numberInSurah, pageNumber: page, text: noteText, timestamp: Date.now() }); setShowNoteInput(false); }} 
                            className="w-full py-3.5 bg-navy-800 hover:bg-navy-700 text-white rounded-xl font-bold shadow-lg shadow-navy-900/20 flex items-center justify-center gap-2 transition-colors"
                          >
                            <Save size={18} /> حفظ الملاحظة
                          </button>
                       </div>
                     ) : (
                       <div className="text-center pt-2 pb-6">
                          {/* Single Ayah View: Neutral Background */}
                          <div className="relative p-6 bg-slate-50 dark:bg-[#111827] rounded-3xl shadow-sm border border-navy-50 dark:border-navy-800">
                             <span className="absolute top-4 right-4 text-4xl text-gold-200 dark:text-navy-800 font-serif leading-none">“</span>
                             
                             <p className="font-quran text-2xl leading-[2.6] text-navy-900 dark:text-white relative z-10">
                               {selectedAyah.text}
                             </p>
                          </div>
                       </div>
                     )}
                  </div>
               </div>
               
               <div className="h-10 sm:h-6"></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const CornerDecoration = ({ className }: { className?: string }) => (
  <div className={`absolute w-12 h-12 text-gold-600/20 dark:text-gold-500/10 pointer-events-none ${className}`}>
    <svg viewBox="0 0 100 100" fill="currentColor" className="w-full h-full">
      <path d="M0 0 H40 V5 H5 V40 H0 Z" />
      <path d="M10 10 H45 V13 H13 V45 H10 Z" opacity="0.6" />
    </svg>
  </div>
);
